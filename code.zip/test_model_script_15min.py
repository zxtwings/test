import lightgbm
import pandas as pd
import numpy as np
from lightgbm import LGBMClassifier
from sklearn.metrics import classification_report, accuracy_score
from sklearn.model_selection import GridSearchCV, ParameterGrid
from sklearn.preprocessing import StandardScaler
from ta.momentum import RSIIndicator
from ta.volume import VolumeWeightedAveragePrice
import matplotlib.pyplot as plt
from lightgbm import early_stopping, log_evaluation
from xgboost import XGBClassifier

from back_trade.back_test_feature_engine.feature_engine_short import FeatureEngine
from back_trade.pick_top_feature import pick_top_features

engine = FeatureEngine()

# === 1. 读取数据 ===
df = pd.read_csv("TQQQ_15min_session.csv", parse_dates=True, index_col=0)  # 👈 改成你的文件路径
df["datetime"] = pd.to_datetime(df["timestamp"])
df = df.set_index("datetime")


# === 4. 数据划分：8:1:1 时间顺序 ===
n = len(df)
# train_end = 40000
# valid_end = 43000
# train_end = int(n * 0.8)
# valid_end = int(n * 0.9)
# print(train_end, valid_end)

start_train = 0
train_end = 10600
valid_end = train_end + 26 * 200
test_end = valid_end + 26 * 200

df = engine.enrich_features_15min(df)


df = df.dropna()

train, valid, test = df[start_train:train_end], df[train_end:valid_end], df[valid_end:test_end]




# === 3. 特征选择 ===


# X_train = train.drop(columns=['target', "timestamp"])
# X_valid = valid.drop(columns=['target', "timestamp"])
# X_test = test.drop(columns=['target', "timestamp"])

X_train = train.drop(columns=['target', "timestamp", "future_return", "future_close", "future_open"])
X_valid = valid.drop(columns=['target', "timestamp", "future_return", "future_close", "future_open"])
X_test = test.drop(columns=['target', "timestamp", "future_return", "future_close", "future_open"])


scaler = StandardScaler()
X_train = pd.DataFrame(
    scaler.fit_transform(X_train),
    columns=X_train.columns,
    index=X_train.index
)

X_valid = pd.DataFrame(
    scaler.fit_transform(X_valid),
    columns=X_valid.columns,
    index=X_valid.index
)

X_test = pd.DataFrame(
    scaler.transform(X_test),
    columns=X_test.columns,
    index=X_test.index
)

# features = pick_top_features(train, 20)
# print(features)
# # X_train = X_train[features.keys()]
# # X_valid = X_valid[features.keys()]
# # X_test = X_test[features.keys()]
# X_train = train[features]
# X_valid = valid[features]
# X_test = test[features]

y_train = train['target']
y_valid = valid['target']
y_test = test['target']





# === 5. 模型训练 ===
model1 = LGBMClassifier(
    n_estimators=10000,
    learning_rate=0.01,
    max_depth=1,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    num_leaves= 127,    # 公式：min(2^(max_depth)-1, 127)
    feature_fraction= 0.5,
    bagging_freq= 5,
    bagging_fraction= 0.6,
    min_data_in_leaf= 50,  # 针对5分钟数据特性
    lambda_l1=0.01,
    lambda_l2=0.01,
    verbose=-1,
    class_weight="balanced",
    path_smooth= 0,
)

model1.fit(
    X_train, y_train,
    eval_set=[(X_valid, y_valid)],
    # eval_metric='multi_logloss',
    callbacks=[
        early_stopping(stopping_rounds=100),
        log_evaluation(period=50)
    ]
)

# model2 = XGBClassifier(
#     objective='multi:softprob',
#     num_class=3,
#     n_estimators=10000,
#     learning_rate=0.01,
#     max_depth=6,
#     early_stopping_rounds=50,  # ✅ 正确的 early stop 参数
#     subsample=0.8,
#     colsample_bytree=0.8,
#     eval_metric='mlogloss',  # ✅ 多分类用 mlogloss
#     use_label_encoder=False,  # ✅ 防止警告
#     verbosity=-1
# )
#
# model2.fit(
#     X_train, y_train,
#     eval_set=[(X_valid, y_valid)],
#     verbose=Fa               # ✅ 输出日志
# )


y_pred = model1.predict(X_train)
acc = accuracy_score(y_train, y_pred)
print(f"\n✅ Test Accuracy: {acc:.2%}\n")
print(classification_report(y_train, y_pred))

y_pred = model1.predict(X_valid)
acc = accuracy_score(y_valid, y_pred)
print(f"\n✅ Test Accuracy: {acc:.2%}\n")
print(classification_report(y_valid, y_pred))

# === 6. 在 test 集上评估 ===
y_pred = model1.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f"\n✅ Test Accuracy: {acc:.2%}\n")
print(classification_report(y_test, y_pred))

probas = model1.predict_proba(X_test)
# 计算第三项（p2）减第一项（p0）
# p_diff = probas[:, 2]
pred_label = np.argmax(probas, axis=1)

# 默认预测（即 argmax）
# 2. 找出预测为2的样本索引
# pred_as_2_mask = p_diff > 0.1
pred_as_2_mask = (pred_label == 2)  & (probas[:, 2] > 0.3)

# 3. 统计这些样本的准确率
if np.sum(pred_as_2_mask) == 0:
    print("没有样本被自定义规则预测为2。")
else:
    true_labels_for_pred2 = y_test[pred_as_2_mask]
    acc_2 = np.mean(true_labels_for_pred2 == 2)
    n_pred_2 = pred_as_2_mask.sum()
    print(f"样本总数: {len(pred_as_2_mask)}")
    print(f"自定义预测为2的样本数: {n_pred_2}")
    print(f"这些样本的准确率: {acc_2:.2%}")

# === 7. 特征重要性图 ===
# plt.title("LGBM Feature Importance")
# plt.xlabel("Importance")
# plt.ylabel("Feature")
# plt.tight_layout()
# plt.show()
#
#
# # === 5. 模型训练 ===
# model = LGBMClassifier(
#     n_estimators=10000,
#     learning_rate=0.01,
#     max_depth=5,
#     subsample=0.8,
#     colsample_bytree=0.8,
#     random_state=42,
#     num_class = 3,
#
#     verbose=-1,
# )
# # param_grid = {
# #     "learning_rate": [0.01, 0.05, 0.1],
# #     "max_depth": [5, 7, 9],
# #     "subsample": [0.7, 0.8, 0.9],
# #     "colsample_bytree": [0.7, 0.8, 0.9],
# # }
#
# best_score = -1
# best_params = None
# best_model = None
#
# # 遍历所有参数组合
# for params in ParameterGrid(param_grid):
#     print("\nTraining with params:", params)
#
#     model = lightgbm.LGBMClassifier(
#         n_estimators=10000,
#         num_class=3,
#         random_state=42,
#         verbose=-1,
#         **params  # 使用当前网格参数
#     )
#
#     model.fit(
#         X_train, y_train,
#         eval_set=[(X_valid, y_valid)],
#         eval_metric='multi_logloss',
#         callbacks=[
#             early_stopping(stopping_rounds=100),
#             log_evaluation(period=50)
#         ]
#     )
#
#     # 在验证集上评估
#     y_valid_pred = model.predict(X_valid)
#     score = accuracy_score(y_valid, y_valid_pred)
#
#     # 保留最佳模型
#     if score > best_score:
#         best_score = score
#         best_params = params
#         best_model = model
#         print(f"🔥 New best score: {best_score:.4f}")
#
# # === 输出最佳参数 ===
# print("\n=== Best Parameters ===")
# print(best_params)
#
# # === 在测试集上评估最佳模型 ===
# y_pred = best_model.predict(X_test)
# acc = accuracy_score(y_test, y_pred)
#
# print(f"\n✅ Test Accuracy: {acc:.2%}")
# print("\n=== Classification Report ===")
# print(classification_report(y_test, y_pred))
