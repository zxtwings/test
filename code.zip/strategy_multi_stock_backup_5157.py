from datetime import datetime, timedelta
from random import random

import backtrader as bt
import pandas as pd
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

from back_trade.alpaca_commision import AlpacaCommission
from back_trade.back_test_feature_engine.feature_engine_daily import FeatureEngine
from back_trade.back_test_model.model_daily import MultiModelTrainerDaily
from back_trade.strategy_base import MLStrategy
from data_loader import get_sp500_tickers
import shap
import ta

DEBUG_MODE = False

def generate_features(df):
    df = df.copy()
    df["open_chg"] = df["open"].pct_change()
    df["high_chg"] = df["high"].pct_change()
    df["low_chg"] = df["low"].pct_change()
    df["close_chg"] = df["close"].pct_change()
    df["volume_chg"] = df["volume"].pct_change()

    # 技术指标（高级信号）
    df["RSI_14"] = ta.momentum.RSIIndicator(df["close"], window=14).rsi()
    atr = ta.volatility.AverageTrueRange(df["high"], df["low"], df["close"], window=14)
    df["ATR_14"] = atr.average_true_range()

    # 目标标签：预测未来1日是否上涨（涨=1，否则=0）
    # df["target"] = (df["open"].shift(-2) > df["open"].shift(-1)).astype(int).shift(1)

    threshold = 0.005  # 例如 0.2%

    # 未来开盘和收盘
    future_open_1 = df["open"].shift(-1)
    future_open_2 = df["open"].shift(-2)

    future_return = (future_open_2 - future_open_1) / future_open_1

    # 设定三分类标签
    # 用 pd.cut 得到分类类型
    df["target"] = pd.cut(
        future_return,
        bins=[-float('inf'), -threshold, threshold, float('inf')],
        labels=[0, 1, 2]
    )

    # 去除缺失
    df.dropna(inplace=True)
    return df


import pandas as pd
import numpy as np
import pandas as pd
import numpy as np

def compute_rsi(series, period=14):
    delta = series.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)
    avg_gain = gain.rolling(period).mean()
    avg_loss = loss.rolling(period).mean()
    rs = avg_gain / (avg_loss + 1e-9)
    return 100 - (100 / (1 + rs))

def select_best_feature(df, top_n=5, top_ratio=0.9):
    threshold = 0.005
    df = df.sort_values("date").reset_index(drop=True).copy()
    # 基础收益率/动量
    df['return_1d'] = df['close'].pct_change(1)
    df['return_3d'] = df['close'].pct_change(3)
    df['return_5d'] = df['close'].pct_change(5)
    df['return_10d'] = df['close'].pct_change(10)
    df['momentum_3'] = df['close'] - df['close'].shift(3)
    df['momentum_10'] = df['close'] - df['close'].shift(10)
    df['momentum_20'] = df['close'] - df['close'].shift(20)
    df['reverse_5d'] = -df['return_5d']

    # 均线相关
    df['ma10_bias'] = df['close'] / df['close'].rolling(10).mean() - 1
    df['ema10_bias'] = df['close'] / df['close'].ewm(span=10).mean() - 1

    df["SMA_5"] = ta.trend.sma_indicator(df["close"], window=5)
    df["SMA_10"] = ta.trend.sma_indicator(df["close"], window=10)
    df["EMA_5"] = ta.trend.ema_indicator(df["close"], window=5)

    # 波动率/振幅/极值
    df['volatility_10'] = df['close'].rolling(10).std()
    df["rolling_max_close_20"] = df["close"].rolling(20).max()
    df["rolling_min_close_20"] = df["close"].rolling(20).min()
    df["rolling_std_close_10"] = df["close"].rolling(10).std()
    df["amplitude_10"] = (df["high"].rolling(10).max() - df["low"].rolling(10).min()) / (df["low"].rolling(10).min() + 1e-9)
    df["close_in_range_10"] = (df["close"] - df["low"].rolling(10).min()) / (df["high"].rolling(10).max() - df["low"].rolling(10).min() + 1e-9)
    df['drawdown_10'] = df['close'] / df['close'].rolling(10).max() - 1
    df['close_vs_high20'] = df['close'] / df['high'].rolling(20).max()
    df['close_vs_low20'] = df['close'] / df['low'].rolling(20).min()
    df["high_low_range"] = (df["high"] - df["low"]) / df["open"]

    # 价量因子
    df['volume_ma_5'] = df['volume'].rolling(5).mean()
    df['volume_ma_20'] = df['volume'].rolling(20).mean()
    df['volume_ratio_5'] = df['volume'] / (df['volume_ma_5'] + 1e-9)
    df['volume_ratio_20'] = df['volume'] / (df['volume_ma_20'] + 1e-9)
    df["volume_change"] = df["volume"].pct_change()
    df["volume_std_10"] = df["volume"].rolling(10).std()
    df["volume_zscore_10"] = (df["volume"] - df["volume_ma_20"]) / (df["volume_std_10"] + 1e-9)

    # K线结构
    df["upper_shadow"] = df["high"] - df[["close", "open"]].max(axis=1)
    df["lower_shadow"] = df[["close", "open"]].min(axis=1) - df["low"]
    df["candle_body"] = df["close"] - df["open"]
    df["body_ratio"] = abs(df["candle_body"]) / (df["high"] - df["low"] + 1e-9)

    # 技术指标
    df["RSI_14"] = ta.momentum.rsi(df["close"], window=14)
    df["CCI_14"] = ta.trend.cci(df["high"], df["low"], df["close"], window=14)
    df["ADX_14"] = ta.trend.adx(df["high"], df["low"], df["close"], window=14)
    df["WILLR_14"] = ta.momentum.williams_r(df["high"], df["low"], df["close"], lbp=14)
    # stoch = ta.momentum.stoch(df["high"], df["low"], df["close"])
    # df["stochastic_k"] = stoch[0]
    # df["stochastic_d"] = stoch[1]

    macd = ta.trend.macd(df["close"])
    df["MACD"] = macd
    df["MACD_signal"] = ta.trend.macd_signal(df["close"])
    df["MACD_hist"] = ta.trend.macd_diff(df["close"])
    df["ATR_14"] = ta.volatility.average_true_range(df["high"], df["low"], df["close"], window=14)
    bb = ta.volatility.BollingerBands(df["close"], window=20, window_dev=2)
    df["Bollinger_width"] = bb.bollinger_hband() - bb.bollinger_lband()
    df["OBV"] = ta.volume.on_balance_volume(df["close"], df["volume"])
    df["Momentum_10"] = ta.momentum.awesome_oscillator(df["high"], df["low"])
    df["ROC_5"] = ta.momentum.roc(df["close"], window=5)

    # 连续涨跌与统计
    df["up_days_5"] = (df["close"] > df["close"].shift(1)).rolling(5).sum()
    df["down_days_5"] = (df["close"] < df["close"].shift(1)).rolling(5).sum()
    df["consecutive_up"] = df["close"].gt(df["close"].shift(1)).astype(int).groupby((df["close"].le(df["close"].shift(1))).cumsum()).cumsum()

    # 价量协同
    df["price_volume_corr_5"] = df["close"].rolling(5).corr(df["volume"])
    df["price_volume_corr_20"] = df["close"].rolling(20).corr(df["volume"])

    # 时间特征
    if isinstance(df.index, pd.DatetimeIndex):
        df["weekday"] = df.index.weekday
        df["is_month_end"] = df.index.is_month_end.astype(int)
        df["is_month_start"] = df.index.is_month_start.astype(int)
        df["day_of_year"] = df.index.dayofyear
    else:
        df["weekday"] = 0
        df["is_month_end"] = 0
        df["is_month_start"] = 0
        df["day_of_year"] = 0

    # 价格跳空
    df["prev_close"] = df["close"].shift(1)
    df["gap_open"] = (df["open"] - df["prev_close"]) / df["prev_close"]
    df["intraday_return"] = (df["close"] - df["open"]) / df["open"]

    # # 板块/大盘相对强弱（如有指数数据，df_index需对齐）
    # if df_index is not None:
    #     df["relative_strength_10"] = (df["close"]/df["close"].shift(10)) / (df_index["close"]/df_index["close"].shift(10))



    # 🏷️ 三分类标签（-1, 0, 1）
    future_open_1 = df['open'].shift(-1)
    future_close_1 = df['close'].shift(-1)
    future_return = (future_close_1 - future_open_1) / future_open_1
    df['target'] = pd.cut(
        future_return,
        bins=[-float('inf'), -threshold, threshold, float('inf')],
        labels=[-1, 0, 1]
    )

    df = df.dropna().reset_index(drop=True)

    # 🧹 保留有效特征
    exclude = ['date', 'open', 'high', 'low', 'close', 'volume', 'target']
    feature_cols = [col for col in df.columns if col not in exclude]
    return feature_cols, df
    X = df[feature_cols]
    y = df['target']

    # ✂️ 划分训练集验证集
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    # 🚀 LightGBM 多分类训练
    model = LGBMClassifier(objective='multiclass', num_class=3, n_estimators=100, random_state=42)
    model.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)],
        callbacks=[
            early_stopping(stopping_rounds=100, verbose=False),
            log_evaluation(period=0)  # 👈 不输出任何训练过程日志
        ]
    )

    # ⚠️ SHAP 分析：用 booster + raw 分数 + numpy
    booster = model.booster_
    X_train_np = X_train.values
    X_val_np = X_val.values

    explainer = shap.TreeExplainer(booster, model_output="raw")
    shap_values = explainer.shap_values(X_val_np)  # list of (n_samples, n_features) arrays

    # 📊 展示类别 -1 的 summary plot（即 target == -1）
    # shap.summary_plot(shap_values[0], X_val_np, feature_names=X_train.columns.tolist(), show=True)

    # 📤 返回最重要特征（针对类别 -1）
    # shap_mean = np.abs(shap_values[2]).mean(axis=0)  # 取类别 -1 的 mean shap
    shap_df = pd.DataFrame({
        'feature': X_train.columns,
        'mean_abs_shap': np.mean(np.abs(shap_values).mean(axis=0), axis=1)
    }).sort_values(by='mean_abs_shap', ascending=False)

    # 计算累计贡献比例
    shap_df['cum_contrib'] = shap_df['mean_abs_shap'].cumsum() / shap_df['mean_abs_shap'].sum()

    # 选出累计贡献 < top_ratio 的特征
    top_features = shap_df[shap_df['cum_contrib'] <= top_ratio]['feature'].tolist()

    # 保证至少有一个特征
    if len(top_features) == 0:
        top_features = [shap_df.iloc[0]['feature']]

    return top_features, df

def compute_scores(df):
    best_feats, df = select_best_feature(df, 3)
    # print(best_feats)

    # 特征和标签
    # features = ["open_chg", "high_chg", "low_chg", "close_chg", "volume_chg"]
    X = df[best_feats]
    y = df["target"]

    X_all = X.iloc[-600:-1]
    y_all = y.iloc[-600:-1]
    X_today = X.iloc[[-1]]

    # 划分训练集和验证集（例如 80% 训练，20% 验证）
    split_idx = int(len(X_all) * 0.8)
    X_train = X_all.iloc[:split_idx]
    X_val = X_all.iloc[split_idx:]
    y_train = y_all.iloc[:split_idx]
    y_val = y_all.iloc[split_idx:]

    model = LGBMClassifier(
        objective='multiclass',
        num_class=3,  # 三分类
        n_estimators=1000,  # 树的数量（可调）
        learning_rate=0.01,  # 学习率（推荐 0.03 ~ 0.1）
        max_depth=-1,  # 树最大深度（可控模型复杂度）
        min_child_samples=10,  # 每个叶子最少样本数（避免过拟合）
        subsample=0.8,  # 行采样（bagging）
        colsample_bytree=0.8,  # 列采样（20个特征也可以采样）
        reg_alpha=0.1,  # L1正则
        reg_lambda=0.1,  # L2正则
        random_state=42,
        class_weight="balanced",
        n_jobs=-1,
        verbose=-1
    )

    model.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)],
        callbacks=[
            early_stopping(stopping_rounds=100, verbose=False),
            log_evaluation(period=0)  # 👈 不输出任何训练过程日志
        ]
    )

    s = model.predict_proba(X_today)[0]

    if s[2] - max(s[0], s[1]) < 0.1:
        return 0

    final_score = s[2]

    return {
        "acc": 0.5,
        "score": round(final_score, 4),
        "final_score": round(final_score, 4)
    }

class MultiStockStrategy(MLStrategy):

    def __init__(self):
        super().__init__()
        self.current_day = None
        self.models = []
        self.lookback_days = 1  # 每次只滚动 1 天
        self.trained_dates = set()

        self.prediction_results = []
        self.last_30_results = []
        self.action_result = []

        self.start_pred = None
        self.end_pred = None
        self.predict_next = None

        self.train_window = 600

        self.cnt_day = 0


    def next1(self):
        for data in self.datas:
            pos = self.getposition(data)

            # 如果没有持仓，有一定概率买入
            if pos.size == 0 and random() < 0.05:
                self.buy(data=data, size=10)

            # 如果有持仓，有一定概率卖出
            elif pos.size > 0 and random() < 0.05:
                self.close(data=data)

    def next(self):

        self.cnt_day += 1
        if self.cnt_day < self.train_window: return
        self.current_date = pd.Timestamp(self.datas[0].datetime.datetime(0)).floor("1d").tz_localize("UTC")

        self.current_value = self.broker.getvalue()

        # today = self.datas[0].datetime.date(0)
        candidates = []

        # self.current_date = pd.Timestamp(self.data.datetime.datetime(0)).floor(self.mode + "in").tz_localize("UTC")
        self.current_value = self.broker.getvalue()

        self.update_drawdown()

        for data in self.datas:
            # print(data._name)
            train_data = self._build_dataframe(data)
            try:
                result = compute_scores(train_data)
                if result:
                    candidates.append((data, result["acc"], result["score"]))
            except Exception as e:
                print(e)
                pass

            # 当前 open 和明日 open



        dt = self.datas[0].datetime.date(0)
        print("-" * 40)
        print("资金：", self.broker.getvalue())
        s = f"📅 {dt} 当前持仓情况："

        for data in self.datas:
            pos = self.getposition(data)
            if pos.size != 0:
                s += f"✅ {data._name}: 持仓数量 = {pos.size}, 成本价 = {pos.price:.2f}   "
            # else:
            #     print(f"❌ {data._name}: 无持仓")
        print(s)


        # 根据 final_score 降序排列
        if not candidates:
            top_5 = []
        else:
            candidates.sort(key=lambda x: x[2], reverse=True)
            top_5 = set([item[0]._name for item in candidates[:10]])

        for data in self.datas:
            name = data._name
            pos = self.getposition(data)

            if name not in top_5:
                if pos.size > 0:
                    self.close(data=data)
        s = "购买: "
        for candidates in candidates[:10]:
            data, acc, score = candidates

            try:
                current_open = data.open[1]
                next_open = data.close[1]
                actual_up = next_open > current_open
                predicted_up = score > 0  # 你可调这个阈值
                self.prediction_results.append(predicted_up == actual_up)
            except IndexError:
                continue

            size = int((self.broker.getvalue()) / 10 / data.close[0])

            s += f"{data._name} = {size},  "
            self.buy(data=data, size = size)
        print(s)

        if len(self.prediction_results) != 0:
            print(f"准确率: {(sum(self.prediction_results) / len(self.prediction_results)):.2%}, {sum(self.prediction_results)}/{len(self.prediction_results)}")


    def _build_dataframe(self, data):
        try:
            n = len(data) - 1
            dates = [data.datetime.date(i) for i in range(-n, 1)]
            df = pd.DataFrame({
                "date": dates,
                "open": [data.open[i] for i in range(-n, 1)],
                "high": [data.high[i] for i in range(-n, 1)],
                "low": [data.low[i] for i in range(-n, 1)],
                "close": [data.close[i] for i in range(-n, 1)],
                "volume": [data.volume[i] for i in range(-n, 1)],
            }).set_index("date")
            return df
        except:
            return None


    def stop(self):
        print(self.max_drawdown)
        print(sum(self.prediction_results) / len(self.prediction_results))
        print(self.broker.getvalue())


# 创建 cerebro 实例
cerebro = bt.Cerebro()

# 添加数据
# symbols = ['AAPL', 'MSFT']
symbols = get_sp500_tickers()[:500]
for symbol in symbols:
    try:
        df = pd.read_csv(f'../sp500_data/{symbol}.csv', parse_dates=True, index_col=0).tail(1000)
        if len(df) != 1000:
            continue
        data = bt.feeds.PandasData(dataname=df, name=symbol)
        cerebro.adddata(data)
    except Exception as e:
        pass
# 添加策略
cerebro.addstrategy(MultiStockStrategy)

cerebro.broker.setcash(30000.0)

alpaca_commission = AlpacaCommission()
cerebro.broker.addcommissioninfo(alpaca_commission)

# 启动回测
cerebro.run()
# cerebro.plot()
