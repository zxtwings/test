import pandas as pd
import numpy as np
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.metrics import accuracy_score
from ta.momentum import RSIIndicator
from ta.volume import VolumeWeightedAveragePrice

from back_trade.back_test_feature_engine.feature_engine_short import FeatureEngine

# === 1. 加载数据 ===
df = pd.read_csv("TQQQ_5min_session.csv", parse_dates=True, index_col=0)
df["datetime"] = pd.to_datetime(df["timestamp"])
df = df.set_index("datetime")
df = df.sort_index()
engine = FeatureEngine()

df = engine.enrich_features_5min(df)
df = df.dropna()

exclude_cols = ["target", "timestamp", "future_return", "future_close", "future_open_1"]
feature = [col for col in df.columns if col not in exclude_cols]

# === 4. 划分训练窗口（2020 + 2021，每3个月共8个模型） ===
train_windows = [

    ("2021-10-01", "2021-10-31"),
    ("2021-11-01", "2021-11-30"),
    ("2021-12-01", "2021-12-31"),

    ("2020-07-01", "2020-09-30"),
    ("2020-10-01", "2020-12-31"),
    ("2021-01-01", "2021-03-31"),
    ("2021-04-01", "2021-06-30"),
    ("2021-07-01", "2021-09-30"),
    ("2021-10-01", "2021-12-31"),
    ("2022-01-01", "2022-03-31"),
    ("2022-04-01", "2022-06-30"),

    ("2020-07-01", "2020-12-31"),
    ("2021-01-01", "2021-06-30"),
    ("2021-07-01", "2021-12-31"),
    ("2022-01-01", "2022-06-30"),

    ("2020-07-01", "2021-06-30"),
    ("2021-07-01", "2022-06-30"),

    ("2020-07-01", "2022-06-30"),
]

# 测试集：2022 Q1
valid_df = df.loc["2022-07-01":"2022-07-31"]
X_valid = valid_df[feature]
y_valid = valid_df["target"]


# 测试集：2022 Q1
test_df = df.loc["2022-08-01":"2022-08-07"]
X_test = test_df[feature]
y_test = test_df["target"]

# === 5. 遍历每个训练窗口，训练并评估 ===
scores = []

# === 5. 训练 + 评估模型，记录得分和模型对象 ===
model_scores = []

for i, (start, end) in enumerate(train_windows):
    train_df = df.loc[start:end]
    X_train = train_df[feature]
    y_train = train_df["target"]

    model = LGBMClassifier(
        objective='multiclass',
        num_class=3,
        learning_rate=0.01,
        n_estimators=1000,
        max_depth=8,
        num_leaves=63,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        verbose=-1
    )



    model.fit(X_train, y_train,
    eval_set=[(X_valid, y_valid)],
    # eval_metric='multi_logloss',
    callbacks=[
        early_stopping(stopping_rounds=100),
        log_evaluation(period=50)
    ])

    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)


    y_pred_valid = model.predict(X_valid)
    acc_valid = accuracy_score(y_valid, y_pred_valid)

    scores.append((f"Model {i+1}: {start} → {end}", acc_valid, acc))


# === 6. 打印模型表现 ===
print("\n📊 各模型在 2022 Q1 上的准确率：\n")
for name, acc_valid, acc in scores:
    print(f"{name}: {acc_valid:.2%} {acc:.2%}")

