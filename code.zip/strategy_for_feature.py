import os.path

import yfinance as yf
import pandas as pd
import backtrader as bt
from datetime import timedelta

from glob import glob

from sklearn.metrics import accuracy_score

from back_trade.strategy_base import MLStrategy
from back_trade.utils import compute_accuracy, prepare_data, prepare_data_from_csv
from back_trade.back_test_model.model_short import MultiModelTrainer

import warnings
from sklearn.exceptions import ConvergenceWarning

# 屏蔽所有 ConvergenceWarning
warnings.filterwarnings("ignore", category=ConvergenceWarning)

DEBUG_MODE = False

full_pred = []
full_action = []

pick = []



def colorize_qty(accuracy_predict):
    if accuracy_predict > 55:
        return f"\033[92m{accuracy_predict:+5}\033[0m"  # 绿色
    elif accuracy_predict > 53:
        return f"\033[91m{accuracy_predict:+5}\033[0m"  # 红色
    else:
        return f"\033[97m{accuracy_predict:+5}\033[0m"  # 白色（灰）

def colorize_value(value):
    if value > 12500:
        return f"\033[92m{value:+5}\033[0m"  # 绿色
    elif value > 12000:
        return f"\033[91m{value:+5}\033[0m"  # 红色
    else:
        return f"\033[97m{value:+5}\033[0m"  # 白色（灰）


_features = [
            # 原有特征
            "Open", # Prediction accuracy:  51.17% (746/1458) | Value:   10537.80 |
            "High",
            "Low", "Close", "Volume",
            "sma_3", # Prediction accuracy:  50.62% (738/1458) | Value:   10715.50 |
            "sma_10",
            "momentum_3", "std_10", "rsi_14",
            "volume_change", "macd", "macd_signal", "macd_diff",
            "boll_width", "vwap", "atr_14", "adx", "cci_20",
            "roc_10", "stoch_k", "stoch_d", "obv",
            "is_open",
            "is_mid", "is_close",

            # ✅ 新增特征
            "price_vs_high",          # 当前价相对于近高点位置
            "price_vs_low",           # 当前价相对于近低点位置
            "close_position",         # 当前K线的收盘位置（在高低区间内）
            "range_ratio",            # 单根K线波幅
            "gap_open",               # 跳空开盘幅度
            "gap_close",              # K线实体方向幅度
            "candle_body",            # 实体大小
            "candle_upper_shadow",    # 上影线
            "candle_lower_shadow",    # 下影线
            "candle_body_ratio",      # 实体占整根K线比例
            "volume_spike",           # 成交量是否放大
            "volatility_volume_ratio",# 波动率 vs 成交量强度
            "ma_trend_slope",         # 均线斜率
            "macd_hist_slope",        # MACD加速
            "rsi_trend",              # RSI 上下趋势
            "bar_count_today",        # 当天第几根K线
            "cum_return_today",       # 当日累计收益
            "cum_volume_today"        # 当日累计成交量
        ]

# === Step 2: 自定义策略 ===
class PickFeatureStrategy(MLStrategy):

    mode = "15m"

    def __init__(self, df, features, now_date, test_period, train_window):

        super().__init__()

        self.data_df = df

        self.trainer = MultiModelTrainer()

        self.prediction_results = []
        self.initial_buy_done = False

        self.features = features
        self.start_pred = None
        self.train_window = train_window

        self.now_date = now_date
        self.period = test_period

        self.result = {}

        self.bar_count = 0
        self.current_date = None
        self.saved_date = 0
        self.bars_per_day = 78  # 09:30 ~ 16:00，一共 6.5 小时 → 26 根


    def next(self):

        current_dt = pd.Timestamp(self.data.datetime.datetime(0)).floor(self.mode + "in").tz_localize("UTC")

        if current_dt not in self.data_df.index: return

        idx = self.data_df.index.get_loc(current_dt)
        if idx < self.train_window : return

        self.current_value = self.broker.getvalue()
        self.update_drawdown()


        dt = self.datas[0].datetime.datetime(0)
        date = pd.Timestamp(dt.date()).tz_localize("UTC")

        # 每天开始，重置 bar_count
        if not self.saved_date or (self.saved_date.date() != dt.date()):
            self.saved_date = date
            self.bar_count = 1
        else:
            self.bar_count += 1

        # 🧹 如果是当天的倒数第二根K线
        if self.bar_count == self.bars_per_day - 1:
            # print(f"🧹 清盘中：{dt.strftime('%Y-%m-%d %H:%M')}")
            for data in self.datas:
                pos = self.getposition(data)
                if pos.size != 0:
                    self.close(data=data)
            return  # 当天不再操作


        # 记录起始价格
        if not self.start_pred: self.start_pred = self.data.close[0]

        train_df = self.data_df.iloc[idx-self.train_window:idx].dropna()

        X_train = train_df[self.features]
        y_train = train_df["target"]
        self.trainer.fit(X_train, y_train)

        # train_x = X_train[:50]
        # train_y = y_train[:50]
        # valid_x = X_train[50:]
        # valid_y = y_train[50:]
        # m = self.trainer.models[0].fit(X_train, y_train)
        #
        # y_pred = (m.predict(train_x))
        # print(accuracy_score(y_pred, train_y))
        #
        # y_pred = (m.predict(valid_x))
        # print(accuracy_score(y_pred, valid_y))



        today_row = self.data_df.iloc[[idx]]
        X_predict = today_row[self.features]
        prob = self.trainer.predict(X_predict)


        try:
            price_today = self.data.close[0]
            price_next = self.data.close[1]  # 明天的收盘价
            actual_up = 1 if price_next > price_today else 0
            predicted_up = 1 if prob > 0 else 0
            correct = predicted_up == actual_up

            self.prediction_results.append(correct)
            full_pred.append(correct)

            if not correct: color = "\033[91m"

            msg = f"No action (P_up={prob:.2f})"

            # 定义action
            shares = int(round(prob * 50))  # e.g. 0.7 → +2，-0.8 → -2
            current_position = self.getposition().size
            if shares > 0:
                # 需要买入
                self.buy(size=shares)
            elif shares < 0:
                # 需要卖出，确保不卖超过现有持仓
                sell_size = min(abs(shares), current_position)
                if sell_size > 0:
                    self.sell(size=sell_size)

            value = self.broker.getvalue()

            if DEBUG_MODE :
                try:
                    print(color
                            + f"{self.data.datetime.date(0)} \t| {self.data.close[0]:.2f} \t| {self.data.close[1]:.2f} \t| {msg} \t| Position: {self.position.size} \t| Value: ${value:.2f}"
                            + f" \t| {sum(self.prediction_results)} / {len(self.prediction_results)} \t| {sum(self.prediction_results) / len(self.prediction_results) * 100:.4f}%" + "\033[0m"
                          )
                except Exception as e:
                    pass


        except IndexError:
            # 最后一根 K 线没有 t+1，跳过
            self.predict_next = prob

    def stop(self):

        # 计算预测准确率
        accuracy_predict, correct_predict, total_predict = compute_accuracy(self.prediction_results)

        self.result = {"Value": self.broker.getvalue(), "Accuracy": accuracy_predict, "Ratio": ((self.broker.getvalue() - 30000) / 30000) / self.max_drawdown}

        if DEBUG_MODE:
            print(
                # f"Share: {self.features[0]:<7} | "
                f"Features: {str(self.features):<150} | "
                # f"Open: {self.start_pred:>8.2f} | "
                # f"Close: {self.data.close[0]:>8.2f} | " 
                f"Prediction accuracy: {accuracy_predict * 100:>6.2f}% ({correct_predict:>3}/{total_predict:<3}) | "
                + colorize_qty(round(accuracy_predict * 100, 2)) +
                # f"Action accuracy: {accuracy_action * 100:>6.2f}% ({correct_action:>3}/{total_action:<3}) | "
                # f"Last 30 accuracy: {accuracy_last_30 * 100:>6.2f}% ({correct_last_30:>2}/{total_last_30:<2}) | "
                f"\tValue:" + colorize_value(round(self.broker.getvalue(), 2))
                # f"Predict next: {self.predict_next:>5.2f}"
            )