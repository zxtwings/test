from datetime import datetime, timedelta
from random import random

import backtrader as bt
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

from back_trade.alpaca_commision import AlpacaCommission
from back_trade.back_test_feature_engine.feature_engine_daily import FeatureEngine
from back_trade.back_test_model.model_daily import MultiModelTrainerDaily
from back_trade.strategy_base import MLStrategy
from data_loader import get_sp500_tickers

DEBUG_MODE = False

class MultiStockStrategy(MLStrategy):

    def __init__(self):
        super().__init__()
        self.current_day = None
        self.models = []
        self.lookback_days = 1  # 每次只滚动 1 天
        self.trained_dates = set()

        self.prediction_results = []
        self.last_30_results = []
        self.action_result = []

        self.start_pred = None
        self.end_pred = None
        self.predict_next = None


    def next1(self):
        for data in self.datas:
            pos = self.getposition(data)

            # 如果没有持仓，有一定概率买入
            if pos.size == 0 and random() < 0.05:
                self.buy(data=data, size=10)

            # 如果有持仓，有一定概率卖出
            elif pos.size > 0 and random() < 0.05:
                self.close(data=data)

    def next(self):

        self.current_value = self.broker.getvalue()
        self.update_drawdown()

        today = self.datas[0].datetime.date(0)
        candidates = []

        for data in self.datas:
            train_data = self._build_dataframe(data)
            if train_data is None or len(train_data) <= 200:
                return

            engine = FeatureEngine()
            train_data = engine.enrich_features(train_data)

            # train_data["target"] = (train_data["open"].shift(-1) < train_data["open"].shift(-2)).astype(int)

            # 划分训练和测试集
            train_df = train_data[-200:-30]
            test_df = train_data[-30:]

            if len(train_df) < 30 or len(test_df) < 10:
                return

            # 特征和标签（涨为1，跌为0）
            X_train = train_df[["close", "open", "high", "low"]].dropna()[:-1]
            y_train = train_df["target"][:-1]

            X_test = test_df[["close", "open", "high", "low"]].dropna()[:-2]
            y_test = test_df["target"][:-2]

            # y_test[-1]

            try:
                # model = LogisticRegression()
                trainer = MultiModelTrainerDaily()
                trainer.fit(X_train, y_train)

                y_pred = trainer.valid(X_test)
                acc = accuracy_score(y_test, y_pred)

                candidates.append((data, trainer, acc))
            except Exception as e:
                print(e)
                continue

        # 选出 top10 准确率最高的股票
        candidates.sort(key=lambda x: x[2], reverse=True)
        top10 = candidates[:10]
        # 记录 Top 10 的股票名，便于后续检查非 Top 股票是否持仓
        top10_names = {data._name for data, _, _ in top10}

        # 当前 portfolio 中持仓的所有股票，非 Top10 的要清仓
        for data in self.datas:
            pos = self.getposition(data)
            if data._name not in top10_names and pos.size > 0:
                self.close(data=data)

        # 对 Top 10 的每只股票做预测决策
        for data, model, acc in top10:
            train_data = self._build_dataframe(data)
            if train_data is None or len(train_data) < 1:
                continue

            # 获取今天的特征
            row = train_data.iloc[-1]
            features = pd.DataFrame([{
                'close': row["close"],
                'open': row["open"],
                'high': row["high"],
                'low': row["low"]
            }])
            # features = features.pct_change(axis=1).fillna(0)

            prediction = model.predict_prob(features)

            pos = self.getposition(data)

            if prediction > 0 and pos.size == 0:

                size = prediction * 100 \
                    # if prediction * 100 * data.close[0] < 2000 else 2000 / data.close[0]
                self.buy(data=data, size=size)
            elif prediction < 0 and pos.size > 0:
                self.close(data=data)

        print(today, self.broker.getvalue())

    def _build_dataframe(self, data):
        try:
            n = len(data)
            dates = [data.datetime.date(i) for i in range(-n, 1)]
            df = pd.DataFrame({
                "date": dates,
                "open": [data.open[i] for i in range(-n, 1)],
                "high": [data.high[i] for i in range(-n, 1)],
                "volume": [data.volume[i] for i in range(-n, 1)],
                "low": [data.low[i] for i in range(-n, 1)],
                "close": [data.close[i] for i in range(-n, 1)],
            }).set_index("date")
            return df
        except:
            return None


    def stop(self):
        print(self.max_drawdown)
        print(self.broker.getvalue())


# 创建 cerebro 实例
cerebro = bt.Cerebro()

# 添加数据
# symbols = ['AAPL', 'MSFT']
symbols = get_sp500_tickers()[:50]
for symbol in symbols:
    df = pd.read_csv(f'../sp500_data/{symbol}.csv', parse_dates=True, index_col=0).tail(1200)
    data = bt.feeds.PandasData(dataname=df)
    cerebro.adddata(data)

# 添加策略
cerebro.addstrategy(MultiStockStrategy)

cerebro.broker.setcash(30000.0)

alpaca_commission = AlpacaCommission()
cerebro.broker.addcommissioninfo(alpaca_commission)

# 启动回测
cerebro.run()
# cerebro.plot()
