import backtrader as bt
import pandas as pd

from pandas.errors import PerformanceWarning
import warnings
warnings.simplefilter(action="ignore", category=PerformanceWarning)

class MLStrategy(bt.Strategy):


    def __init__(self):

        self.daily_returns = []
        self.last_value = None
        self.last_date = None
        self.current_value = None
        self.current_date = None

        self.initial_buy_done = True
        self.train_window = 100
        self.predict_window = 1
        self.trainer = None

        self.max_drawdown = 0
        self.peak_value = 0

        self.activate_daily_profit = False

        self.current_index = None

        self.daily_profit = 0
        self.weekly_profit = 0

        self.start_day_value = 0
        self.start_week_value = 0

        self.start_day_price = 0

        if not self.initial_buy_done:
            self.buy_half_position()
            self.initial_buy_done = True
            return  # 如果你希望第一次不做其他预测动作

    def next_base(self):
        self.current_date = pd.Timestamp(self.data.datetime.datetime(0)).floor(self.mode + "in").tz_localize("UTC")
        self.current_value = self.broker.getvalue()

        if self.current_date not in self.data_df.index: return False
        self.current_index = self.data_df.index.get_loc(self.current_date)
        if self.current_index < self.train_window or self.current_index + 1 >= len(self.data_df): return False

        # if self.is_new_day():
        #     self.start_day_value = self.current_value
        #
        # if self.is_new_week():
        #     self.start_week_value = self.current_value

        return True

    def base_action_start_of_day(self):

        pass

    def base_action_end_of_day(self):
        pass

    def calculate_weekly_profit(self):
        if self.is_new_week() or self.start_week_value == 0:
            self.start_week_value = self.current_value
        self.weekly_profit = (self.current_value - self.start_week_value) / self.start_week_value

    def calculate_daily_profit(self):
        if self.start_day_value is None:
            self.start_day_value = self.current_value
            return


        if self.is_new_day() or self.start_day_value == 0:
            self.start_day_value = self.current_value
            self.start_day_price = self.data.close[0]

        if self.is_end_of_day():
            # 计算收益率
            daily_return = (self.current_value - self.start_day_value) / self.start_day_value
            self.daily_returns.append(daily_return)

            # print(f"📅 {self.last_date.strftime('%Y-%m-%d %H:%M')} → {self.current_date.strftime('%Y-%m-%d %H:%M')} 日收益率: {daily_return * 100:.2f}%")
        self.daily_profit = (self.current_value - self.start_day_value) / self.start_day_value

    def buy_full_position(self):
        price = self.data.close[0]
        cash = self.broker.getcash()
        size = int(cash / price)
        if size > 0:
            self.buy(size=size)
            # value = self.broker.getvalue()
            # print(f"{self.data.datetime.date(0)} Buy {size} shares at {self.data.close[0]:.2f}  | Value: ${value:.2f}")
        return size

    def buy_amount(self, amount):
        price = self.data.close[0]
        cash = self.broker.getcash()

        size = int(min(cash, amount) / price)
        self.buy(size=size)
        return size

    def sell_amount(self, amount):
        price = self.data.close[0]
        size = self.position.size

        size = int(min(size, amount / price))
        self.sell(size=size)
        return size




    def sell_half_position(self):
        if self.position:
            size = self.position.size / 2  # 当前持仓数量（正值）
            self.sell(size=int(size))



    def buy_half_position(self):
        price = self.data.close[0]
        cash = self.broker.getcash()
        size = int(cash / price) / 2
        if size > 0:
            self.buy(size=size)
            value = self.broker.getvalue()
            # print(f"{self.data.datetime.date(0)} Buy {size} shares at {self.data.close[0]:.2f}  | Value: ${value:.2f}")
        return size

    def sell_full_position(self):
        """
        Sell all current shares in the position.
        """
        if self.position:
            size = self.position.size  # 当前持仓数量（正值）
            self.sell(size=size)
            # value = self.broker.getvalue()
            # print(f"{self.data.datetime.date(0)} SELL {size} shares at {self.data.close[0]:.2f}  | Value: ${value:.2f}")

    def is_new_week(self):
        if len(self.data) < 2:
            return False
        current_date = pd.Timestamp(self.data.datetime.datetime(0)).tz_localize("UTC").date()
        prev_date = pd.Timestamp(self.data.datetime.datetime(-1)).tz_localize("UTC").date()

        # 如果今天是周一，且上一根不是周一 → 说明是新的一周开始
        curr_week = (current_date.isocalendar().year, current_date.isocalendar().week)
        prev_week = (prev_date.isocalendar().year, prev_date.isocalendar().week)

        return curr_week != prev_week

    def is_end_of_week(self):
        if len(self.data) < 2:
            return False

        current_date = pd.Timestamp(self.data.datetime.datetime(0)).tz_localize("UTC").date()
        next_date = pd.Timestamp(self.data.datetime.datetime(1)).tz_localize("UTC").date()

        # 获取当前和下一根的（年份，周编号）
        curr_week = (current_date.isocalendar().year, current_date.isocalendar().week)
        next_week = (next_date.isocalendar().year, next_date.isocalendar().week)

        return curr_week != next_week

    def is_new_month(self):
        if len(self.data) < 2:
            return False

        curr_dt = pd.Timestamp(self.data.datetime.datetime(0)).tz_localize("UTC")
        prev_dt = pd.Timestamp(self.data.datetime.datetime(-1)).tz_localize("UTC")

        return curr_dt.month != prev_dt.month

    def is_end_of_month(self):
        if len(self.data) < 2:
            return False

        curr_dt = pd.Timestamp(self.data.datetime.datetime(0)).tz_localize("UTC")
        next_dt = pd.Timestamp(self.data.datetime.datetime(1)).tz_localize("UTC")

        return curr_dt.month != next_dt.month


    def update_drawdown(self):
        # 更新峰值
        if self.current_value > self.peak_value:
            self.peak_value = self.current_value
        # 计算当前回撤
        drawdown = (self.peak_value - self.current_value) / self.peak_value if self.peak_value > 0 else 0
        # 更新最大回撤
        if drawdown > self.max_drawdown:
            self.max_drawdown = drawdown

        pass


    def is_new_day(self):
        if len(self.data) < 2:
            return False  # 没有前一根，不能判断

        # 当前时间（当前 bar）
        current_dt = pd.Timestamp(self.data.datetime.datetime(0)).floor("5min").tz_localize("UTC")

        # 上一根时间（前一个 bar）
        prev_dt = pd.Timestamp(self.data.datetime.datetime(-1)).floor("5min").tz_localize("UTC")

        # 判断日期是否变化
        return current_dt.date() != prev_dt.date()

    def is_end_of_day(self):
        # 当前时间（已 floor 为当前K线开始时间）
        current_dt = pd.Timestamp(self.data.datetime.datetime(0)).floor("5min").tz_localize("UTC")

        # 如果数据还没到倒数第二根，就判断下一根
        if len(self.data) < 2:
            return False

        # 下一根K线的时间（+1）

        try:
            next_dt = pd.Timestamp(self.data.datetime.datetime(1)).floor("5min").tz_localize("UTC")

            return current_dt.date() != next_dt.date()
        except IndexError:
            return True