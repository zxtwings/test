from datetime import datetime, timedelta
from random import random

import backtrader as bt
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

from back_trade.back_test_feature_engine.feature_engine_daily import FeatureEngine
from back_trade.back_test_model.model_daily import MultiModelTrainerDaily
from back_trade.strategy_base import MLStrategy
from data_loader import get_sp500_tickers
import shap
import ta
import pandas as pd
import numpy as np
from lightgbm import LGBMRegressor
from sklearn.model_selection import train_test_split
import shap
DEBUG_MODE = False

def generate_features(df):
    df = df.copy()
    df["open_chg"] = df["open"].pct_change()
    df["high_chg"] = df["high"].pct_change()
    df["low_chg"] = df["low"].pct_change()
    df["close_chg"] = df["close"].pct_change()
    df["volume_chg"] = df["volume"].pct_change()

    # 技术指标（高级信号）
    df["RSI_14"] = ta.momentum.RSIIndicator(df["close"], window=14).rsi()
    atr = ta.volatility.AverageTrueRange(df["high"], df["low"], df["close"], window=14)
    df["ATR_14"] = atr.average_true_range()

    # 目标标签：预测未来1日是否上涨（涨=1，否则=0）
    # df["target"] = (df["open"].shift(-2) > df["open"].shift(-1)).astype(int).shift(1)

    threshold = 0.005  # 例如 0.2%

    # 未来开盘和收盘
    future_open_1 = df["open"].shift(-1)
    future_open_2 = df["open"].shift(-2)

    future_return = (future_open_2 - future_open_1) / future_open_1

    # 设定三分类标签
    # 用 pd.cut 得到分类类型
    df["target"] = pd.cut(
        future_return,
        bins=[-float('inf'), -threshold, threshold, float('inf')],
        labels=[0, 1, 2]
    )

    # 去除缺失
    df.dropna(inplace=True)
    return df


import pandas as pd
import numpy as np
import pandas as pd
import numpy as np

def compute_rsi(series, period=14):
    delta = series.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)
    avg_gain = gain.rolling(period).mean()
    avg_loss = loss.rolling(period).mean()
    rs = avg_gain / (avg_loss + 1e-9)
    return 100 - (100 / (1 + rs))

def select_best_feature(df, top_n=5):
    threshold = 0.003
    df = df.sort_values("date").reset_index(drop=True).copy()

    # 🎯 特征构造
    df['return_3d'] = df['close'].pct_change(3)
    df['return_5d'] = df['close'].pct_change(5)
    df['ma10_bias'] = df['close'] / df['close'].rolling(10).mean() - 1
    df['ema10_bias'] = df['close'] / df['close'].ewm(span=10).mean() - 1
    df['volatility_10'] = df['close'].rolling(10).std()
    df['momentum_10'] = df['close'] - df['close'].shift(10)
    df['volume_ratio_5'] = df['volume'] / df['volume'].rolling(5).mean()
    df['rsi_14'] = compute_rsi(df['close'], 14)
    df['bollinger_width'] = 2 * df['close'].rolling(20).std() / df['close'].rolling(20).mean()
    df['drawdown_10'] = df['close'] / df['close'].rolling(10).max() - 1
    df['close_vs_high20'] = df['close'] / df['high'].rolling(20).max()
    df['close_vs_low20'] = df['close'] / df['low'].rolling(20).min()
    df["prev_close"] = df["close"].shift(1)
    df["return_1d"] = (df["close"] - df["prev_close"]) / df["prev_close"]
    df["gap_open"] = (df["open"] - df["prev_close"]) / df["prev_close"]
    df["intraday_return"] = (df["close"] - df["open"]) / df["open"]
    df["high_low_range"] = (df["high"] - df["low"]) / df["open"]
    df["volume_change"] = df["volume"].pct_change()

    # 技术指标 (使用 ta 库)
    df["SMA_5"] = ta.trend.sma_indicator(df["close"], window=5)
    df["SMA_10"] = ta.trend.sma_indicator(df["close"], window=10)
    df["EMA_5"] = ta.trend.ema_indicator(df["close"], window=5)

    macd = ta.trend.macd(df["close"])
    df["MACD"] = macd
    df["MACD_signal"] = ta.trend.macd_signal(df["close"])
    df["MACD_hist"] = ta.trend.macd_diff(df["close"])

    df["RSI_14"] = ta.momentum.rsi(df["close"], window=14)
    df["Momentum_10"] = ta.momentum.awesome_oscillator(df["high"], df["low"])
    df["ROC_5"] = ta.momentum.roc(df["close"], window=5)

    df["ATR_14"] = ta.volatility.average_true_range(df["high"], df["low"], df["close"], window=14)
    bb = ta.volatility.BollingerBands(df["close"], window=20, window_dev=2)
    df["Bollinger_width"] = bb.bollinger_hband() - bb.bollinger_lband()

    df["OBV"] = ta.volume.on_balance_volume(df["close"], df["volume"])

    # 滚动统计特征
    df["rolling_max_close_20"] = df["close"].rolling(20).max()
    df["rolling_min_close_20"] = df["close"].rolling(20).min()
    df["rolling_std_close_10"] = df["close"].rolling(10).std()
    df["price_vs_rolling_max"] = df["close"] / df["rolling_max_close_20"]

    # 时间特征（如果 index 是 datetime）
    if isinstance(df.index, pd.DatetimeIndex):
        df["weekday"] = df.index.weekday
        df["is_month_end"] = df.index.is_month_end.astype(int)
        df["is_month_start"] = df.index.is_month_start.astype(int)
        df["day_of_year"] = df.index.dayofyear
    else:
        df["weekday"] = 0
        df["is_month_end"] = 0
        df["is_month_start"] = 0
        df["day_of_year"] = 0




    # # 🏷️ 三分类标签（-1, 0, 1）
    # future_open_1 = df['open'].shift(-1)
    # future_open_2 = df['open'].shift(-2)
    # future_return = (future_open_2 - future_open_1) / future_open_1
    # df['target'] = pd.cut(
    #     future_return,
    #     bins=[-float('inf'), -threshold, threshold, float('inf')],
    #     labels=[-1, 0, 1]
    # )
    #
    # df = df.dropna().reset_index(drop=True)
    #
    # # 🧹 保留有效特征
    # exclude = ['date', 'open', 'high', 'low', 'close', 'volume', 'target']
    # feature_cols = [col for col in df.columns if col not in exclude]
    # X = df[feature_cols]
    # y = df['target']
    #
    # # ✂️ 划分训练集验证集
    # X_train, X_val, y_train, y_val = train_test_split(
    #     X, y, test_size=0.2, stratify=y, random_state=42
    # )
    #
    # # 🚀 LightGBM 多分类训练
    # model = LGBMClassifier(objective='multiclass', num_class=3, n_estimators=100, random_state=42)
    # model.fit(X_train, y_train)
    #
    # # ⚠️ SHAP 分析：用 booster + raw 分数 + numpy
    # booster = model.booster_
    # X_train_np = X_train.values
    # X_val_np = X_val.values
    #
    # explainer = shap.TreeExplainer(booster, model_output="raw")
    # shap_values = explainer.shap_values(X_val_np)  # list of (n_samples, n_features) arrays
    #
    # # 📊 展示类别 -1 的 summary plot（即 target == -1）
    # # shap.summary_plot(shap_values[0], X_val_np, feature_names=X_train.columns.tolist(), show=True)
    #
    # # 📤 返回最重要特征（针对类别 -1）
    # # shap_mean = np.abs(shap_values[2]).mean(axis=0)  # 取类别 -1 的 mean shap
    # shap_df = pd.DataFrame({
    #     'feature': X_train.columns,
    #     'mean_abs_shap': np.mean(np.abs(shap_values).mean(axis=0), axis=1)
    # }).sort_values(by='mean_abs_shap', ascending=False)
    #
    # top_features = shap_df.head(top_n)['feature'].tolist()
    # return top_features, df

    # 🏷️ 回归目标：未来收益
    future_open_1 = df['open'].shift(-1)
    future_open_2 = df['open'].shift(-2)
    df['target'] = (future_open_2 - future_open_1) / future_open_1 * 100

    df = df.dropna().reset_index(drop=True)

    # 🧹 保留有效特征
    exclude = ['date', 'open', 'high', 'low', 'close', 'volume', 'target']
    feature_cols = [col for col in df.columns if col not in exclude]

    X = df[feature_cols]
    y = df['target']

    # ✂️ 划分训练集与验证集
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # 🚀 LightGBM 回归模型
    model = LGBMRegressor(n_estimators=100, learning_rate=0.05, random_state=42)
    model.fit(X_train, y_train)

    # 📈 SHAP 分析
    booster = model.booster_
    explainer = shap.TreeExplainer(booster)

    X_val_np = X_val.values
    shap_values = explainer.shap_values(X_val_np)  # (n_samples, n_features)

    # 📊 平均特征贡献（取绝对值平均）
    shap_df = pd.DataFrame({
        'feature': X_train.columns,
        'mean_abs_shap': np.abs(shap_values).mean(axis=0)
    }).sort_values(by='mean_abs_shap', ascending=False)

    # 🔝 提取 top N 个特征
    top_n = 3  # 你可以改
    top_features = shap_df.head(top_n)['feature'].tolist()

    return top_features, df[top_features]


def compute_scores(df):
    best_feats, df = select_best_feature(df, 3)
    # print(best_feats)

    # 特征和标签
    # features = ["open_chg", "high_chg", "low_chg", "close_chg", "volume_chg"]
    X = df[best_feats]
    y = df["target"]

    X_all = X.iloc[-200:-1]
    y_all = y.iloc[-200:-1]
    X_today = X.iloc[[-1]]

    # 划分训练集和验证集（例如 80% 训练，20% 验证）
    X_train, X_val, y_train, y_val = train_test_split(
        X_all, y_all, test_size=0.2, random_state=42
    )

    # 训练模型（带验证集）
    # model = LGBMClassifier(
    #     n_estimators=150,
    #     max_depth=-1,
    #     learning_rate=0.02,
    #     subsample=0.8,
    #     colsample_bytree=0.8,
    #     random_state=42,
    #     verbose=-1,
    #     n_jobs=1
    # )

    # model.fit(
    #     X_train, y_train,
    #     eval_set=[(X_val, y_val)],
    #     eval_metric="multi_logloss",  # 或 "multi_logloss"（多分类）
    # )
    model = LGBMRegressor(n_estimators=100, learning_rate=0.05, random_state=42, max_depth=-1, )
    model.fit(X_all, y_all)

    # 对今日预测
    # y_val_pred = model.predict(X_val)
    # val_acc = accuracy_score(y_val, y_val_pred)
    #
    # if val_acc < 0.4:
    #     return 0

    score = model.predict(X_today)[0]

    if score < 0.01:
        return 0

    # 过滤器（高级信号）
    # rsi = df["RSI_14"].iloc[-1]
    # atr = df["ATR_14"].iloc[-1]
    # atr_mean = df["ATR_14"].rolling(20).mean().iloc[-1]
    #
    # rsi_filter = (rsi > 35) & (rsi < 70)
    # atr_filter = atr > atr_mean
    #
    # final_score = score * rsi_filter * atr_filter

    final_score = score

    return {
        "acc": 0.5,
        "score": round(score, 4),
        # "rsi_filter": bool(rsi_filter),
        # "atr_filter": bool(atr_filter),
        "final_score": round(final_score, 4)
    }

features = [
    # 原始特征
    "open", "high", "low", "close", "volume",

    # 一阶衍生
    "return_1d", "gap_open", "intraday_return", "high_low_range",
    #
    # # 均线与趋势
    # "SMA_5", "SMA_10", "EMA_5",
    # "MACD", "MACD_signal", "MACD_hist",
    #
    # # 动量类
    # "RSI_14", "Momentum_10", "ROC_5",
    #
    # # 波动性
    # "Bollinger_width", "ATR_14",
    #
    # # 成交量
    # "volume_change", "OBV",
    #
    # # 滚动统计
    # "rolling_std_close_10", "rolling_max_close_20", "rolling_min_close_20",
    # "price_vs_rolling_max",
    #
    # # 时间类（可选）
    # "weekday", "is_month_end"
]

# features = [
#     "close", "return_1d", "gap_open", "intraday_return",
#     "RSI_14", "MACD_hist", "volume", "SMA_5",
#     "high_low_range", "rolling_std_close_10", "OBV", "price_vs_rolling_max",
#     "MACD", "MACD_signal", "volume_change", "Bollinger_width",
#     "Momentum_10", "ROC_5", "SMA_10", "EMA_5",
#     "rolling_max_close_20", "rolling_min_close_20",
#     "weekday", "is_month_end"
# ]

class MultiStockStrategy(MLStrategy):

    def __init__(self):
        super().__init__()
        self.current_day = None
        self.models = []
        self.lookback_days = 1  # 每次只滚动 1 天
        self.trained_dates = set()

        self.prediction_results = []
        self.last_30_results = []
        self.action_result = []

        self.start_pred = None
        self.end_pred = None
        self.predict_next = None


    def next1(self):
        for data in self.datas:
            pos = self.getposition(data)

            # 如果没有持仓，有一定概率买入
            if pos.size == 0 and random() < 0.05:
                self.buy(data=data, size=10)

            # 如果有持仓，有一定概率卖出
            elif pos.size > 0 and random() < 0.05:
                self.close(data=data)

    def next(self):

        today = self.datas[0].datetime.date(0)
        candidates = []

        # self.current_date = pd.Timestamp(self.data.datetime.datetime(0)).floor(self.mode + "in").tz_localize("UTC")
        self.current_value = self.broker.getvalue()

        self.update_drawdown()

        for data in self.datas:
            train_data = self._build_dataframe(data)
            if train_data is None or len(train_data) <= 200:
                return

            result = compute_scores(train_data)

            # 当前 open 和明日 open

            if result:

                candidates.append((data, result["score"]))

        # 根据 final_score 降序排列
        if not candidates:
            top_5 = []
        else:
            candidates.sort(key=lambda x: x[1], reverse=True)
            top_5 = set([item[0]._name for item in candidates[:5]])

        for data in self.datas:
            name = data._name
            pos = self.getposition(data)

            if name not in top_5:
                if pos.size > 0:
                    self.close(data=data)
        for candidates in candidates[:5]:
            data, score = candidates

            try:
                current_open = data.open[1]
                next_open = data.open[2]
                actual_up = next_open > current_open
                predicted_up = score > 0  # 你可调这个阈值
                self.prediction_results.append(predicted_up == actual_up)
            except IndexError:
                continue

            self.buy(data=data, size = score * 100 if score * 100 * data.close[0] < 1000 else 1000 / data.close[0])

        # dt = self.datas[0].datetime.date(0)
        # print(f"\n📅 {dt} 当前持仓情况：")
        #
        # for data in self.datas:
        #     pos = self.getposition(data)
        #     if pos.size != 0:
        #         print(f"✅ {data._name}: 持仓数量 = {pos.size}, 成本价 = {pos.price:.2f}")
        #     else:
        #         print(f"❌ {data._name}: 无持仓")

        # 选出 top10 准确率最高的股票
        # candidates.sort(key=lambda x: x[2], reverse=True)
        # top10 = candidates[:10]
        # # 记录 Top 10 的股票名，便于后续检查非 Top 股票是否持仓
        # top10_names = {data._name for data, _, _ in top10}
        #
        # # 当前 portfolio 中持仓的所有股票，非 Top10 的要清仓
        # for data in self.datas:
        #     pos = self.getposition(data)
        #     if data._name not in top10_names and pos.size > 0:
        #         self.close(data=data)
        #
        #
        # if result["final_score"] > 0.7:
        #
        # print(result)


            # engine = FeatureEngine()
            # train_data = engine.enrich_features(train_data)

            # train_data["target"] = (train_data["open"].shift(-1) < train_data["open"].shift(-2)).astype(int)

            # 划分训练和测试集
            # train_df = train_data[-200:-30]
            # test_df = train_data[-30:]
            #
            # if len(train_df) < 30 or len(test_df) < 10:
            #     return
            #
            # global features
            #
            # # 特征和标签（涨为1，跌为0）
            # X_train = train_df[features].dropna()[:-1]
            # y_train = train_df["target"][:-1]
            #
            # X_test = test_df[features].dropna()[:-2]
            # y_test = test_df["target"][:-2]
            #
            # # y_test[-1]
            #
            # try:
            #     # model = LogisticRegression()
            #     trainer = MultiModelTrainerDaily()
            #     trainer.fit(X_train, y_train)
            #
            #     y_pred = trainer.valid(X_test)
            #     acc = accuracy_score(y_test, y_pred)
            #
            #     candidates.append((data, trainer, acc))
            # except Exception as e:
            #     print(e)
            #     continue


        # 选出 top10 准确率最高的股票
        # candidates.sort(key=lambda x: x[2], reverse=True)
        # top10 = candidates[:10]
        # # 记录 Top 10 的股票名，便于后续检查非 Top 股票是否持仓
        # top10_names = {data._name for data, _, _ in top10}
        #
        # # 当前 portfolio 中持仓的所有股票，非 Top10 的要清仓
        # for data in self.datas:
        #     pos = self.getposition(data)
        #     if data._name not in top10_names and pos.size > 0:
        #         self.close(data=data)
        #
        # # 对 Top 10 的每只股票做预测决策
        # for data, model, acc in top10:
            # train_data = self._build_dataframe(data)
            # if train_data is None or len(train_data) < 1:
            #     continue

            # 获取今天的特征
            # row = train_data.iloc[-1]
            # features = pd.DataFrame([{
            #     'close': row["close"],
            #     'open': row["open"],
            #     'high': row["high"],
            #     'volume': row["volume"],
            #     'low': row["low"]
            # }])
            # features = features.pct_change(axis=1).fillna(0)
            # engine = FeatureEngine()
            # train_data = engine.enrich_features(row)
            # global features
            # prediction = model.predict_prob(train_data[features].iloc[-1:])
            #
            # pos = self.getposition(data)
            #
            # if prediction > 0 and pos.size == 0:
            #
            #     size = prediction * 100 \
            #         # if prediction * 100 * data.close[0] < 2000 else 2000 / data.close[0]
            #     self.buy(data=data, size=size)
            # elif prediction < 0 and pos.size > 0:
            #     self.close(data=data)

        if len(self.prediction_results) != 0:
            print(sum(self.prediction_results) / len(self.prediction_results), sum(self.prediction_results), len(self.prediction_results))
        print(today, self.broker.getvalue())

    def _build_dataframe(self, data):
        try:
            n = len(data)
            dates = [data.datetime.date(i) for i in range(-n, 1)]
            df = pd.DataFrame({
                "date": dates,
                "open": [data.open[i] for i in range(-n, 1)],
                "high": [data.high[i] for i in range(-n, 1)],
                "low": [data.low[i] for i in range(-n, 1)],
                "close": [data.close[i] for i in range(-n, 1)],
                "volume": [data.volume[i] for i in range(-n, 1)],
            }).set_index("date")
            return df
        except:
            return None


    def stop(self):
        print(self.max_drawdown)
        print(sum(self.prediction_results) / len(self.prediction_results))
        print(self.broker.getvalue())


# 创建 cerebro 实例
cerebro = bt.Cerebro()

# 添加数据
# symbols = ['AAPL', 'MSFT']
symbols = get_sp500_tickers()[:50]
for symbol in symbols:
    df = pd.read_csv(f'../sp500_data/{symbol}.csv', parse_dates=True, index_col=0).tail(700)
    data = bt.feeds.PandasData(dataname=df, name=symbol)
    cerebro.adddata(data)

# 添加策略
cerebro.addstrategy(MultiStockStrategy)
cerebro.broker.setcommission(commission=0.001)

# 启动回测
cerebro.run()
# cerebro.plot()
