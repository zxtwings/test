from sklearn.model_selection import train_test_split
from lightgbm import LGBMClassifier
import pandas as pd


features = [
    "close", "volume", "sma_10", "rsi_14", "macd_diff", "atr_14", "vwap",
    "open", "high", "low",
    "sma_3", "momentum_3", "std_10", 'volume_change',
    "macd", "macd_signal",
    "boll_width", "adx", "cci_20",
    "roc_10", "stoch_k", "stoch_d", "obv",
    "is_open", "is_mid", "is_close",
    "price_vs_high", "price_vs_low", "gap_open", "candle_body"
]

def pick_top_features(df: pd.DataFrame, n: int = 20) -> dict:
    """
    使用 LGBMClassifier 从 dataframe 中选出前 n 个最重要的特征（归一化后）。

    参数:
    - df: 包含特征和 'target' 的 DataFrame
    - n: 需要返回的特征数量（默认20）

    返回:
    - 字典格式的特征重要性，例如 {"close": 0.35, "volume": 0.25, ...}
    """
    if 'target' not in df.columns:
        raise ValueError("DataFrame 中必须包含 'target' 列")

    # 分离特征和目标

    global features
    X = df[features]
    y = df['target']

    # 划分训练集和测试集
    split_idx = int(len(df) * 0.8)
    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]
    # 训练 LGBM 模型
    model = LGBMClassifier(random_state=42)
    model.fit(X_train, y_train)

    # 获取特征重要性
    importance = model.feature_importances_
    features = X.columns
    imp_dict = dict(zip(features, importance))

    # 排序并选出前 n 个
    sorted_items = sorted(imp_dict.items(), key=lambda item: item[1], reverse=True)[:n]

    # 归一化
    total_importance = sum(item[1] for item in sorted_items)
    normalized = {k: round(v / total_importance, 6) for k, v in sorted_items}

    return normalized
