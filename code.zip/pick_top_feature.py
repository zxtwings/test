import numpy as np
import shap
from sklearn.model_selection import train_test_split
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
import pandas as pd


features = [
    "close", "volume", "sma_10", "rsi_14", "macd_diff", "atr_14", "vwap",
    "open", "high", "low",
    "sma_3", "momentum_3", "std_10", 'volume_change',
    "macd", "macd_signal",
    "boll_width", "adx", "cci_20",
    "roc_10", "stoch_k", "stoch_d", "obv",
    "is_open", "is_mid", "is_close",
    "price_vs_high", "price_vs_low", "gap_open", "candle_body",

    # "open", "high", "low", "close", "rsi_14", "vwap", "sma_10"
]

def pick_top_features(df: pd.DataFrame, n: int = 20) -> dict:
    """
    使用 LGBMClassifier 从 dataframe 中选出前 n 个最重要的特征（归一化后）。

    参数:
    - df: 包含特征和 'target' 的 DataFrame
    - n: 需要返回的特征数量（默认20）

    返回:
    - 字典格式的特征重要性，例如 {"close": 0.35, "volume": 0.25, ...}
    """


    if 'target' not in df.columns:
        raise ValueError("DataFrame 中必须包含 'target' 列")

    X = df.drop(columns=['target', "timestamp", "future_return", "future_close", "future_open"])
    y = df['target']

    split_idx = int(len(df) * 0.8)
    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]
    # 训练 LGBM 模型
    model = LGBMClassifier(
        n_estimators=10000,
        learning_rate=0.01,
        max_depth=4,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        num_leaves= 127,    # 公式：min(2^(max_depth)-1, 127)
        feature_fraction= 0.5,
        bagging_freq= 5,
        bagging_fraction= 0.6,
        min_data_in_leaf= 50,  # 针对5分钟数据特性
        lambda_l1=0.01,
        lambda_l2=0.01,
        verbose=-1,
        # class_weight="balanced",
        path_smooth= 0,
    )

    model.fit(
        X_train, y_train,
        eval_set=[(X_test, y_test)],
        # eval_metric='multi_logloss',
        callbacks=[
                early_stopping(stopping_rounds=100, verbose=False),
                log_evaluation(period=0)  # 👈 不输出任何训练过程日志
        ]
    )


    # ⚠️ SHAP 分析：用 booster + raw 分数 + numpy
    booster = model.booster_
    X_train_np = X_train.values
    X_val_np = X_test.values

    explainer = shap.TreeExplainer(booster, model_output="raw")
    shap_values = explainer.shap_values(X_val_np)  # list of (n_samples, n_features) arrays

    shap_df = pd.DataFrame({
        'feature': X_train.columns,
        'mean_abs_shap': np.mean(np.abs(shap_values).mean(axis=0), axis=1)
    }).sort_values(by='mean_abs_shap', ascending=False)
    # 1. 先筛出相关性（mean_abs_shap）大于0的特征

    shap_df_filtered = shap_df[shap_df['mean_abs_shap'] > 0].copy()

    # 2. 加上类型归类
    shap_df_filtered['type'] = shap_df_filtered['feature'].apply(get_feature_type)

    shap_df['type'] = shap_df['feature'].apply(get_feature_type)
    filtered = (
        shap_df_filtered.groupby('type', group_keys=False)
        .head(2)  # 每类型最多2个
        .sort_values('mean_abs_shap', ascending=False)
        .head(n)  # 总数最多30个
    )

    return list(filtered["feature"].values)


def get_feature_type(feat):
    if feat.startswith('sma_') or feat.startswith('ema_'):
        return 'ma'
    if feat.startswith('mom_') or feat.startswith('ret_'):
        return 'momentum'
    if feat.startswith('boll_upper') or feat.startswith('boll_lower') or feat.startswith('boll_width') or feat.startswith('boll_pos'):
        return 'boll'
    if feat.startswith('macd_'):
        return 'macd'
    if feat.startswith('rsi_'):
        return 'rsi'
    if feat.startswith('cci_'):
        return 'cci'
    if feat.startswith('atr_'):
        return 'atr'
    if feat.startswith('vol_ma') or feat.startswith('vol_spike') or feat == 'volume_change' or feat == 'volatility_volume_ratio':
        return 'volume'
    if feat.startswith('high_max') or feat.startswith('low_min') or feat.startswith('price_vs_high') or feat.startswith('price_vs_low') or feat.startswith('range'):
        return 'range'
    if feat.startswith('up_') or feat.startswith('down_') or feat.startswith('body_ratio') or feat.startswith('upper_shadow') or feat.startswith('lower_shadow'):
        return 'kline'
    if feat.startswith('candle_'):
        return 'kline'
    if feat.startswith('gap_'):
        return 'gap'
    if feat in {'minute_of_day', 'is_open', 'is_mid', 'is_close', 'day_of_week', 'day_of_month'}:
        return 'time'
    if feat in {'price_vs_open', 'high_close_diff', 'low_close_diff', 'close_position'}:
        return 'derived'
    if feat == 'obv':
        return 'obv'
    if feat.startswith('prev_kline'):
        return 'prev_kline'
    # 默认自身
    return feat