import pandas as pd
import yfinance as yf

from back_trade.back_test_feature_engine.fe_class import calculate_all_features_alpaca
from back_trade.back_test_feature_engine.feature_engine_short import FeatureEngine

def compute_accuracy(results):
    total = len(results)
    correct = sum(results)
    accuracy = correct / total if total > 0 else 0.0
    return accuracy, correct, total

def prepare_data(tickers, mode, period):
    df = yf.download(tickers, interval=mode, period=period, multi_level_index=False, progress=False)
    engine = FeatureEngine(mode=mode)
    df = engine.enrich_features_5min(df)
    return df

def prepare_data_from_csv(symbol, mode):
    df = pd.read_csv(r"~/work/projects/quant/back_trade/data/" + symbol + "_" + mode + "in_intraday.csv", index_col=0, parse_dates=True)
    # df = pd.read_csv(r"back_trade/data/" + symbol + "_" + mode + "in_intraday.csv", index_col=0, parse_dates=True)
    df["datetime"] = pd.to_datetime(df["timestamp"])
    df = df.set_index("datetime")
    engine = FeatureEngine(mode=mode)
    df = engine.enrich_features_5min(df)

    # df.columns = [col.lower() for col in df.columns]
    # df = calculate_all_features_alpaca(df.copy())

    return df
