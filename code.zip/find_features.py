import random

import pandas as pd

from back_trade.alpaca_commision import AlpacaCommission
from back_trade.strategy_for_feature import PickFeatureStrategy
from back_trade.utils import prepare_data, prepare_data_from_csv
import backtrader as bt


def get_random_feature_subset(feature_list, min_size=1, max_size=4):
    """
    从特征列表中随机选择一个组合，返回子集
    """
    size = random.randint(min_size, min(max_size, len(feature_list)))
    subset = random.sample(feature_list, size)
    return subset

base_features = [
    # 'volume_change', 'Open'
    # "price_vs_high", "roc_10"
    # "sma_3", "sma_10"
]

features = [
    "close", "volume", "sma_10", "rsi_14", "macd_diff", "atr_14", "vwap",
    "open", "high", "low",
    "sma_3", "momentum_3", "std_10", 'volume_change',
    "macd", "macd_signal",
    "boll_width", "adx", "cci_20",
    "roc_10", "stoch_k", "stoch_d", "obv",
    "is_open", "is_mid", "is_close",
    "price_vs_high", "price_vs_low", "gap_open", "candle_body"
]

share_code = "TQQQ"

# df = (share_code, "15m", "60d")
# df = prepare_data(share_code, "15m", "60d")
# df = prepare_data_from_csv(share_code, "15m")

def get_train_test_slice(df, now_date, test_period, train_window):
    """
     从 df 中选出 now_date 之前（不含 now_date） 的 test_period + train_window 条记录

     参数：
         df : 包含 datetime 列的 DataFrame（升序排列）
         now_date : 当前日期（datetime.date 类型）
         test_period : 测试用的 K 线数量
         train_window : 训练窗口的长度

     返回：
         DataFrame：选出的切片
     """
    # 确保 datetime 是升序并且是 Timestamp 类型
    cutoff_ts = pd.Timestamp(now_date)

    # 过滤掉 now_date 当天及之后的数据
    df_before = df[df.index < cutoff_ts]

    # 总共需要的条数
    required_rows = test_period + train_window

    if len(df_before) < required_rows:
        raise ValueError(f"数据不足：只有 {len(df_before)} 条，要求 {required_rows} 条")

    return df_before.iloc[-required_rows:]


def pick_features(df, now_date, test_period, train_window, init_feature):


    df_bt = get_train_test_slice(df, now_date, test_period, train_window)
    df_bt.columns = df_bt.columns.str.lower()
    df_bt.index.name = "datetime"

    data = bt.feeds.PandasData(dataname=df_bt)

    best_score = 0
    best_features = []
    for i in range(100):

        cerebro = bt.Cerebro()
        cerebro.adddata(data)
        subset = get_random_feature_subset(features, min_size=2, max_size=4)

        if i == 0 and init_feature:
            subset = init_feature

        cerebro.addstrategy(PickFeatureStrategy, df_bt, subset, now_date, test_period, train_window)
        cerebro.broker.setcash(30000)

        alpaca_commission = AlpacaCommission()
        cerebro.broker.addcommissioninfo(alpaca_commission)

        res = cerebro.run()
        # if best_score < res[0].result["Ratio"] and res[0].result["Value"] > 30000:
        #     best_features = res[0].features
        #     best_score = res[0].result["Ratio"]

        if best_score < res[0].result["Accuracy"] and res[0].result["Value"] > 30000:
            best_features = res[0].features
            best_score = res[0].result["Accuracy"]

        # if best_score < res[0].result["Value"]:
        #     best_features = res[0].features
        #     best_score = res[0].result["Value"]

    # if best_score > 0.7:
    #
    #     return best_features, best_score
    # else:
    #     return [], 0

    return best_features, best_score
# print(pick_features(pd.Timestamp("2023-06-05").tz_localize("UTC"), 7))

# pick_features(pd.Timestamp("2023-06-05").tz_localize("UTC"), 7)
