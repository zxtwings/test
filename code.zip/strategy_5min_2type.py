import os.path

import yfinance as yf
import pandas as pd
import backtrader as bt
from datetime import timedelta

from glob import glob

from back_trade.strategy_base import MLStrategy
from back_trade.utils import compute_accuracy
from model.buy_strategy import BuyStrategy
from model.feature_engine import FeatureEngine
from model.model import MultiModelTrainer

DEBUG_MODE = True

full_pred = []
full_action = []

pick = []

# === Step 1: 下载数据并构造因子 ===
def prepare_data(tickers):
    df = yf.download(tickers, interval="15m", period="60d", multi_level_index=False, progress=False)
    engine = FeatureEngine(mode='5min')  # 或 'daily'
    df = engine.enrich_features_5min(df)
    return df


# === Step 2: 自定义策略 ===
class ML5MinStrategy(MLStrategy):
    def __init__(self, sharing_name):
        self.data_df = prepare_data(sharing_name)
        self.sharing_name = sharing_name
        self.current_day = None
        self.trainer = MultiModelTrainer()
        self.lookback_days = 1  # 每次只滚动 1 天
        self.trained_dates = set()

        self.prediction_results = []
        self.last_30_results = []
        self.action_result = []

        self.start_pred = None
        self.end_pred = None
        self.predict_next = None

        self.initial_buy_done = False
        self.strategy = BuyStrategy(mode="5min")

        self.data_df.index = self.data_df.index.floor("15min")

        self.features = [
            "sma_3", "sma_10", "momentum_3", "std_10", "rsi_14",
            "volume_change", "macd", "macd_signal", "macd_diff",
            "boll_width", "vwap", "atr_14", "adx", "cci_20",
            "roc_10", "stoch_k", "stoch_d", "obv"
        ]


    def next(self):

        current_dt = pd.Timestamp(self.data.datetime.datetime(0)).floor("15min").tz_localize("UTC")

        if current_dt not in self.data_df.index:
            return

        idx = self.data_df.index.get_loc(current_dt)

        # 每天更新模型：用前一日之前所有数据训练
        if idx < 1200 or idx + 1 >= len(self.data_df):
            return


        if not self.initial_buy_done:
            self.buy_full_position()
            self.initial_buy_done = True
            return  # 如果你希望第一次不做其他预测动作

        if not self.start_pred:
            self.start_pred = self.data.close[0]

        train_df = self.data_df.iloc[idx-200:idx].dropna()

        X_train = train_df[self.features]
        y_train = train_df["target"]
        # self.back_test_model = RandomForestClassifier(n_estimators=1000)
        # self.back_test_model.fit(X_train, y_train)


        # N = 1  # 想取几个数
        # numbers = random.sample(range(1, 101), N)
        #
        # for seed in numbers:


        self.trainer.fit(X_train, y_train)

        # self.trained_dates.add(date)

        # 模型已就绪，预测明天
        today_row = self.data_df.iloc[[idx]]

        if len(today_row) == 0:
            return
        features = today_row[self.features]

        prob = self.trainer.predict(features)

        color = "\033[92m"

        # 获取实际 next day 涨跌（t+1 close > t close）
        try:
            price_today = self.data.close[0]
            price_tomorrow = self.data.close[1]  # 明天的收盘价
            actual_up = 1 if price_tomorrow > price_today else 0
            predicted_up = 1 if prob > 0.5 else 0
            correct = predicted_up == actual_up

            current_date = self.data.datetime.date(0)
            last_date = self.data._dataname.index[-1].date()

            if last_date - current_date <= timedelta(days=30):
                self.last_30_results.append(correct)

            if not correct:
                color = "\033[91m"

            self.prediction_results.append(correct)

            full_pred.append(correct)

            msg = f"No action (P_up={prob:.2f})"  # 初始化空消息
            shares = self.strategy.decide_shares(prob)

            current_position = self.getposition().size

            if shares > 0:
                # 需要买入
                self.buy(size=shares)
            elif shares < 0:
                # 需要卖出，确保不卖超过现有持仓
                sell_size = min(abs(shares), current_position)
                if sell_size > 0:
                    self.sell(size=sell_size)

            value = self.broker.getvalue()

            if DEBUG_MODE :
                try:
                    print(color
                            + f"{self.data.datetime.date(0)} \t| {self.data.close[0]:.2f} \t| {self.data.close[1]:.2f} \t| {msg} \t| Position: {self.position.size} \t| Value: ${value:.2f}"
                            + f" \t| {sum(self.prediction_results)} / {len(self.prediction_results)} \t| {sum(self.prediction_results) / len(self.prediction_results):.2f}" + "\033[0m"
                          )
                except Exception as e:
                    pass


        except IndexError:
            # 最后一根 K 线没有 t+1，跳过
            self.predict_next = prob
        # pred = self.back_test_model.predict(features)[0]
        # if pred == 1:
        #     self.buy()
        #     value = self.broker.getvalue()
        #     print(f"{self.data.datetime.date(0)} Buy {1} shares at {self.data.close[0]:.2f}   | Value: ${value:.2f}   | Position: {self.position.size}")
        #     # self.buy_full_position()
        # elif self.position and pred == 0:
        #     # self.sell()
        #     # value = self.broker.getvalue()
        #     # print(f"{self.data.datetime.date(0)} SELL {1} shares at {self.data.close[0]:.2f}  | Position: ${self.position.size}  | Value: ${value:.2f}")
        #     self.sell_full_position()

    def stop(self):

        # 计算预测准确率
        accuracy_predict, correct_predict, total_predict = compute_accuracy(self.prediction_results)
        accuracy_action, correct_action, total_action = compute_accuracy(self.action_result)
        accuracy_last_30, correct_last_30, total_last_30 = compute_accuracy(self.last_30_results)

        print(
            f"Share: {self.sharing_name:<7} | "
            f"Open: {self.start_pred:>8.2f} | "
            f"Close: {self.data.close[0]:>8.2f} | "
            f"Prediction accuracy: {accuracy_predict * 100:>6.2f}% ({correct_predict:>3}/{total_predict:<3}) | "
            f"Action accuracy: {accuracy_action * 100:>6.2f}% ({correct_action:>3}/{total_action:<3}) | "
            f"Last 30 accuracy: {accuracy_last_30 * 100:>6.2f}% ({correct_last_30:>2}/{total_last_30:<2}) | "
            f"Value: {self.broker.getvalue():>10.2f} | "
            # f"Predict next: {self.predict_next:>5.2f}"
        )

        if accuracy_predict > 0.53 and accuracy_action > 0.53 and accuracy_last_30 > 0.6 and self.predict_next > 0.55:
            pick.append({
                "Share": self.sharing_name,
                "Prediction accuracy": round(accuracy_predict, 2),
                "Action accuracy": round(accuracy_action, 2),
                "Last 30 accuracy": round(accuracy_last_30, 2),
                "Value": round(self.broker.getvalue(), 2),
                # "Predict next": round(self.predict_next, 2)
            })


# === Step 3: 运行回测 ===
def run_backtest():

    for sharing_name_path in glob(r"sp500_data/*.csv"):

        cerebro = bt.Cerebro()
        sharing_name = os.path.basename(sharing_name_path)[:-4]

        # if sharing_name == "GILD":
        #     break

        sharing_name = "TQQQ"

        df = prepare_data(sharing_name)
        df_bt = df[["Open", "High", "Low", "Close", "Volume"]].copy()
        df_bt.columns = df_bt.columns.str.lower()
        df_bt.index.name = "datetime"
        # df_bt.index = pd.to_datetime(df_bt.index)

        data = bt.feeds.PandasData(dataname=df_bt)
        cerebro.adddata(data)
        cerebro.addstrategy(ML5MinStrategy, sharing_name=sharing_name)
        cerebro.broker.setcash(10000)
        cerebro.broker.setcommission(commission=0.001)
        cerebro.run()

        break

    total_predict = len(full_pred)
    correct_predict = sum(full_pred)
    accuracy_predict = correct_predict / total_predict if total_predict > 0 else 0.0

    total_action = len(full_action)
    correct_action = sum(full_action)
    accuracy_action = correct_action / total_action if total_action > 0 else 0.0

    print(
          f"Full prediction accuracy: {accuracy_predict*100:.2f}% ({correct_predict}/{total_predict}) \t"
          f"Full action accuracy: {accuracy_action*100:.2f}% ({correct_action}/{total_action}) \t"
    )

    # cerebro.plot()

if __name__ == "__main__":
    run_backtest()
    print(pick)