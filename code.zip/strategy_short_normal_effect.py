import os.path

import yfinance as yf
import pandas as pd
import backtrader as bt
from datetime import timedelta

from glob import glob

from back_trade.find_features import pick_features
from back_trade.strategy_base import MLStrategy
from back_trade.utils import compute_accuracy, prepare_data, prepare_data_from_csv
from back_trade.back_test_model.model_short import MultiModelTrainer

import warnings
from sklearn.exceptions import ConvergenceWarning

# 屏蔽所有 ConvergenceWarning
warnings.filterwarnings("ignore", category=ConvergenceWarning)

DEBUG_MODE = True

full_pred = []
full_action = []

pick = []



def colorize_qty(accuracy_predict):
    if accuracy_predict > 55:
        return f"\033[92m{accuracy_predict:+5}\033[0m"  # 绿色
    elif accuracy_predict > 53:
        return f"\033[91m{accuracy_predict:+5}\033[0m"  # 红色
    else:
        return f"\033[97m{accuracy_predict:+5}\033[0m"  # 白色（灰）

def colorize_value(value):
    if value > 12500:
        return f"\033[92m{value:+5}\033[0m"  # 绿色
    elif value > 12000:
        return f"\033[91m{value:+5}\033[0m"  # 红色
    else:
        return f"\033[97m{value:+5}\033[0m"  # 白色（灰）


_features = [
            # 原有特征
            "Open", # Prediction accuracy:  51.17% (746/1458) | Value:   10537.80 |
            "High",
            "Low", "Close", "Volume",
            "sma_3", # Prediction accuracy:  50.62% (738/1458) | Value:   10715.50 |
            "sma_10",
            "momentum_3", "std_10", "rsi_14",
            "volume_change", "macd", "macd_signal", "macd_diff",
            "boll_width", "vwap", "atr_14", "adx", "cci_20",
            "roc_10", "stoch_k", "stoch_d", "obv",
            "is_open",
            "is_mid", "is_close",

            # ✅ 新增特征
            "price_vs_high",          # 当前价相对于近高点位置
            "price_vs_low",           # 当前价相对于近低点位置
            "close_position",         # 当前K线的收盘位置（在高低区间内）
            "range_ratio",            # 单根K线波幅
            "gap_open",               # 跳空开盘幅度
            "gap_close",              # K线实体方向幅度
            "candle_body",            # 实体大小
            "candle_upper_shadow",    # 上影线
            "candle_lower_shadow",    # 下影线
            "candle_body_ratio",      # 实体占整根K线比例
            "volume_spike",           # 成交量是否放大
            "volatility_volume_ratio",# 波动率 vs 成交量强度
            "ma_trend_slope",         # 均线斜率
            "macd_hist_slope",        # MACD加速
            "rsi_trend",              # RSI 上下趋势
            "bar_count_today",        # 当天第几根K线
            "cum_return_today",       # 当日累计收益
            "cum_volume_today"        # 当日累计成交量
        ]

# === Step 2: 自定义策略 ===
class MLShortStrategy(MLStrategy):

    mode = "15m"

    def __init__(self, share_code, features):

        super().__init__()

        self.base_price = 0

        # self.data_df = prepare_data(share_code, self.mode, "60d")
        self.data_df = prepare_data_from_csv(share_code, "15m")
        self.share_code = share_code
        self.current_day = None

        self.trainer = MultiModelTrainer()

        self.prediction_results = []
        self.last_30_results = []

        self.start_pred = None
        self.end_pred = None

        self.initial_buy_done = False

        self.data_df.index = self.data_df.index.floor(self.mode + "in")

        self.features = features

        self.train_window = 100

        self.effective = 1

    def is_new_day(self):
        if len(self.data) < 2:
            return False  # 没有前一根，不能判断

        # 当前时间（当前 bar）
        current_dt = pd.Timestamp(self.data.datetime.datetime(0)).floor("15min").tz_localize("UTC")

        # 上一根时间（前一个 bar）
        prev_dt = pd.Timestamp(self.data.datetime.datetime(-1)).floor("15min").tz_localize("UTC")

        # 判断日期是否变化
        return current_dt.date() != prev_dt.date()

    def next(self):

        current_dt = pd.Timestamp(self.data.datetime.datetime(0)).floor(self.mode + "in").tz_localize("UTC")

        if current_dt not in self.data_df.index: return

        idx = self.data_df.index.get_loc(current_dt)
        if idx < self.train_window or idx + 1 >= len(self.data_df): return

        if self.is_new_day():
            new_features, score = pick_features(current_dt, 7)
            print(f"New day! Use new features: {new_features} with score {score}")
            self.features = new_features

            if int(score) == 10000:
                self.effective = 0
                print()


        # 记录起始价格
        if not self.start_pred: self.start_pred = self.data.close[0]


        # 更新模型：用之前100天所有数据训练
        train_df = self.data_df.iloc[idx-self.train_window:idx].dropna()


        X_train = train_df[self.features]
        y_train = train_df["target"]
        self.trainer.fit(X_train, y_train)

        today_row = self.data_df.iloc[[idx]]
        X_predict = today_row[self.features]
        prob = self.trainer.predict(X_predict)



        X_train = train_df[self.features][:-2]
        y_train = train_df["target2"][:-2]
        self.trainer.fit(X_train, y_train)
        today_row = self.data_df.iloc[[idx]]
        X_predict = today_row[self.features]
        prob += self.trainer.predict(X_predict)



        X_train = train_df[self.features][:-4]
        y_train = train_df["target3"][:-4]
        self.trainer.fit(X_train, y_train)
        today_row = self.data_df.iloc[[idx]]
        X_predict = today_row[self.features]
        prob += self.trainer.predict(X_predict)

        prob /= 3

        color = "\033[92m"

        # 获取实际 next day 涨跌（t+1 close > t close）
        try:
            price_today = self.data.close[0]
            price_next = self.data.close[1]  # 明天的收盘价
            actual_up = 1 if price_next > price_today else 0
            predicted_up = 1 if prob > 0 else 0
            correct = predicted_up == actual_up

            current_date = self.data.datetime.date(0)
            last_date = self.data._dataname.index[-1].date()

            if last_date - current_date <= timedelta(days=30):
                self.last_30_results.append(correct)
            self.prediction_results.append(correct)
            full_pred.append(correct)

            if not correct: color = "\033[91m"

            msg = f"No action (P_up={prob:.2f})"

            # 定义action
            shares = int(round(prob * 5))  # e.g. 0.7 → +2，-0.8 → -2
            current_position = self.getposition().size
            if shares > 0:
                # 需要买入
                self.buy(size=shares)
            elif shares < 0:
                # 需要卖出，确保不卖超过现有持仓
                sell_size = min(abs(shares), current_position)
                if sell_size > 0:
                    self.sell(size=sell_size)

            value = self.broker.getvalue()

            if DEBUG_MODE :
                try:
                    print(color
                            + f"{self.data.datetime.date(0)} \t| {self.data.close[0]:.2f} \t| {self.data.close[1]:.2f} \t| {msg} \t| Position: {self.position.size} \t| Value: ${value:.2f}"
                            + f" \t| {sum(self.prediction_results)} / {len(self.prediction_results)} \t| {sum(self.prediction_results) / len(self.prediction_results) * 100:.4f}%" + "\033[0m"
                          )
                except Exception as e:
                    pass


        except IndexError:
            # 最后一根 K 线没有 t+1，跳过
            self.predict_next = prob

    def stop(self):

        # 计算预测准确率
        accuracy_predict, correct_predict, total_predict = compute_accuracy(self.prediction_results)
        accuracy_last_30, correct_last_30, total_last_30 = compute_accuracy(self.last_30_results)


        print(
            # f"Share: {self.features[0]:<7} | "
            f"Features: {str(self.features):<150} | "
            # f"Open: {self.start_pred:>8.2f} | "
            # f"Close: {self.data.close[0]:>8.2f} | " 
            f"Prediction accuracy: {accuracy_predict * 100:>6.2f}% ({correct_predict:>3}/{total_predict:<3}) | "
            + colorize_qty(round(accuracy_predict * 100, 2)) +
            # f"Action accuracy: {accuracy_action * 100:>6.2f}% ({correct_action:>3}/{total_action:<3}) | "
            # f"Last 30 accuracy: {accuracy_last_30 * 100:>6.2f}% ({correct_last_30:>2}/{total_last_30:<2}) | "
            f"\tValue:" + colorize_value(round(self.broker.getvalue(), 2))
            # f"Predict next: {self.predict_next:>5.2f}"
        )

        if accuracy_predict > 0.52 or self.broker.getvalue() > 16000:
            line = (
                    f"Features: {str(self.features):<150} | "
                    f"Prediction accuracy: {accuracy_predict * 100:>6.2f}% ({correct_predict:>3}/{total_predict:<3}) | "
                    + str(round(accuracy_predict * 100, 2)) +
                    f"\tValue:" + str(round(self.broker.getvalue(), 2))
            )
            # 写入文件（追加模式）
            with open("selected_features_log.txt", "a", encoding="utf-8") as f:
                f.write(line + "\n")




# === Step 3: 运行回测 ===
import random

def get_random_feature_subset(feature_list, min_size=1, max_size=4):
    """
    从特征列表中随机选择一个组合，返回子集
    """
    size = random.randint(min_size, min(max_size, len(feature_list)))
    subset = random.sample(feature_list, size)
    return subset

base_features = [
    # 'volume_change', 'Open'
    "price_vs_high", "roc_10"
    # "sma_3", "sma_10"
]

def run_backtest():


    chosed_features = [
        "Close", "Volume", "sma_10", "rsi_14", "macd_diff", "atr_14", "vwap",
        "Open", "High", "Low",
        "sma_3", "momentum_3", "std_10", 'volume_change',
        "macd", "macd_signal",
        "boll_width", "adx", "cci_20",
        "roc_10", "stoch_k", "stoch_d", "obv",
        "is_open", "is_mid", "is_close",
        "price_vs_high", "price_vs_low", "gap_open", "candle_body"
    ]


    # price_vs_high roc_10

    share_code = "TQQQ"
    df = prepare_data(share_code, "15m", "60d")
    df = prepare_data_from_csv(share_code, "15m")

    # df_bt = df[["open", "high", "low", "close", "volume"]].copy()
    df_bt = df[["Open", "High", "Low", "Close", "Volume"]].copy()
    df_bt.columns = df_bt.columns.str.lower()
    df_bt.index.name = "datetime"

    data = bt.feeds.PandasData(dataname=df_bt)

    while True:

        cerebro = bt.Cerebro()
        cerebro.adddata(data)
        subset = []# get_random_feature_subset(chosed_features, min_size=1, max_size=10)

        cerebro.addstrategy(MLShortStrategy, share_code=share_code, features=base_features + subset)
        cerebro.broker.setcash(10000)
        cerebro.broker.setcommission(commission=0.001)
        cerebro.run()

        break


    total_predict = len(full_pred)
    correct_predict = sum(full_pred)
    accuracy_predict = correct_predict / total_predict if total_predict > 0 else 0.0

    total_action = len(full_action)
    correct_action = sum(full_action)
    accuracy_action = correct_action / total_action if total_action > 0 else 0.0

    print(
          f"Full prediction accuracy: {accuracy_predict*100:.2f}% ({correct_predict}/{total_predict}) \t"
          f"Full action accuracy: {accuracy_action*100:.2f}% ({correct_action}/{total_action}) \t"
    )

    # cerebro.plot()

if __name__ == "__main__":
    run_backtest()
    print(pick)