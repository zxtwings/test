import backtrader as bt

class AlpacaCommission(bt.CommInfoBase):
    params = (
        ('commission', 0.0),        # 无普通佣金
        ('sec_rate', 27.80 / 1_000_000),
        ('taf_rate', 0.000166),
        ('taf_max', 8.30),
    )

    def _getcommission(self, size, price, pseudoexec):
        if size > 0:
            return 0.0  # 买入不收费

        # 卖出才收费
        trade_value = abs(size) * price
        sec_fee = trade_value * self.p.sec_rate
        taf_fee = min(abs(size) * self.p.taf_rate, self.p.taf_max)

        total_fee = round(sec_fee + taf_fee, 4)  # 四舍五入到分
        return total_fee