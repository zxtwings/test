import os.path

import joblib
import numpy as np
import yfinance as yf
import pandas as pd
import backtrader as bt
from datetime import timedelta, datetime

from glob import glob

from lightgbm import LGBMClassifier

from back_trade.alpaca_commision import AlpacaCommission
from back_trade.back_test_feature_engine.feature_engine import FeatureEngine
from back_trade.find_features import pick_features, get_train_test_slice
from back_trade.pick_top_feature import pick_top_features
from back_trade.select_from_multi_window_near_best_features import get_best_model
from back_trade.strategy_base import MLStrategy
from back_trade.utils import compute_accuracy, prepare_data, prepare_data_from_csv
from back_trade.back_test_model.model_short import MultiModelTrainer

import warnings
from sklearn.exceptions import ConvergenceWarning

# 屏蔽所有 ConvergenceWarning
warnings.filterwarnings("ignore", category=ConvergenceWarning)

DEBUG_MODE = True
DEBUG_MODE_DETAIL = True

full_pred = []
full_action = []

pick = []



def colorize_qty(accuracy_predict):
    if accuracy_predict > 55:
        return f"\033[92m{accuracy_predict:+5}\033[0m"  # 绿色
    elif accuracy_predict > 53:
        return f"\033[91m{accuracy_predict:+5}\033[0m"  # 红色
    else:
        return f"\033[97m{accuracy_predict:+5}\033[0m"  # 白色（灰）

def colorize_value(value):
    if value > 12500:
        return f"\033[92m{value:+5}\033[0m"  # 绿色
    elif value > 12000:
        return f"\033[91m{value:+5}\033[0m"  # 红色
    else:
        return f"\033[97m{value:+5}\033[0m"  # 白色（灰）


_features = [
            # 原有特征
            "Open", # Prediction accuracy:  51.17% (746/1458) | Value:   10537.80 |
            "High",
            "Low", "Close", "Volume",
            "sma_3", # Prediction accuracy:  50.62% (738/1458) | Value:   10715.50 |
            "sma_10",
            "momentum_3", "std_10", "rsi_14",
            "volume_change", "macd", "macd_signal", "macd_diff",
            "boll_width", "vwap", "atr_14", "adx", "cci_20",
            "roc_10", "stoch_k", "stoch_d", "obv",
            "is_open",
            "is_mid", "is_close",

            # ✅ 新增特征
            "price_vs_high",          # 当前价相对于近高点位置
            "price_vs_low",           # 当前价相对于近低点位置
            "close_position",         # 当前K线的收盘位置（在高低区间内）
            "range_ratio",            # 单根K线波幅
            "gap_open",               # 跳空开盘幅度
            "gap_close",              # K线实体方向幅度
            "candle_body",            # 实体大小
            "candle_upper_shadow",    # 上影线
            "candle_lower_shadow",    # 下影线
            "candle_body_ratio",      # 实体占整根K线比例
            "volume_spike",           # 成交量是否放大
            "volatility_volume_ratio",# 波动率 vs 成交量强度
            "ma_trend_slope",         # 均线斜率
            "macd_hist_slope",        # MACD加速
            "rsi_trend",              # RSI 上下趋势
            "bar_count_today",        # 当天第几根K线
            "cum_return_today",       # 当日累计收益
            "cum_volume_today"        # 当日累计成交量
        ]

def scale_value(x):
    a, b = 1/3, 0.4  # 原始区间
    c, d = 0.05, 0.6  # 新区间
    if x >= b:
        return d
    elif x <= a:
        return c
    else:
        return (x - a) / (b - a) * (d - c) + c


# === Step 2: 自定义策略 ===
class MLShortStrategy(MLStrategy):

    mode = "15m"

    def __init__(self, share_code, init_features, data_df):

        super().__init__()

        self.base_price = 0

        self.share_code = share_code
        self.current_day = None

        self.trainer = MultiModelTrainer()

        self.prediction_results = []
        self.last_30_results = []

        self.start_pred = None
        self.end_pred = None

        self.initial_buy_done = False

        self.daily_pnl = 0.0  # 今日累计盈亏
        self.stop_trading_today = False  # 是否停止今日交易

        self.effective_days = []
        self.win_days = []
        self.begin_of_day_position = 0
        self.begin_of_day_cash = 30000
        self.last_day_value = 30000

        self.effective_weeks = []
        self.win_weeks = []
        self.begin_of_week_position = 0
        self.begin_of_week_cash = 30000
        self.last_week_value = 30000

        self.effective_months = []
        self.win_months = []
        self.begin_of_month_position = 0
        self.begin_of_month_cash = 30000
        self.last_month_value = 30000

        self.features = init_features

        self.train_window = 20800
        self.valid_window = 5

        self.effective = 1

        self.saved_value = 30000

        self.activate_daily_profit = True

        self.engine = FeatureEngine()

        self.data_df = data_df
        # self.data_df.index = self.data_df.index.floor(self.mode + "in")
        self.data_df = self.engine.enrich_features(self.data_df)

        self.bar_count = 0
        self.current_date = None

        self.saved_date = 0

        # 设置每天总共的K线数量（以15分钟为单位）
        self.bars_per_day = 26  # 09:30 ~ 16:00，一共 6.5 小时 → 26 根

        self.max_position = 0

        self.scores = []
        self.profits = []

        self.skip = False

        self.day_break = False
        self.day_pause = False
        self.week_break = False

        self.stop = 0

        self.model = None
        self.models = None


        self.threshold = 0.33


    def next1(self):

        if not self.next_base():
            return

        if self.is_new_day():
            self.buy_full_position()
        # else:
        #     if self.data_df.close[0] > self.data_df.open[0]:
        #         self.close()



        if self.is_end_of_day():
            self.close()
            print(self.broker.getvalue())
        # self.buy(size=1)
        if self.data.close[-1] < self.data.open[-1] and self.data.close[-2] < self.data.open[-2] and self.data.close[-3] < self.data.open[-3] :
            self.prediction_results.append(self.data.close[0] > self.data.open[0])
            print(sum(self.prediction_results) / len(self.prediction_results), len(self.prediction_results)  )

    def next(self):

        if not self.next_base():
            return


        if self.is_new_week():
            self.week_break = False
            # try:
            #     # new_features, score = pick_features(self.data_df, self.current_date, 78 * 2, self.train_window, self.features)    #
            #     # self.scores.append(score)
            #     # self.features = new_features
            #     # print("Change features: ", new_features, score)
            #
            #
            #     train_dataset = get_train_test_slice(self.data_df, self.current_date, 78 * 2, self.train_window)
            #     new_features = pick_top_features(train_dataset, 5   )
            #     # self.features = list(new_features.keys())
            #     self.features = new_features
            #     print("Change features: ", new_features)
            #
            # except Exception as e:
            #     print(e)
            #     pass
            # pass

        if self.is_new_day():
            self.max_position = 0
            self.day_break = False
            self.stop = 0
            pass


        if self.stop > 0:
            self.stop -= 1
            return



        self.update_drawdown()
        self.calculate_daily_profit()
        self.calculate_weekly_profit()


        # if self.daily_profit < -0.0025 and self.data.close[0] > self.start_day_price and self.stop == 0:
        #     print(f"❌ 亏损已达 {self.daily_profit*100}%，暂停策略")
        #     self.close()
        #     self.stop = 10
        #     return

        # if self.daily_profit < -0.03 and not self.day_break and not self.week_break and not self.day_pause:
        #     print(f"❌ 亏损已达 {self.daily_profit*100}%，暂停今日交易")
        #     pos = self.getposition()
        #     if pos.size != 0:
        #         self.sell(size=int(pos.size / 2))
        #     self.day_pause = True

        #
        # if self.daily_profit > -0.005 and not self.day_break and self.day_pause:
        #     print(f"❌ 亏损恢复到 {self.daily_profit*100}%，恢复今日交易")
        #     # for data in self.datas:
        #     #     pos = self.getposition(data)
        #     #     if pos.size != 0:
        #     #         self.close(data=data)
        #     self.day_pause = False
        #
        if self.daily_profit < -0.05 and not self.day_break and not self.week_break:
            print(f"❌ 亏损已达 {self.daily_profit*100}%，停止今日交易")
            for data in self.datas:
                pos = self.getposition(data)
                if pos.size != 0:
                    self.close(data=data)
            self.day_break = True

        # if self.is_end_of_day() and self.daily_profit < -0.02:
        #     print("Retrain strategy ... ")
        #     self.model = get_best_model(self.data_df, self.current_date, 21)
        #     # self.week_break = False


        if self.daily_profit > 0.06 and not self.day_break and not self.week_break:
            print(f"❌ 盈利已达 {self.daily_profit*100}%，停止今日交易")
            for data in self.datas:
                pos = self.getposition(data)
                if pos.size != 0:
                    self.close(data=data)
            self.day_break = True

        # if self.weekly_profit < -0.03 and not self.week_break and not self.day_break:
        #     print(f"❌ 亏损已达 {self.weekly_profit*100}%，停止本周交易")
        #     for data in self.datas:
        #         pos = self.getposition(data)
        #         if pos.size != 0:
        #             self.close(data=data)
        #     self.week_break = True
        #     self.day_break = True

        # if self.weekly_profit < -0.03 and not self.week_break and not self.day_break:
        #     print(f"❌ 亏损已达 {self.weekly_profit*100}%，暂停交易，更新模型")
        #     for data in self.datas:
        #         pos = self.getposition(data)
        #         if pos.size != 0:
        #             self.close(data=data)
        #     self.day_break = True

        # if self.weekly_profit > 0.045 and not self.week_break:
        #     print(f"❌ 盈利已达 {self.weekly_profit*100}%，停止本周交易")
        #     for data in self.datas:
        #         pos = self.getposition(data)
        #         if pos.size != 0:
        #             self.close(data=data)
        #     self.week_break = True
        #     self.day_break = True


        if self.max_position < self.getposition().size:
            self.max_position = self.getposition().size

        dt = self.datas[0].datetime.datetime(0)
        date = pd.Timestamp(dt.date()).tz_localize("UTC")



        # 每天开始，重置 bar_count
        if not self.saved_date or (self.saved_date.date() != dt.date()):
            self.saved_date = date
            self.bar_count = 1
        else:
            self.bar_count += 1

        # 🧹 如果是当天的倒数第二根K线
        if self.bar_count == self.bars_per_day - 1:
            # print(f"🧹 清盘中：{dt.strftime('%Y-%m-%d %H:%M')}")
            for data in self.datas:
                pos = self.getposition(data)
                if pos.size != 0:
                    self.close(data=data)
            self.day_break = True

        # if self.current_value > self.saved_value * 1.05:
        #     self.sell_full_position()
        #     self.saved_value = self.current_value
        #     return
        # elif self.current_value < self.saved_value * 0.95:
        #     self.sell_full_position()
        #     self.saved_value = self.current_value


        # if not self.features:
        #     return

        if not self.start_pred: self.start_pred = self.data.close[0]

        if not self.day_break and not self.week_break and not self.day_pause:

            # 更新模型：用之前100天所有数据训练
            train_df = self.data_df.iloc[self.current_index-self.train_window:self.current_index + 1].dropna()

            train_df["datetime"] = pd.to_datetime(train_df["timestamp"])
            train_df = train_df.set_index("datetime")
            # train_df = self.engine.enrich_features(train_df)

            # X_train = train_df[self.features][:-1]

            # X_train = train_df.drop(columns=['target', "timestamp", "future_return", "future_close", "future_open_1"])[:-1]
            #
            # y_train = train_df["target"][:-1]
            if self.is_new_day() or self.start_week_value == 0 or not self.models:

                last_week_end = self.current_date - pd.Timedelta(seconds=1)
                last_week_start = self.current_date - pd.Timedelta(days=14)
                week_mask = (self.data_df.index > last_week_start) & (self.data_df.index <= last_week_end)
                recent_week_df = self.data_df.loc[week_mask]

                # 2. 挑选最优feature
                # pick_top_features 已经写好，假设返回一个特征名称list
                top_features = pick_top_features(recent_week_df, n=30)  # 这里n可调整
                print("Select features: ", top_features)
                # 你可以保存结果
                self.features = top_features  # 假如你有self.top_features


                print("training new model...")
                self.models = []
                # model1, _ = get_best_model(self.data_df, self.current_date, 60)
                model2, models = get_best_model(self.data_df, self.current_date, top_features, 30)

                if model2 is None or len(models) < 3:
                    print("No model found, skip this day.")
                    self.day_break = True
                    return

                for m in models[:3]:
                    self.models.append(m)

                # model3, _ = get_best_model(self.data_df, self.current_date, 7)

                # self.models = [loaded_model]

                # self.models.append(model1)
                # self.models.append(model3)


            today_row = train_df[self.features][-1:]
            # # X_predict = today_row[self.features]
            # prob_down, _, prob_up = self.model.predict_proba(today_row)[0]


            y_probas = np.array(
                [model.predict_proba(today_row) for model in self.models])  # shape = (3, n_samples, n_classes)
            prob_down, prob_med, prob_up = np.mean(y_probas, axis=0)[0]  # shape = (n_samples, n_classes)

            color = "\033[92m"

            # 获取实际 next day 涨跌（t+1 close > t close）
            try:
                price_today = self.data.close[0]
                price_next = self.data.close[1]  # 明天的收盘价

                actual_up = 1 if price_next > price_today else 0
                predicted_up = 1 if prob_up > self.threshold and prob_up > prob_down and prob_up > prob_med and not self.is_end_of_day() and not self.day_break and not self.week_break else 0
                correct = predicted_up == actual_up

                current_date = self.data.datetime.date(0)
                last_date = self.data._dataname.index[-1].date()

                if last_date - current_date <= timedelta(days=30):
                    self.last_30_results.append(correct)

                if prob_up > self.threshold and prob_up > prob_down and prob_up > prob_med and not self.is_end_of_day() and not self.day_break and not self.week_break:
                    self.prediction_results.append(correct)

                full_pred.append(correct)

                if not correct: color = "\033[91m"

                msg = f"P_up={prob_up:.2f}, P_down={prob_down:.2f}"

                # 定义action

                # prob -= 0.35


                if prob_up > self.threshold and prob_up > prob_down and prob_up > prob_med and not self.is_end_of_day() and not self.day_break and not self.week_break:
                    # 需要买入
                    # to_buy = min(int((prob_up - self.threshold) * 200), 25)
                    # self.buy(size=to_buy)
                    # msg += ", Buy " + str(to_buy)
                    self.buy_full_position()
                    # self.buy_half_position()

                # elif prob_down > self.threshold:
                #     to_sell = min(int((prob_down - self.threshold) * 160), 25)
                #     self.sell(size=min(self.position.size, to_sell))

                    # best
                    # to_sell = min((prob_down - self.threshold) * 1000, 50)
                    # self.buy(size=min(self.position.size, to_sell))


                    # self.sell(size=min(self.position.size, prob_down * 100))
                    # self.close()
                else:
                    # to_sell = min(int((prob_down - self.threshold) * 100), 15)
                    # self.sell(size=min(self.position.size, to_sell))
                    self.close()


                if DEBUG_MODE_DETAIL:
                    try:
                        print(color
                                + f"{self.data.datetime.date(0)} \t| {self.data.close[0]:.2f} \t| {self.data.close[1]:.2f} \t| {msg:<30} \t| Position: {self.position.size} \t| Value: ${self.current_value:.2f}"
                                + f" \t| {sum(self.prediction_results)} / {len(self.prediction_results)} \t| {sum(self.prediction_results) / len(self.prediction_results) * 100:.4f}%" + "\033[0m"
                              )
                    except Exception as e:
                        pass


            except Exception as e:
                # 最后一根 K 线没有 t+1，跳过
                print(e)
                # self.predict_next = prob_up


        if DEBUG_MODE:
            if self.is_end_of_day():

                color = "\033[92m"
                # 记录当天策略是否有效
                no_action_rec = self.begin_of_day_position *  self.data.close[0] + self.begin_of_day_cash
                if self.current_value < no_action_rec:
                    color = "\033[91m"
                strategy_win_rate = (self.current_value - no_action_rec) / no_action_rec
                self.effective_days.append(strategy_win_rate > 0)


                # 记录当天是否赚钱
                win_rate = (self.current_value - self.last_day_value) / self.last_day_value
                if win_rate != 0:
                    self.win_days.append(win_rate > 0)

                if self.prediction_results and self.win_days:

                    print(color + (
                        f"{self.data.datetime.date(-1)} "
                        f"| 💰 Open: {self.start_day_price:>7.2f} "
                        f"| 💰 Close: {self.data.open[0]:>7.2f} "
                        f"| 📊 Max Pos: {self.max_position:>3} "
                        f"| 💼 Value: ${self.current_value:>9.2f} "
                        f"| ✅ Prof: {win_rate * 100:>5.2f}% \t\t "
                        # f"| ✅ Strategy: {strategy_win_rate * 100:>5.2f}% \t\t "
                            f"| 🟢 Prof. days: {sum(self.win_days):>2}/{len(self.win_days):<2} ({sum(self.win_days) / len(self.win_days) * 100:>5.2f}%) "
                        f"| 🔍 Eff. days: {sum(self.effective_days):>2}/{len(self.effective_days):<2} ({sum(self.effective_days) / len(self.effective_days) * 100:>5.2f}%) "
                        f"| 🧠 Pred. Acc:" + (" 0" if not self.prediction_results else f"{sum(self.prediction_results):>2}/{len(self.prediction_results):<2} ({sum(self.prediction_results) / len(self.prediction_results) * 100:>5.2f}%)") +
                        f"\033[0m"
                    ))

                self.last_day_value = self.broker.getvalue()

                self.begin_of_day_position = self.getposition().size
                self.begin_of_day_cash = self.broker.getcash()

            if self.is_end_of_week():
                color = "\033[92m"
                print()
                print("-- End of Week! Weekly report: -- ")

                no_action_rec = self.begin_of_week_position * self.data.close[0] + self.begin_of_week_cash

                if self.current_value < no_action_rec:
                    color = "\033[91m"

                strategy_win_rate = (self.current_value - no_action_rec) / no_action_rec
                self.effective_weeks.append(strategy_win_rate > 0)

                # 记录当天是否赚钱
                win_rate = (self.current_value - self.last_week_value) / self.last_week_value
                self.win_weeks.append(win_rate > 0)

                if self.prediction_results:
                    print(color + (
                        f"{self.data.datetime.date(-1)} "
                        f"| 💰 Open: {self.data.open[0]:>7.2f} "
                        f"| 💰 Close: {self.data.close[0]:>7.2f} "
                        f"| 📊 Pos: {self.position.size:>3} "
                        f"| 💼 Value: ${self.current_value:>9.2f} "
                        f"| ✅ Win: {win_rate * 100:>5.2f}% \t\t "
                        f"| ✅ Strategy: {strategy_win_rate * 100:>5.2f}% \t\t "
                        f"| 🟢 Prof. weeks: {sum(self.win_weeks):>2}/{len(self.win_weeks):<2} ({sum(self.win_weeks) / len(self.win_weeks) * 100:>5.2f}%) "
                        f"| 🔍 Eff. weeks: {sum(self.effective_weeks):>2}/{len(self.effective_weeks):<2} ({sum(self.effective_weeks) / len(self.effective_weeks) * 100:>5.2f}%) "
                        f"| 🧠 Pred. Acc: {sum(self.prediction_results):>2}/{len(self.prediction_results):<2} ({sum(self.prediction_results) / len(self.prediction_results) * 100:>5.2f}%)"
                        f"\033[0m"
                    ))
                self.last_week_value = self.broker.getvalue()
                self.begin_of_week_position = self.getposition().size
                self.begin_of_week_cash = self.broker.getcash()

                print()

            if self.is_end_of_month():
                color = "\033[92m"
                print()
                print("-- End of Month!  Monthly report: -- --")
                no_action_rec = self.begin_of_month_position * self.data.close[0] + self.begin_of_month_cash
                if self.current_value < no_action_rec:
                    color = "\033[91m"
                strategy_win_rate = (self.current_value - no_action_rec) / (no_action_rec + 0.001)
                self.effective_months.append(strategy_win_rate > 0)

                # 记录当天是否赚钱
                win_rate = (self.current_value - self.last_month_value) / self.last_month_value
                if win_rate != 0:
                    self.win_months.append(win_rate > 0)

                if self.prediction_results and self.win_months:
                    print(color + (
                        f"{self.data.datetime.date(-1)} "
                        f"| 💰 Open: {self.start_day_value:>7.2f} "
                        f"| 💰 Close: {self.data.close[0]:>7.2f} "
                        f"| 📊 Pos: {self.position.size:>3} "
                        f"| 💼 Value: ${self.current_value:>9.2f} "
                        f"| ✅ Win: {win_rate * 100:>5.2f}% \t\t "
                        f"| ✅ Strategy: {strategy_win_rate * 100:>5.2f}% \t\t "
                        f"| 🟢 Prof. months: {sum(self.win_months):>2}/{len(self.win_months):<2} ({sum(self.win_months) / len(self.win_months) * 100:>5.2f}%) "
                        f"| 🔍 Eff. months: {sum(self.effective_months):>2}/{len(self.effective_months):<2} ({sum(self.effective_months) / len(self.effective_months) * 100:>5.2f}%) "
                        f"| 🧠 Pred. Acc: {sum(self.prediction_results):>2}/{len(self.prediction_results):<2} ({sum(self.prediction_results) / len(self.prediction_results) * 100:>5.2f}%)"
                        f"\033[0m"
                    ))
                self.last_month_value = self.broker.getvalue()

                self.begin_of_month_position = self.getposition().size
                self.begin_of_month_cash = self.broker.getcash()
                print()


    def stop(self):

        # 计算预测准确率
        accuracy_predict, correct_predict, total_predict = compute_accuracy(self.prediction_results)
        accuracy_last_30, correct_last_30, total_last_30 = compute_accuracy(self.last_30_results)


        print(
            # f"Share: {self.features[0]:<7} | "
            f"Features: {str(self.features):<100} | "
            f"Drawdown: {self.max_drawdown * 100:>10.2f}% | "
            # f"Open: {self.start_pred:>8.2f} | "
            # f"Close: {self.data.close[0]:>8.2f} | " 
            f"Prediction accuracy: {accuracy_predict * 100:>6.2f}% ({correct_predict:>3}/{total_predict:<3}) | "
            + colorize_qty(round(accuracy_predict * 100, 2)) +
            # f"Action accuracy: {accuracy_action * 100:>6.2f}% ({correct_action:>3}/{total_action:<3}) | "
            # f"Last 30 accuracy: {accuracy_last_30 * 100:>6.2f}% ({correct_last_30:>2}/{total_last_30:<2}) | "
            f"\tValue:" + colorize_value(round(self.broker.getvalue(), 2))
            # f"Predict next: {self.predict_next:>5.2f}"
        )

        # if accuracy_predict > 0.53 or self.broker.getvalue() > 13000:
        if self.max_drawdown < 0.2 or accuracy_predict > 0.55 or self.broker.getvalue() > 9500:
            line = (
                    f"Features: {str(self.features):<100} | "
                    f"Drawdown: {self.max_drawdown * 100:>10.2f}% | "
                    f"Prediction accuracy: {accuracy_predict * 100:>6.2f}% ({correct_predict:>3}/{total_predict:<3}) | "
                    + str(round(accuracy_predict * 100, 2)) +
                    f"\tValue:" + str(round(self.broker.getvalue(), 2))
            )
            # 写入文件（追加模式）
            with open("selected_features_log.txt", "a", encoding="utf-8") as f:
                f.write(line + "\n")




# === Step 3: 运行回测 ===
import random

def get_random_feature_subset(feature_list, min_size=1, max_size=4):
    """
    从特征列表中随机选择一个组合，返回子集
    """
    size = random.randint(min_size, min(max_size, len(feature_list)))
    subset = random.sample(feature_list, size)
    return subset


import itertools
import random

def generate_shuffled_feature_combinations(features, n):
    """
    从 features 中生成所有长度为 n 的组合，并打乱顺序

    参数:
        features (list): 特征名列表
        n (int): 组合中元素个数

    返回:
        list of tuples: 打乱顺序的所有特征组合
    """
    combinations = list(itertools.combinations(features, n))
    combinations = [list(c) for c in combinations]  # 转换为 list
    random.shuffle(combinations)
    return combinations


def run_backtest(share_code, csv_path, start_date, end_date, strategy_class, init_features):
    # 加载CSV数据
    df = pd.read_csv(csv_path, parse_dates=True, index_col=0)

    df["datetime"] = pd.to_datetime(df["timestamp"])
    df = df.set_index("datetime")

    start = pd.to_datetime(start_date).tz_localize('UTC')
    end = pd.to_datetime(end_date).tz_localize('UTC')
    df = df[(df.index >= start) & (df.index <= end)]

    data = bt.feeds.PandasData(dataname=df)

    # 设置Cerebro
    cerebro = bt.Cerebro()
    cerebro.adddata(data)
    cerebro.addstrategy(strategy_class, share_code=share_code, init_features=init_features, data_df=df)
    cerebro.broker.setcash(30000.0)

    alpaca_commission = AlpacaCommission()
    cerebro.broker.addcommissioninfo(alpaca_commission)

    # 添加分析器
    cerebro.addanalyzer(bt.analyzers.DrawDown, _name='drawdown')
    cerebro.addanalyzer(bt.analyzers.PyFolio, _name='pyfolio')

    # 回测
    results = cerebro.run()
    strat = results[0]

    print()

run_backtest(
    share_code="TQQQ",
    csv_path=r"~/work/projects/quant/back_trade/TQQQ_15min_session.csv",
    start_date='2021-01-07',
    end_date='2025-05-16',
    strategy_class=MLShortStrategy,
    init_features=[]
)




def run_backtest1():

    base_features = [
        'boll_width', 'Close'
    ]


    chosed_features = [
        "Close", "Volume", "sma_10", "rsi_14", "macd_diff", "atr_14", "vwap",
        "Open", "High", "Low",
        "sma_3", "momentum_3", "std_10", 'volume_change',
        "macd", "macd_signal",
        "boll_width", "adx", "cci_20",
        "roc_10", "stoch_k", "stoch_d", "obv",
        "is_open", "is_mid", "is_close",
        "price_vs_high", "price_vs_low", "gap_open", "candle_body"
    ]

    # TQQQ
    # chosed_features = ['is_open', 'momentum_3', 'Close', 'gap_open', 'macd_signal', 'Low', 'macd_diff', 'adx',
    #                     'Volume', 'price_vs_high', 'is_close', 'volume_change', 'gap_open', 'macd', 'price_vs_low',
    #                     'stoch_k', 'roc_10', 'sma_10']


    # price_vs_high roc_10

    share_code = "TQQQ"
    # df = prepare_data(share_code, "15m", "60d")
    df = prepare_data_from_csv(share_code, "15m")

    # df_bt = df[["open", "high", "low", "close", "volume"]].copy()
    df_bt = df[["Open", "High", "Low", "Close", "Volume"]].copy()
    df_bt.columns = df_bt.columns.str.lower()
    df_bt.index.name = "datetime"

    data = bt.feeds.PandasData(dataname=df_bt)

    while True:
    # for i in [2, 3, 4]:
    #  for base_features in generate_shuffled_feature_combinations(chosed_features, i):

        cerebro = bt.Cerebro()
        cerebro.adddata(data)
        # subset = []# get_random_feature_subset(chosed_features, min_size=1, max_size=10)
        subset = get_random_feature_subset(chosed_features, min_size=2, max_size=4)

        cerebro.addstrategy(MLShortStrategy, share_code=share_code, features=list(set(base_features + subset)))
        cerebro.broker.setcash(10000)
        cerebro.broker.setcommission(commission=0.001)
        cerebro.run()

        break


    total_predict = len(full_pred)
    correct_predict = sum(full_pred)
    accuracy_predict = correct_predict / total_predict if total_predict > 0 else 0.0

    total_action = len(full_action)
    correct_action = sum(full_action)
    accuracy_action = correct_action / total_action if total_action > 0 else 0.0

    print(
          f"Full prediction accuracy: {accuracy_predict*100:.2f}% ({correct_predict}/{total_predict}) \t"
          f"Full action accuracy: {accuracy_action*100:.2f}% ({correct_action}/{total_action}) \t"
    )

    # cerebro.plot()

# if __name__ == "__main__":
#     run_backtest()
#     print(pick)