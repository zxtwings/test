import pandas as pd
from datetime import time
import pytz

def filter_alpaca_intraday(input_csv, output_csv,
                            start_time='09:30', end_time='16:00',
                            exchange_tz='US/Eastern'):
    """
    过滤 Alpaca 下载的 UTC 时间戳数据，只保留盘中（如美股9:30-16:00 ET）的K线，并保存到文件

    参数:
        input_csv (str): 原始含夜盘的CSV文件路径
        output_csv (str): 输出仅盘中的CSV文件路径
        start_time (str): 盘中开始时间（本地交易所时区，如 '09:30'）
        end_time (str): 盘中结束时间（如 '16:00'）
        exchange_tz (str): Alpaca对应市场的时区（默认美股东部时间）
    """
    # 1. 读取数据，Alpaca 默认时间戳为 UTC
    df = pd.read_csv(input_csv, parse_dates=['timestamp'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], utc=True)

    # 2. 转换为交易所本地时区（如 ET）
    df['local_time'] = df['timestamp'].dt.tz_convert(exchange_tz)

    # 3. 提取时间部分
    df['time'] = df['local_time'].dt.time

    # 4. 转换字符串为时间对象
    start = time.fromisoformat(start_time)
    end = time.fromisoformat(end_time)

    # 5. 保留交易时间内的数据
    df_filtered = df[(df['time'] >= start) & (df['time'] < end)]

    # 6. 可选：去除周末
    df_filtered = df_filtered[df_filtered['local_time'].dt.weekday < 5]

    # 7. 删除中间列，仅保留原数据结构（如你愿意可保留local_time）
    df_filtered = df_filtered.drop(columns=['time', 'local_time'])

    # 8. 保存结果
    df_filtered.to_csv(output_csv, index=False)
    print(f"✅ 保存完毕：仅盘中数据 → {output_csv}")

filter_alpaca_intraday(r"alpaca_data/TQQQ_20200101_20250521_5m_entire.csv", "TQQQ_5min_session.csv")
