import os.path

from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame, TimeFrameUnit
import pandas as pd
from datetime import datetime, timedelta
from alpaca.data.enums import DataFeed


from config import API_KEY, SECRET_KEY, BASE_URL
# === 替换成你的 API key ===


client = StockHistoricalDataClient(API_KEY, SECRET_KEY)

# 时间范围：过去 2 年
end_date = datetime.now() - timedelta(minutes=30)
start_date = end_date - timedelta(days=770)

# 分页时间跨度（每次取 30 天）
step = timedelta(days=30)

# 存储所有结果
all_data = []

share = "TQQQ"


# 分页请求数据
current_start = start_date
print(f"开始抓取 " + share + " 的 15 分钟数据（分页）...")

timeframe_15min = TimeFrame(15, TimeFrameUnit.Minute)

while current_start < end_date:
    current_end = min(current_start + step, end_date)

    print(f"抓取区间：{current_start.date()} 到 {current_end.date()}")
    try:
        request_params = StockBarsRequest(
            symbol_or_symbols=share,
            timeframe=timeframe_15min,
            start=current_start,
            # feed='iex',  # ✅ 仅盘中数据（关键）
            end=current_end
        )
        bars = client.get_stock_bars(request_params).df

        if not bars.empty:
            df = bars[bars.index.get_level_values("symbol") == share]
            all_data.append(df)

    except Exception as e:
        print(f"抓取失败：{e}")

    current_start = current_end  # 下一段

# 合并所有数据
if all_data:
    full_df = pd.concat(all_data)

    full_df.to_csv(share + "_15min_entire_day.csv")
    print("✅ 数据已保存到 SQQQ_15min_entire_day.csv")
else:
    print("❌ 没有获取到任何数据，请检查 API key、权限或时间段")