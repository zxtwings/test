import numpy as np
from lightgbm import LGBMClassifier
from xgboost import XGBClassifier
from catboost import CatBoostClassifier
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis

class MultiModelTrainerDaily:
    def __init__(self, random_state=42):
        self.models = []
        self._init_models(random_state)

    def _init_models(self, random_state):

        # self.models.append(LGBMClassifier(
        #     n_estimators=200,
        #     max_depth=4,
        #     learning_rate=0.05,
        #     subsample=0.8,
        #     colsample_bytree=0.8,
        #     random_state=random_state,
        #     verbose=-1,
        #     n_jobs=1
        # ))  # ['volume_change', 'Open']  +53.91	Value:+10492.61
        self.models.append(LGBMClassifier(
            n_estimators=150,
            max_depth=-1,
            learning_rate=0.06,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            verbose=-1,
            n_jobs=1
        ))  # ['price_vs_high', 'roc_10']   +49.45	Value:+12766.95
        # initial_lgbm_params = {
        #     'objective': 'multiclass',  # 明确指定为多分类问题
        #     'metric': 'multi_logloss',  # 多分类常用的损失函数，也可以用 'multi_error'
        #     'num_class': 3,  # 类别数量："涨", "平", "跌"
        #
        #     'boosting_type': 'gbdt',  # 传统的梯度提升决策树
        #     'n_estimators': 500,  # 初始迭代次数，建议配合早停使用
        #     'learning_rate': 0.05,  # 学习率，较小的值通常需要更多的 n_estimators
        #
        #     'num_leaves': 31,  # 每棵树的叶子数量，是控制复杂度的关键参数之一
        #     'max_depth': -1,  # 树的最大深度，-1表示不限制 (num_leaves 更直接)
        #     'min_child_samples': 20,  # 一个叶子节点上最少需要的样本数，防止过拟合
        #
        #     'subsample': 0.8,  # 行采样比例 (bagging_fraction)，随机选择80%的数据训练每棵树
        #     'colsample_bytree': 0.8,  # 列采样比例 (feature_fraction)，随机选择80%的特征构建每棵树
        #
        #     'reg_alpha': 0.1,  # L1 正则化系数
        #     'reg_lambda': 0.1,  # L2 正则化系数
        #
        #     'random_state': 42,  # 随机种子，保证结果可复现
        #     'n_jobs': -1,  # 使用所有可用的CPU核心
        #     'verbose': -1,  # 控制训练过程中的信息输出，-1为不输出
        #
        #     # 处理类别不平衡 (非常重要，因为您的阈值可能导致类别不平衡)
        #     'class_weight': 'balanced'  # Scikit-Learn接口中，'balanced'会自动调整权重
        #     # 或者，您可以传入一个字典，例如：{0: w_跌, 1: w_平, 2: w_涨}
        #     # 如果使用原生API，可能是 is_unbalance=True (但主要对二分类有效)
        # }
        # self.models.append(LGBMClassifier(**initial_lgbm_params))  # ['price_vs_high', 'roc_10']   +49.45	Value:+12766.95

        # self.models.append(LGBMClassifier(
        #     objective="multiclass",         # 明确为多分类任务（如你预测涨/横/跌）
        #     num_class=3,                    # 3 类（0/1/2）
        #
        #     n_estimators=200,              # 更多树以更充分拟合短期模式
        #     max_depth=5,                   # 可稍加深，提升模型容量
        #     learning_rate=0.03,            # 降低学习率提高泛化能力
        #     subsample=0.8,                 # 保持对样本的随机性（防止过拟合）
        #     colsample_bytree=0.7,          # 稍降特征采样比例，增强鲁棒性
        #
        #     min_child_samples=20,          # 每棵叶子最小样本数，防过拟合
        #     reg_alpha=1.0,                 # L1 正则（可惩罚不重要特征）
        #     reg_lambda=1.0,                # L2 正则
        #
        #     importance_type='gain',        # 重要性评估方式
        #     random_state=random_state,
        #     verbose=-1,
        #     n_jobs=-1
        # )) # 0.5099 10016

        # self.models.append(RandomForestClassifier(
        #     n_estimators=150, max_depth=3, random_state=random_state, n_jobs=1)) # 0.5188 9652

        # self.models.append(LogisticRegression(max_iter=1000)) # 0.4982 10713
        #
        # self.models.append(XGBClassifier(
        #     n_estimators=100, max_depth=4, learning_rate=0.05,
        #     eval_metric="logloss"))
        #
        # self.models.append(CatBoostClassifier(
        #     iterations=100, depth=4, learning_rate=0.05, verbose=0)) # 0.4982 9949

        # self.models.append(KNeighborsClassifier(n_neighbors=5, weights="distance")) # 0.4989 10540
        #
        # self.models.append(GaussianNB()) # 0.4893 9844
        #
        # self.models.append(ExtraTreesClassifier(
        #     n_estimators=200, max_depth=6, random_state=random_state, n_jobs=1)) #0.5151 9480
        #
        # self.models.append(GradientBoostingClassifier(
        #     n_estimators=150, max_depth=4, learning_rate=0.05, random_state=random_state)) # 0.5041 7762

        # self.models.append(MLPClassifier(
        #     hidden_layer_sizes=(64, 32), activation='relu',
        #     max_iter=500, early_stopping=True, random_state=random_state)) # 0.4974 9890

        # self.models.append(QuadraticDiscriminantAnalysis(reg_param=0.01)) # 0.5129 7715

    def fit(self, X_train, y_train):
        for model in self.models:
            model.fit(X_train, y_train)

    def predict_prob(self, features):
        prob = 0
        for model in self.models:

            probs = model.predict_proba(features)
            p_up = probs[0][2]  # 类别2 = 上涨
            p_down = probs[0][0]  # 类别0 = 下跌
            confidence = p_up - p_down  # [-1, 1] 区间，越接近 +1 越强烈看涨
            prob += confidence
        prob /= len(self.models)
        return prob


    def valid(self, features):
        # 初始化三类概率之和
        """
        features: pd.DataFrame or np.ndarray of shape (N, D)
        return: list of predicted class labels (0, 1, 2) for each row
        """
        n_samples = len(features)
        n_classes = 3
        prob_sum = np.zeros((n_samples, n_classes))

        for model in self.models:
            probs = model.predict_proba(features)  # shape: (N, 3)
            prob_sum += probs  # 累加每个类别的概率

        avg_probs = prob_sum / len(self.models)  # shape: (N, 3)
        predicted_classes = np.argmax(avg_probs, axis=1)  # 取最大概率对应的类

        return predicted_classes.tolist()