import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from scipy.stats import mode
from sklearn.metrics import accuracy_score, classification_report
import joblib

from back_trade.back_test_feature_engine.feature_engine_short import FeatureEngine


def get_best_model(df, current_date, valid_days=30):
    """
    根据历史数据训练多个不同窗口的模型，并返回在验证集上表现最好的模型

    参数:
        df: 包含特征和目标的数据框(必须包含datetime索引和target列)
        current_date: 字符串或datetime对象，表示当前日期(如"2022-02-01")
        valid_days: 验证集天数，默认为30天

    返回:
        best_model: 验证集上表现最好的模型
        best_score: 该模型在验证集上的准确率
        all_scores: 所有模型的评分列表(包含窗口信息和分数)
    """

    df = df.copy()

    # 确保所有日期时间对象都是时区无关的
    current_date = pd.to_datetime(current_date).tz_localize(None) - pd.Timedelta(minutes=5)
    df.index = pd.to_datetime(df.index).tz_localize(None)

    # 1. 定义验证窗口 (当前日期之前的valid_days天)
    valid_end = current_date
    valid_start = current_date - pd.Timedelta(days=valid_days)

    valid_start_near = current_date - pd.Timedelta(days=7)

    # 2. 自动生成训练窗口 (从验证窗口开始时间往前计算)
    train_windows = []
    train_end = valid_start  # 训练窗口结束于验证窗口开始前

    # 生成不同长度的训练窗口
    window_sizes = [
        # pd.Timedelta(days=120),  # 2个月
        pd.Timedelta(days=60),  # 6个月
        pd.Timedelta(days=90),  # 6个月
        pd.Timedelta(days=180),  # 6个月
        pd.Timedelta(days=270),  # 6个月
        pd.Timedelta(days=365),  # 1年
        pd.Timedelta(days=730),  # 2年
        pd.Timedelta(days=1095)  # 2年
    ]

    for window_size in window_sizes:
        train_start = train_end - window_size
        if train_start >= df.index.min():  # 确保有足够数据
            train_windows.append((train_start, train_end))

    # # 添加滚动窗口 (每月一个2个月窗口)
    # for months in range(0, 24, 1):  # 最多滚动24个月
    #     train_start = train_end - pd.Timedelta(days=60) - pd.Timedelta(days=30 * months)
    #     train_end_roll = train_start + pd.Timedelta(days=60)
    #     if train_start >= df.index.min() and train_end_roll <= train_end:
    #         train_windows.append((train_start, train_end_roll))


    # 添加滚动窗口 (每月一个2个月窗口)
    for months in range(0, 36, 2):  # 最多滚动24个月
        train_start = train_end - pd.Timedelta(days=90) - pd.Timedelta(days=30 * months)
        train_end_roll = train_start + pd.Timedelta(days=90)
        if train_start >= df.index.min() and train_end_roll <= train_end:
            train_windows.append((train_start, train_end_roll))


    # 添加滚动窗口 (每月一个2个月窗口)
    for months in range(0, 36, 3):  # 最多滚动24个月
        train_start = train_end - pd.Timedelta(days=180) - pd.Timedelta(days=30 * months)
        train_end_roll = train_start + pd.Timedelta(days=180)
        if train_start >= df.index.min() and train_end_roll <= train_end:
            train_windows.append((train_start, train_end_roll))

    # 去重并排序
    train_windows = sorted(list(set(train_windows)), key=lambda x: x[0])

    # 3. 准备验证集
    valid_df = df.loc[valid_start:valid_end]
    valid_df_near = df.loc[valid_start_near:valid_end]

    # 自动排除不需要的列
    exclude_cols = ["target", "timestamp", "future_return", "future_close", "future_open"]
    features = [col for col in df.columns if col not in exclude_cols]

    X_valid = valid_df[features]
    y_valid = valid_df["target"]

    X_valid_near = valid_df_near[features]
    y_valid_near = valid_df_near["target"]

    # 4. 训练和评估模型
    model_scores = []

    for i, (start, end) in enumerate(train_windows):
        # 获取训练数据
        train_df = df.loc[start:end]

        # 检查数据是否足够
        if len(train_df) < 100:  # 最小样本数阈值
            continue

        X_train = train_df[features]
        y_train = train_df["target"]

        # 训练模型

        try:

            # model = LGBMClassifier(
            #     n_estimators=10000,
            #     learning_rate=0.01,
            #     max_depth=4,
            #     subsample=0.8,
            #     colsample_bytree=0.8,
            #     random_state=42,
            #     num_leaves=127,  # 公式：min(2^(max_depth)-1, 127)
            #     feature_fraction=0.5,
            #     bagging_freq=5,
            #     bagging_fraction=0.6,
            #     min_data_in_leaf=200,  # 针对5分钟数据特性
            #     verbose=-1,
            #     class_weight="balanced",
            # )

            model = LGBMClassifier(
                n_estimators=10000,
                learning_rate=0.01,
                max_depth=1,
                subsample=0.8,
                colsample_bytree=0.8,
                random_state=42,
                num_leaves=127,  # 公式：min(2^(max_depth)-1, 127)
                feature_fraction=0.3,
                bagging_freq=5,
                bagging_fraction=0.6,
                min_data_in_leaf=400,  # 针对5分钟数据特性
                lambda_l1=0.01,
                lambda_l2=0.01,
                verbose=-1,
                class_weight="balanced",
                # path_smooth= 10,
            )

            model.fit(
                X_train, y_train,
                eval_set=[(X_valid, y_valid)],
                callbacks=[
                        early_stopping(stopping_rounds=100, verbose=False),
                        log_evaluation(period=0)  # 👈 不输出任何训练过程日志
                ]
            )

            # 评估模型
            y_pred_valid = model.predict(X_valid)
            acc_valid1 = accuracy_score(y_valid, y_pred_valid)

            model = LGBMClassifier(
                n_estimators=10000,
                learning_rate=0.02,
                max_depth=4,
                subsample=0.8,
                colsample_bytree=0.8,
                random_state=42,
                num_leaves=127,  # 公式：min(2^(max_depth)-1, 127)
                feature_fraction=0.5,
                bagging_freq=5,
                bagging_fraction=0.6,
                min_data_in_leaf=200,  # 针对5分钟数据特性
                verbose=-1,
            )
            model.fit(
                X_train, y_train,
                eval_set=[(X_valid_near, y_valid_near)],
                callbacks=[
                        early_stopping(stopping_rounds=100, verbose=False),
                        log_evaluation(period=0)  # 👈 不输出任何训练过程日志
                ]
            )

            # 评估模型
            y_pred_valid_near = model.predict(X_valid_near)
            acc_valid2 = accuracy_score(y_valid_near, y_pred_valid_near)

            # print(acc_valid1, acc_valid2)

            if acc_valid2 > 0.40 and acc_valid2 + acc_valid1 > 0.8:
                # 存储结果
                model_scores.append({
                    "model_index": i,
                    "window_start": start,
                    "window_end": end,
                    "window_size": (end - start).days,
                    "accuracy": acc_valid2 + acc_valid1,
                    "accuracy_near": acc_valid2,
                    "model": model
                })

        except Exception as e:
            print(f"训练窗口 {start.date()} 到 {end.date()} 失败: {str(e)}")
            continue

    if not model_scores:
        # raise ValueError("没有成功训练任何模型，请检查数据和时间范围")
        print("没有成功训练任何模型，请检查数据和时间范围")
        return None, []

    # 5. 找出表现最好的模型
    best_model_info = max(model_scores, key=lambda x: x["accuracy"])

    best_model = best_model_info["model"]
    best_score = best_model_info["accuracy"]
    best_score_near = best_model_info["accuracy_near"]

    # 打印所有模型表现
    # print(f"验证窗口: {valid_start.date()} → {valid_end.date()} ({valid_days}天)")
    # # print("\n📊 所有模型在验证集上的表现:")
    # # for info in sorted(model_scores, key=lambda x: x["window_size"]):
    # #     print(f"训练窗口 {info['window_size']:4} 天 | {info['window_start'].date()} → {info['window_end'].date()} "
    # #           f"| 准确率: {info['accuracy']:.2%}")
    #
    # print(f"\n🏆 最佳模型: {best_model_info['window_size']} 天窗口 "
    #       f"({best_model_info['window_start'].date()} → {best_model_info['window_end'].date()})")
    # print(f"验证集准确率: {best_score:.2%}")
    #

    print(f"验证窗口: {valid_start.date()} → {valid_end.date()} ({valid_days}天)"
            f"🏆 最佳模型: {best_model_info['window_size']} 天窗口 "
            f"({best_model_info['window_start'].date()} → {best_model_info['window_end'].date()})"
            f" 验证集准确率: {best_score:.2%}"
            f" 验证集准确率: {best_score_near:.2%}")

    model_scores.sort(key=lambda x: x["accuracy"])
    top_5_models = [m["model"] for m in model_scores[::-1][:5]]

    return best_model, top_5_models

if __name__ == "__main__":
    df = pd.read_csv("TQQQ_5min_session.csv", parse_dates=True, index_col=0)
    df["datetime"] = pd.to_datetime(df["timestamp"])
    df = df.set_index("datetime")
    df = df.sort_index()
    engine = FeatureEngine()

    df = engine.enrich_features_5min(df)
    df = df.dropna()

    best_model, top_5_models = get_best_model(df, "2024-09-02")

    test_df = df.loc["2024-09-03":"2024-09-10"]

    exclude_cols = ["target", "timestamp", "future_return", "future_close", "future_open_1"]
    features = [col for col in df.columns if col not in exclude_cols]

    X_test = test_df[features]
    y_test = test_df["target"]

    y_pred_test = best_model.predict(X_test)
    acc_valid = accuracy_score(y_test, y_pred_test)
    print(classification_report(y_test, y_pred_test))
    print(acc_valid)

    # 得到每个模型的预测

    print("Top 5")
    y_pred_test_list = [model.predict(X_test) for model in top_5_models]
    y_preds = np.array(y_pred_test_list)

    # 多数投票
    y_pred_ensemble = mode(y_preds, axis=0).mode

    acc_valid = accuracy_score(y_test, y_pred_ensemble)
    print("===== Ensemble (Voting) Result =====")
    print(classification_report(y_test, y_pred_ensemble))
    print(f"Accuracy: {acc_valid:.4f}")


    y_probas = np.array([model.predict_proba(X_test) for model in top_5_models])  # shape = (3, n_samples, n_classes)
    y_proba_mean = np.mean(y_probas, axis=0)  # shape = (n_samples, n_classes)
    y_pred_ensemble = np.argmax(y_proba_mean, axis=1)  # 分类结果


    acc_valid = accuracy_score(y_test, y_pred_ensemble)
    print("===== Ensemble (Voting) Result =====")
    print(classification_report(y_test, y_pred_ensemble))
    print(f"Accuracy: {acc_valid:.4f}")


    print("Top 3")
    y_pred_test_list = [model.predict(X_test) for model in top_5_models[:3]]
    y_preds = np.array(y_pred_test_list)

    # 多数投票
    y_pred_ensemble = mode(y_preds, axis=0).mode

    acc_valid = accuracy_score(y_test, y_pred_ensemble)
    print("===== Ensemble (Voting) Result =====")
    print(classification_report(y_test, y_pred_ensemble))
    print(f"Accuracy: {acc_valid:.4f}")


    y_probas = np.array([model.predict_proba(X_test) for model in top_5_models[:3]])  # shape = (3, n_samples, n_classes)
    y_proba_mean = np.mean(y_probas, axis=0)  # shape = (n_samples, n_classes)
    y_pred_ensemble = np.argmax(y_proba_mean, axis=1)  # 分类结果


    acc_valid = accuracy_score(y_test, y_pred_ensemble)
    print("===== Ensemble (Voting) Result =====")
    print(classification_report(y_test, y_pred_ensemble))
    print(f"Accuracy: {acc_valid:.4f}")

