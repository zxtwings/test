from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame, TimeFrameUnit
from datetime import datetime, timedelta
import pandas as pd
import os

from config import API_KEY, SECRET_KEY

client = StockHistoricalDataClient(API_KEY, SECRET_KEY)
step_days = 30

def download_alpaca_data(symbol: str, start_dt: datetime, end_dt: datetime,
                         timeframe: str = "1d", extended_hours: bool = False) -> pd.DataFrame:

    # 解析 timeframe
    unit_map = {
        "1m": (1, TimeFrameUnit.Minute),
        "5m": (5, TimeFrameUnit.Minute),
        "15m": (15, TimeFrameUnit.Minute),
        "1d": (1, TimeFrameUnit.Day),
        "1wk": (1, TimeFrameUnit.Week)
    }

    step = timedelta(days=30)

    if timeframe not in unit_map:
        raise ValueError(f"Unsupported timeframe '{timeframe}'. Choose from {list(unit_map.keys())}")

    tf = TimeFrame(*unit_map[timeframe])

    # 开始分页抓取
    all_data = []
    current_start = start_dt

    while current_start < end_dt:
        current_end = min(current_start + timedelta(days=step_days), end_dt)
        print(f"⏳ 抓取区间：{current_start.strftime('%Y-%m-%d %H:%M')} → {current_end.strftime('%Y-%m-%d %H:%M')}")

        try:
            request = StockBarsRequest(
                symbol_or_symbols=symbol,
                start=current_start,
                end=current_end,
                timeframe=tf,
                # feed='iex',  # ✅ 仅盘中数据（关键）
                feed='sip',
                adjustment='raw',
                extended_hours=extended_hours
            )

            bars = client.get_stock_bars(request).df

            if not bars.empty:
                df = bars[bars.index.get_level_values("symbol") == symbol]
                all_data.append(df)

        except Exception as e:
            print(f"❌ 抓取失败: {e}")

        current_start = current_end  # 更新到下一页

    if not all_data:
        print("⚠️ 未获取到任何数据")
        return pd.DataFrame()

    full_df = pd.concat(all_data).reset_index()
    print(f"✅ 下载完成，共获取 {len(full_df)} 行数据")
    return full_df

def download_by_string_date(symbol: str, start_str: str, # end_str: str,
                            timeframe: str = "1d", extended_hours: bool = False) -> pd.DataFrame:
    # 支持 "yy-mm-dd-hh-mm" 解析
    start_dt = datetime.strptime(start_str, "%y-%m-%d %H:%M")
    end_dt = datetime.utcnow() - timedelta(minutes=30)

    return download_alpaca_data(symbol, start_dt, end_dt, timeframe, extended_hours)



def download_and_save(symbol: str, start_dt: datetime, end_dt: datetime,
                      timeframe: str = "1d", extended_hours: bool = False,
                      output_dir: str = "./data"):
    df = download_alpaca_data(symbol, start_dt, end_dt, timeframe, extended_hours)

    # 文件命名规则：symbol_start_end_timeframe.csv
    fname = f"{symbol}_{start_dt.strftime('%Y%m%d')}_{end_dt.strftime('%Y%m%d')}_{timeframe}_"+("iex" if not extended_hours else "entire") + ".csv"
    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, fname)

    df.to_csv(filepath, index=False)
    print(f"✅ 数据已保存到：{filepath}")
    return filepath


# df = download_by_string_date("TQQQ", "25-05-01 06:30", timeframe="15m", extended_hours=True)
# print(df)


download_and_save(
    symbol="TQQQ",
    start_dt=datetime(2020, 1, 1, 6, 30),
    # end_dt=datetime(2025, 5, 30, 16, 0),
    end_dt=datetime.utcnow() - timedelta(minutes=30),
    timeframe="5m",
    extended_hours=True,
    output_dir="./alpaca_data"
)