import os.path

import yfinance as yf
import pandas as pd
import backtrader as bt
import numpy as np
from datetime import datetime, timedelta
from sklearn.ensemble import RandomForestClassifier
from lightgbm import LGBMClassifier
from glob import glob

DEBUG_MODE = True

full_pred = []
full_action = []

pick = []

# === Step 1: 下载数据并构造因子 ===
def prepare_data(tickers):
    df = yf.download(tickers, interval="1d", start="1900-01-01", end="2025-05-11", multi_level_index=False, progress=False)
    df = enrich_features(df)
    # df["return"] = df["Close"].pct_change().shift(-1)
    # df["target"] = (df["return"] > 0).astype(int)
    df["tomorrow_open"] = df["Open"].shift(-1)
    df["tomorrow_close"] = df["Close"].shift(-1)

    df["target"] = (df["tomorrow_close"] > df["tomorrow_open"]).astype(int)

    # df.dropna(inplace=True)
    return df

def enrich_features(df: pd.DataFrame) -> pd.DataFrame:
    # df["return"] = df["Close"].pct_change().shift(-1)
    # df["target"] = (df["tomorrow_close"] > df["tomorrow_open"]).astype(int)

    # 均线
    df["sma5"] = df["Close"].rolling(5).mean()
    df["sma20"] = df["Close"].rolling(20).mean()

    # RSI14
    delta = df["Close"].diff()
    up = delta.clip(lower=0)
    down = -delta.clip(upper=0)
    roll_up = up.rolling(14).mean()
    roll_down = down.rolling(14).mean()
    rs = roll_up / (roll_down + 1e-6)
    df["rsi14"] = 100 - (100 / (1 + rs))

    # 布林带
    sma20 = df["Close"].rolling(20).mean()
    std20 = df["Close"].rolling(20).std()
    df["bb_upper"] = sma20 + 2 * std20
    df["bb_lower"] = sma20 - 2 * std20

    # 波动率、动量、成交量均值
    df["volatility"] = df["Close"].rolling(10).std()
    df["momentum"] = df["Close"] / df["Close"].shift(5) - 1
    df["volume_mean"] = df["Volume"].rolling(5).mean()
    df["price_change"] = df["Close"] / df["Open"] - 1
    df["daily_range"] = df["High"] - df["Low"]

    # MACD
    ema12 = df["Close"].ewm(span=12, adjust=False).mean()
    ema26 = df["Close"].ewm(span=26, adjust=False).mean()
    df["macd"] = ema12 - ema26
    df["macd_signal"] = df["macd"].ewm(span=9, adjust=False).mean()

    # ROC
    df["roc"] = df["Close"].pct_change(periods=5)

    # Williams %R (14日)
    high14 = df["High"].rolling(14).max()
    low14 = df["Low"].rolling(14).min()
    df["willr"] = -100 * (high14 - df["Close"]) / (high14 - low14 + 1e-6)

    # On Balance Volume
    df["obv"] = (np.sign(df["Close"].diff()) * df["Volume"]).fillna(0).cumsum()

    # K线实体大小
    df["candle_body"] = df["Close"] - df["Open"]

    # 跳空幅度
    df["gap"] = df["Open"] / df["Close"].shift(1) - 1

    # VWAP 估算：近5天成交额 / 成交量
    df["vwap"] = (df["Close"] * df["Volume"]).rolling(5).sum() / df["Volume"].rolling(5).sum()
    df["vwap_ratio"] = df["Close"] / df["vwap"]

    # 滚动高低点
    df["rolling_max"] = df["High"].rolling(10).max()
    df["rolling_min"] = df["Low"].rolling(10).min()

    # df.dropna(inplace=True)
    return df


def compute_accuracy(results):
    total = len(results)
    correct = sum(results)
    accuracy = correct / total if total > 0 else 0.0
    return accuracy, correct, total



# === Step 2: 自定义策略 ===
class MLStrategy(bt.Strategy):
    def __init__(self, sharing_name):
        self.data_df = prepare_data(sharing_name)
        self.sharing_name = sharing_name
        self.current_day = None
        self.models = []
        self.lookback_days = 1  # 每次只滚动 1 天
        self.trained_dates = set()

        self.prediction_results = []
        self.last_30_results = []
        self.action_result = []

        self.start_pred = None
        self.end_pred = None
        self.predict_next = None

        self.features = [
            "sma5", "sma20",
            # "rsi14", "macd", "macd_signal", "roc", "willr", "obv",
            # "candle_body", "gap", "vwap_ratio", "momentum", "volatility",
            # "price_change", "daily_range", "rolling_max", "rolling_min"
        ]


    def next(self):
        date = pd.Timestamp(self.data.datetime.date(0))

        if date not in self.data_df.index or len(self.data.close) < 2:
            return

        # 每天更新模型：用前一日之前所有数据训练
        if date not in self.trained_dates and date > pd.Timestamp("2022-05-11"):

            if not self.start_pred:
                self.start_pred = self.data.close[0]

            train_df = self.data_df[self.data_df.index < date]
            if len(train_df) < 200:
                return
            X_train = train_df[self.features]
            y_train = train_df["target"]
            # self.back_test_model = RandomForestClassifier(n_estimators=1000)
            # self.back_test_model.fit(X_train, y_train)

            self.models = []
            for seed in [12, 42, 77]:
                model = LGBMClassifier(n_estimators=100, max_depth=5, random_state=seed, verbose=-1)
                model.fit(X_train, y_train)
                self.models.append(model)
            self.trained_dates.add(date)

        # 模型已就绪，预测明天
        if len(self.models) >= 1 :
            today_row = self.data_df.loc[date:date]
            if len(today_row) == 0:
                return
            features = today_row[self.features]

            prob = 0
            for model in self.models:
                prob += model.predict_proba(features)[0][1]
            prob /= 3

            color = "\033[92m"

            # 获取实际 next day 涨跌（t+1 close > t close）
            try:
                price_today = self.data.close[0]
                price_tomorrow = self.data.close[1]  # 明天的收盘价
                actual_up = 1 if price_tomorrow > price_today else 0
                predicted_up = 1 if prob > 0.5 else 0
                correct = predicted_up == actual_up

                current_date = self.data.datetime.date(0)
                last_date = self.data._dataname.index[-1].date()

                if last_date - current_date <= timedelta(days=30):
                    self.last_30_results.append(correct)

                if not correct:
                    color = "\033[91m"

                self.prediction_results.append(correct)

                full_pred.append(correct)

                msg = f"No action (P_up={prob:.2f})"  # 初始化空消息

                if prob > 0.6:
                    # self.buy(size=5)
                    size = self.buy_full_position()
                    correct = predicted_up == actual_up
                    self.action_result.append(correct)
                    full_action.append(correct)

                    msg = f"BUY {size} shares (P_up={prob:.2f})"

                else:
                    position_size = self.position.size  # 当前持仓数量
                    if position_size > 0:
                        self.sell(size=position_size)
                        msg = f"SELL shares (P_up={prob:.2f})"

                value = self.broker.getvalue()

                if DEBUG_MODE :
                    try:
                        print(color
                                + f"{self.data.datetime.date(0)} \t| {self.data.close[0]:.2f} \t| {self.data.close[1]:.2f} \t| {msg} \t| Position: {self.position.size} \t| Value: ${value:.2f}"
                                + f" \t| {sum(self.prediction_results)} / {len(self.prediction_results)} \t| {sum(self.prediction_results) / len(self.prediction_results):.2f}" + "\033[0m"
                              )
                    except Exception as e:
                        pass


            except IndexError:
                # 最后一根 K 线没有 t+1，跳过
                self.predict_next = prob
            # pred = self.back_test_model.predict(features)[0]
            # if pred == 1:
            #     self.buy()
            #     value = self.broker.getvalue()
            #     print(f"{self.data.datetime.date(0)} Buy {1} shares at {self.data.close[0]:.2f}   | Value: ${value:.2f}   | Position: {self.position.size}")
            #     # self.buy_full_position()
            # elif self.position and pred == 0:
            #     # self.sell()
            #     # value = self.broker.getvalue()
            #     # print(f"{self.data.datetime.date(0)} SELL {1} shares at {self.data.close[0]:.2f}  | Position: ${self.position.size}  | Value: ${value:.2f}")
            #     self.sell_full_position()

    def buy_full_position(self):
        price = self.data.close[0]
        cash = self.broker.getcash()
        size = int(cash / price)
        if size > 0:
            self.buy(size=size)
            # value = self.broker.getvalue()
            # print(f"{self.data.datetime.date(0)} Buy {size} shares at {self.data.close[0]:.2f}  | Value: ${value:.2f}")
        return size

    def sell_full_position(self):
        """
        Sell all current shares in the position.
        """
        if self.position:
            size = self.position.size  # 当前持仓数量（正值）
            self.sell(size=size)
            # value = self.broker.getvalue()
            # print(f"{self.data.datetime.date(0)} SELL {size} shares at {self.data.close[0]:.2f}  | Value: ${value:.2f}")

    def stop(self):

        # 计算预测准确率
        accuracy_predict, correct_predict, total_predict = compute_accuracy(self.prediction_results)
        accuracy_action, correct_action, total_action = compute_accuracy(self.action_result)
        accuracy_last_30, correct_last_30, total_last_30 = compute_accuracy(self.last_30_results)

        print(
            f"Share: {self.sharing_name:<7} | "
            f"Open: {self.start_pred:>8.2f} | "
            f"Close: {self.data.close[0]:>8.2f} | "
            f"Prediction accuracy: {accuracy_predict * 100:>6.2f}% ({correct_predict:>3}/{total_predict:<3}) | "
            f"Action accuracy: {accuracy_action * 100:>6.2f}% ({correct_action:>3}/{total_action:<3}) | "
            f"Last 30 accuracy: {accuracy_last_30 * 100:>6.2f}% ({correct_last_30:>2}/{total_last_30:<2}) | "
            f"Value: {self.broker.getvalue():>10.2f} | "
            f"Predict next: {self.predict_next:>5.2f}"
        )

        if accuracy_predict > 0.53 and accuracy_action > 0.53 and accuracy_last_30 > 0.6 and self.predict_next > 0.55:
            pick.append({
                "Share": self.sharing_name,
                "Prediction accuracy": round(accuracy_predict, 2),
                "Action accuracy": round(accuracy_action, 2),
                "Last 30 accuracy": round(accuracy_last_30, 2),
                "Value": round(self.broker.getvalue(), 2),
                "Predict next": round(self.predict_next, 2)
            })


# === Step 3: 运行回测 ===
def run_backtest():

    for sharing_name_path in glob(r"../sp500_data/*.csv"):

        print(sharing_name_path)
        cerebro = bt.Cerebro()
        sharing_name = os.path.basename(sharing_name_path)[:-4]

        # if sharing_name == "GILD":
        #     break

        sharing_name = "TQQQ"

        df = prepare_data(sharing_name)
        df_bt = df[["Open", "High", "Low", "Close", "Volume"]].copy()
        df_bt.index.name = "datetime"

        data = bt.feeds.PandasData(dataname=df_bt)
        cerebro.adddata(data)
        cerebro.addstrategy(MLStrategy, sharing_name=sharing_name)
        cerebro.broker.setcash(10000)
        cerebro.broker.setcommission(commission=0.001)
        cerebro.run()

        break

    total_predict = len(full_pred)
    correct_predict = sum(full_pred)
    accuracy_predict = correct_predict / total_predict if total_predict > 0 else 0.0

    total_action = len(full_action)
    correct_action = sum(full_action)
    accuracy_action = correct_action / total_action if total_action > 0 else 0.0

    print(
          f"Full prediction accuracy: {accuracy_predict*100:.2f}% ({correct_predict}/{total_predict}) \t"
          f"Full action accuracy: {accuracy_action*100:.2f}% ({correct_action}/{total_action}) \t"
    )

    # cerebro.plot()

if __name__ == "__main__":
    run_backtest()
    print(pick)