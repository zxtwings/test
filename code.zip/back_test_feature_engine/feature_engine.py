from datetime import time
import numpy as np
import pandas as pd
import talib

# ---------- 批量参数特征（如前述） ----------
ma_windows = [3, 5, 8, 13, 21, 34, 55]
momentum_windows = [1, 3, 5, 8, 13, 21, 34]
boll_windows = [8, 13, 21, 34, 55]
boll_multipliers = [1.5, 2, 2.618]
macd_params = [(5, 13, 3), (8, 21, 5), (12, 26, 9)]
osc_windows = [6, 9, 14, 21, 34]
atr_windows = [5, 8, 14, 21, 34]
vol_windows = [5, 10, 20, 34]
range_windows = [8, 13, 21, 34, 55]
kline_windows = [3, 5, 8, 13]


class FeatureEngine:
    def __init__(self, mode='auto'):
        """
        mode: '15min', 'daily', or 'auto'
        """
        self.mode = mode

    # ===== 15分钟特征 =====
    def _add_features(self, df):
        df = df.copy()

        # MA/EMA
        for win in ma_windows:
            df[f'sma_{win}'] = df['close'].rolling(win).mean()
            df[f'ema_{win}'] = df['close'].ewm(span=win, adjust=False).mean()

        # 动量
        for win in momentum_windows:
            df[f'mom_{win}'] = df['close'].pct_change(win)
            df[f'ret_{win}'] = df['close'] / df['close'].shift(win) - 1

        # 布林带
        for win in boll_windows:
            ma = df['close'].rolling(win).mean()
            std = df['close'].rolling(win).std()
            for mul in boll_multipliers:
                df[f'boll_upper_{win}_{mul}'] = ma + mul * std
                df[f'boll_lower_{win}_{mul}'] = ma - mul * std
            df[f'boll_width_{win}'] = (ma + 2 * std) - (ma - 2 * std)
            df[f'boll_pos_{win}'] = (df['close'] - ma) / (std + 1e-9)

        # MACD
        for fast, slow, sig in macd_params:
            macd, macdsignal, macdhist = talib.MACD(df['close'], fastperiod=fast, slowperiod=slow, signalperiod=sig)
            df[f'macd_diff_{fast}_{slow}_{sig}'] = macd
            df[f'macd_signal_{fast}_{slow}_{sig}'] = macdsignal
            df[f'macd_hist_{fast}_{slow}_{sig}'] = macdhist

        # RSI/CCI
        for win in osc_windows:
            df[f'rsi_{win}'] = talib.RSI(df['close'], timeperiod=win)
            tp = (df['high'] + df['low'] + df['close']) / 3
            df[f'cci_{win}'] = talib.CCI(df['high'], df['low'], df['close'], timeperiod=win)

        # ATR
        for win in atr_windows:
            df[f'atr_{win}'] = talib.ATR(df['high'], df['low'], df['close'], timeperiod=win)

        # 成交量
        for win in vol_windows:
            df[f'vol_ma_{win}'] = df['volume'].rolling(win).mean()
            df[f'vol_spike_{win}'] = df['volume'] / (df[f'vol_ma_{win}'] + 1e-9)

        # 区间极值
        for win in range_windows:
            df[f'high_max_{win}'] = df['high'].rolling(win).max()
            df[f'low_min_{win}'] = df['low'].rolling(win).min()
            df[f'price_vs_high_{win}'] = df['close'] / (df[f'high_max_{win}'] + 1e-9)
            df[f'price_vs_low_{win}'] = df['close'] / (df[f'low_min_{win}'] + 1e-9)
            df[f'range_{win}'] = df['high'].rolling(win).max() - df['low'].rolling(win).min()

        # K线结构
        for win in kline_windows:
            df[f'up_{win}'] = (df['close'] > df['close'].shift(1)).rolling(win).sum()
            df[f'down_{win}'] = (df['close'] < df['close'].shift(1)).rolling(win).sum()
            body = abs(df['close'] - df['open'])
            upper_shadow = df['high'] - df[['close', 'open']].max(axis=1)
            lower_shadow = df[['close', 'open']].min(axis=1) - df['low']
            df[f'body_ratio_{win}'] = (body / (df['high'] - df['low'] + 1e-9)).rolling(win).mean()
            df[f'upper_shadow_{win}'] = upper_shadow.rolling(win).mean()
            df[f'lower_shadow_{win}'] = lower_shadow.rolling(win).mean()

        # ---------- 常规单特征 ----------
        # 1. K线基础
        df['candle_body'] = df['close'] - df['open']
        df['candle_upper_shadow'] = df['high'] - df[['close', 'open']].max(axis=1)
        df['candle_lower_shadow'] = df[['close', 'open']].min(axis=1) - df['low']
        df['candle_body_ratio'] = abs(df['candle_body']) / (df['high'] - df['low'] + 1e-9)

        # 2. 跳空特征
        df['gap_open'] = (df['open'] - df['close'].shift(1)) / (df['close'].shift(1) + 1e-9)
        df['gap_close'] = (df['close'] - df['open']) / (df['open'] + 1e-9)

        # 3. 波动率与区间
        df['range'] = df['high'] - df['low']
        df['close_position'] = (df['close'] - df[['close', 'open']].min(axis=1)) / (df['high'] - df['low'] + 1e-9)

        # 4. 量价结构
        df['volume_change'] = df['volume'].pct_change()
        df['volatility_volume_ratio'] = df['close'].rolling(10).std() / (df['volume'].rolling(10).mean() + 1e-9)

        # 5. 日内时间特征
        df['minute_of_day'] = df.index.hour * 60 + df.index.minute
        df['is_open'] = ((df['minute_of_day'] >= 570) & (df['minute_of_day'] < 600)).astype(
            int)  # example: 美股9:30-10:00
        df['is_mid'] = ((df['minute_of_day'] >= 600) & (df['minute_of_day'] < 900)).astype(int)
        df['is_close'] = ((df['minute_of_day'] >= 900) & (df['minute_of_day'] <= 960)).astype(int)

        # 6. 日历特征
        df['day_of_week'] = df.index.dayofweek  # 0=Monday
        df['day_of_month'] = df.index.day

        # 7. 复合信号举例
        df['price_vs_open'] = df['close'] / (df['open'] + 1e-9)
        df['high_close_diff'] = (df['high'] - df['close']) / df['close']
        df['low_close_diff'] = (df['low'] - df['close']) / df['close']

        # 8. OBV/资金流（如需talib或自写）
        try:
            df['obv'] = talib.OBV(df['close'], df['volume'])
        except:
            df['obv'] = np.nan

        # 以 Pandas 为例
        df['prev_kline_down'] = (df['close'].shift(1) < df['open'].shift(1)).astype(int)
        df['prev_kline_change'] = (df['close'].shift(1) - df['open'].shift(1)) / (df['open'].shift(1) + 1e-9)
        return df


    # ===== 标签生成（Target）=====
    def _set_target(self, df):
        # df["tomorrow_open"] = df["open"].shift(-1)
        # df["tomorrow_close"] = df["close"].shift(-1)

        # df["target"] = (df["tomorrow_close"] > df["tomorrow_open"]).astype(int)
        # return df
        # 以未来5分钟的涨跌幅为target
        # future_close = df['close'].shift(-1)  # 以后一根K线收盘为例，实际可以用未来5min收盘
        # df['return'] = (future_close - df['close']) / df['close']

        df["future_open"] = df["open"].shift(-1)
        df["future_close"] = df["close"].shift(-1)

        df["future_return"] = (df["future_close"] - df["future_open"]) / df['future_open']
        # 设置阈值
        threshold = 0.001  # 0.2%

        # 只保留大涨/大跌样本
        df['target'] = np.where(df['future_return'] > threshold, 1,
                                np.where(df['future_return'] < -threshold, 0, np.nan))

        # 去除噪音样本（即涨跌幅度很小的）
        df_filtered = df.dropna(subset=['target'])
        return df_filtered


    def _set_target_3type(self, df):
        # 设置阈值（横盘波动阈值）
        threshold = 0.001  # 例如 0.2%

        # 未来开盘和收盘
        df["future_open"] = df["open"].shift(-1)
        df["future_close"] = df["close"].shift(-1)

        # df["future_close_2"] = df["close"].shift(-2)
        # df["future_close_3"] = df["close"].shift(-3)

        # 计算明日涨跌幅
        df["future_return"] = df["future_close"] / df["future_open"] - 1
        # df["future_return2"] = df["future_close_2"] / df["future_open_1"] - 1
        # df["future_return3"] = df["future_close_3"] / df["future_open_1"] - 1

        # 设定三分类标签
        # 用 pd.cut 得到分类类型
        df["target"] = pd.cut(
            df["future_return"],
            bins=[-float('inf'), -threshold, threshold, float('inf')],
            labels=[0, 1, 2]
        )

        return df

    def _set_target_linreg(self, df):

        # 未来开盘和收盘
        df["future_open_1"] = df["open"].shift(-1)
        df["future_close"] = df["close"].shift(-1)

        # df["future_close_2"] = df["close"].shift(-2)
        # df["future_close_3"] = df["close"].shift(-3)

        # 计算明日涨跌幅
        df["target"] = (df["future_close"] / df["future_open"] - 1) * 1000
        # df["future_return2"] = df["future_close_2"] / df["future_open_1"] - 1
        # df["future_return3"] = df["future_close_3"] / df["future_open_1"] - 1

        return df

    # ===== 主函数入口 =====
    def enrich_features(self, df: pd.DataFrame) -> pd.DataFrame:
        # df = self._add_features_5min(df)

        df = self._add_features(df)
        df = self._set_target_3type(df)

        return df