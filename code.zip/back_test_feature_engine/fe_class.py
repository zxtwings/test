import pandas as pd
import pandas_ta as ta  # pip install pandas_ta
import numpy as np


def calculate_all_features_alpaca(df_original):  # 函数名稍作修改以反映新功能
    """
    根据 Alpaca 数据计算全面的技术指标、衍生特征以及目标变量。

    参数:
    df_original (pd.DataFrame):
        必须包含 'datetime' 索引以及以下列 (不区分大小写):
        'Open', 'High', 'Low', 'Close', 'Volume', 'trade_count', 'vwap'.

    返回:
    pd.DataFrame: 带有新增技术指标列和 'target' 列的DataFrame。
    """
    df = df_original.copy()

    # 统一列名为小写
    df.columns = [col.lower() for col in df.columns]

    # 确保必要的列存在
    required_cols = ['open', 'high', 'low', 'close', 'volume', 'trade_count', 'vwap']
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"输入 DataFrame 缺少以下列: {', '.join(missing_cols)}")

    # --- 0. 基础K线特征 ---
    df['bar_range'] = df['high'] - df['low']
    df['body_size'] = (df['close'] - df['open']).abs()
    df['upper_wick_size'] = df['high'] - df[['open', 'close']].max(axis=1)
    df['lower_wick_size'] = df[['open', 'close']].min(axis=1) - df['low']
    df['body_to_range_ratio'] = df['body_size'].divide(df['bar_range']).replace([np.inf, -np.inf], np.nan)
    df['close_in_bar_range_pct'] = ((df['close'] - df['low']).divide(df['bar_range'])
                                    .replace([np.inf, -np.inf], np.nan).fillna(0.5))

    # --- 1. 近期收益率 (Recent Returns) ---
    for lag in [1, 2, 3, 5, 8, 13]:
        df[f'return_close_lag_{lag}'] = df['close'].pct_change(periods=lag)
        if 'vwap' in df.columns:
            df[f'return_vwap_lag_{lag}'] = df['vwap'].pct_change(periods=lag)

    # --- 2. 移动平均线 (Moving Averages) 及其衍生 ---
    ema_periods_short = [5, 8, 13]
    ema_periods_long = [21, 34, 55]

    for period in ema_periods_short:
        df[f'ema_{period}'] = df.ta.ema(close=df['close'], length=period)
        df[f'price_div_ema_{period}'] = df['close'] / df[f'ema_{period}']
        if 'vwap' in df.columns:
            df[f'vwap_ema_{period}'] = df.ta.ema(close=df['vwap'], length=period)

    for period in ema_periods_long:
        df[f'ema_{period}'] = df.ta.ema(close=df['close'], length=period)
        if 'vwap' in df.columns:
            df[f'vwap_ema_{period}'] = df.ta.ema(close=df['vwap'], length=period)

    if f'ema_{ema_periods_short[0]}' in df and f'ema_{ema_periods_long[0]}' in df:
        df[f'ema_s_div_l'] = df[f'ema_{ema_periods_short[0]}'] / df[f'ema_{ema_periods_long[0]}']
    if 'vwap_ema_5' in df and 'vwap_ema_21' in df:
        df[f'vwap_ema_s_div_l'] = df[f'vwap_ema_{ema_periods_short[0]}'] / df[f'vwap_ema_{ema_periods_long[0]}']

    macd_close = df.ta.macd(close=df['close'], fast=12, slow=26, signal=9)
    if macd_close is not None:
        df['macd_close'] = macd_close[f'MACD_12_26_9']
        df['macd_signal_close'] = macd_close[f'MACDs_12_26_9']
        df['macd_hist_close'] = macd_close[f'MACDh_12_26_9']

    if 'vwap' in df.columns:
        macd_vwap = df.ta.macd(close=df['vwap'], fast=12, slow=26, signal=9)
        if macd_vwap is not None:
            df['macd_vwap'] = macd_vwap[f'MACD_12_26_9']
            df['macd_signal_vwap'] = macd_vwap[f'MACDs_12_26_9']
            df['macd_hist_vwap'] = macd_vwap[f'MACDh_12_26_9']

    # --- 3. 波动率指标 (Volatility Indicators) ---
    atr_length = 14
    df[f'atr_{atr_length}'] = df.ta.atr(high=df['high'], low=df['low'], close=df['close'], length=atr_length)

    bb_length = 20
    bb_std = 2.0
    bbands = df.ta.bbands(close=df['close'], length=bb_length, std=bb_std)
    if bbands is not None:
        df[f'bb_lower_{bb_length}_{bb_std}'] = bbands[f'BBL_{bb_length}_{bb_std}']
        df[f'bb_middle_{bb_length}_{bb_std}'] = bbands[f'BBM_{bb_length}_{bb_std}']
        df[f'bb_upper_{bb_length}_{bb_std}'] = bbands[f'BBU_{bb_length}_{bb_std}']
        df[f'bb_width_{bb_length}_{bb_std}'] = bbands[f'BBB_{bb_length}_{bb_std}'] / 100
        df[f'bb_percent_{bb_length}_{bb_std}'] = bbands[f'BBP_{bb_length}_{bb_std}'] / 100

    kc = df.ta.kc(high=df['high'], low=df['low'], close=df['close'], length=20, atr_length=10, mamode='ema')
    if kc is not None and isinstance(kc, pd.DataFrame) and not kc.empty:
        # pandas_ta < 0.3.15 returns a dict, >= 0.3.15 returns a DataFrame
        # For newer versions, column names might be like 'KCL_20_2.0', 'KCU_20_2.0'
        # For older versions, it might be positional. Checking based on typical structure.
        if f'KCL_20_ema_10' in kc.columns:  # Example for a specific pandas_ta version naming
            df['kc_lower'] = kc[f'KCL_20_ema_10']
            df['kc_upper'] = kc[f'KCU_20_ema_10']
        elif kc.shape[1] >= 3:  # Fallback for positional or generic names
            df['kc_lower'] = kc.iloc[:, 0]
            df['kc_upper'] = kc.iloc[:, 2]

            # --- 4. 动量震荡指标 (Momentum Oscillators) ---
    rsi_length = 14
    df[f'rsi_{rsi_length}'] = df.ta.rsi(close=df['close'], length=rsi_length)
    if 'vwap' in df.columns:
        df[f'rsi_vwap_{rsi_length}'] = df.ta.rsi(close=df['vwap'], length=rsi_length)

    stoch_k, stoch_d, stoch_smooth_k = 14, 3, 3
    stoch = df.ta.stoch(high=df['high'], low=df['low'], close=df['close'], k=stoch_k, d=stoch_d,
                        smooth_k=stoch_smooth_k)
    if stoch is not None:
        df[f'stoch_k'] = stoch[f'STOCHk_{stoch_k}_{stoch_d}_{stoch_smooth_k}']
        df[f'stoch_d'] = stoch[f'STOCHd_{stoch_k}_{stoch_d}_{stoch_smooth_k}']

    for period in [10, 15, 20]:
        df[f'roc_close_{period}'] = df.ta.roc(close=df['close'], length=period)
        if 'vwap' in df.columns:
            df[f'roc_vwap_{period}'] = df.ta.roc(close=df['vwap'], length=period)

    cci_length = 20
    df[f'cci_{cci_length}'] = df.ta.cci(high=df['high'], low=df['low'], close=df['close'], length=cci_length)

    adx_length = 14
    adx_indicator = df.ta.adx(high=df['high'], low=df['low'], close=df['close'], length=adx_length)
    if adx_indicator is not None and isinstance(adx_indicator, pd.DataFrame) and not adx_indicator.empty:
        df[f'adx_{adx_length}'] = adx_indicator[f'ADX_{adx_length}']
        df[f'dmp_{adx_length}'] = adx_indicator[f'DMP_{adx_length}']
        df[f'dmn_{adx_length}'] = adx_indicator[f'DMN_{adx_length}']

    # --- 5. 价格与近期极值关系 ---
    for n_period in [10, 20, 40]:
        high_n = df['high'].rolling(window=n_period, min_periods=1).max()
        low_n = df['low'].rolling(window=n_period, min_periods=1).min()

        df[f'price_div_recent_high_{n_period}'] = (df['close'] / high_n)
        df[f'price_div_recent_low_{n_period}'] = (df['close'] / low_n)

        range_n = high_n - low_n
        df[f'position_in_range_{n_period}'] = ((df['close'] - low_n).divide(range_n)
                                               .replace([np.inf, -np.inf], np.nan).fillna(0.5))

    # --- 6. 成交量 (Volume), 交易次数 (Trade Count), VWAP 相关特征 ---
    for period in [5, 10, 20]:
        df[f'volume_sma_{period}'] = df.ta.sma(close=df['volume'], length=period)
        if period == 10:
            df[f'volume_div_sma_{period}'] = df['volume'].divide(df[f'volume_sma_{period}']).replace([np.inf, -np.inf],
                                                                                                     np.nan)
    df['obv'] = df.ta.obv(close=df['close'], volume=df['volume'])
    df['obv_roc_10'] = df.ta.roc(close=df['obv'], length=10) if 'obv' in df and not df['obv'].isnull().all() else np.nan

    if 'trade_count' in df.columns:
        for period in [5, 10, 20]:
            df[f'trade_count_sma_{period}'] = df.ta.sma(close=df['trade_count'], length=period)
            if period == 10:
                df[f'trade_count_div_sma_{period}'] = df['trade_count'].divide(df[f'trade_count_sma_{period}']).replace(
                    [np.inf, -np.inf], np.nan)
        df['trade_count_roc_10'] = df.ta.roc(close=df['trade_count'], length=10)

        df['avg_trade_size'] = df['volume'].divide(df['trade_count']).replace([np.inf, -np.inf], np.nan)
        df['avg_trade_size_sma_10'] = df.ta.sma(close=df['avg_trade_size'], length=10) if 'avg_trade_size' in df and not \
        df['avg_trade_size'].isnull().all() else np.nan

    if 'vwap' in df.columns:
        df['close_div_vwap'] = df['close'] / df['vwap']
        df['open_div_vwap'] = df['open'] / df['vwap']
        df['high_div_vwap'] = df['high'] / df['vwap']
        df['low_div_vwap'] = df['low'] / df['vwap']
        df['vwap_dist_from_close_pct'] = (df['close'] - df['vwap']) / df['vwap']

    # --- 7. 时间特征 (Time-Based Features) ---
    if isinstance(df.index, pd.DatetimeIndex):
        df['time_hour'] = df.index.hour
        df['time_minute_of_day'] = df.index.hour * 60 + df.index.minute
        df['time_day_of_week'] = df.index.dayofweek
        df['time_week_of_year'] = df.index.isocalendar().week.astype(int)
        df['time_15min_segment'] = (df.index.hour * 4 + df.index.minute // 15)

        df['hour_sin'] = np.sin(2 * np.pi * df['time_hour'] / 23.0)  # Use 23 for 0-23 range
        df['hour_cos'] = np.cos(2 * np.pi * df['time_hour'] / 23.0)
        df['dayofweek_sin'] = np.sin(2 * np.pi * df['time_day_of_week'] / 6.0)  # Use 6 for 0-6 range
        df['dayofweek_cos'] = np.cos(2 * np.pi * df['time_day_of_week'] / 6.0)
    else:
        print("提示: DataFrame 索引不是 DatetimeIndex 类型，时间相关特征未计算。")

    # --- 8. 计算目标变量 (Target Variable) ---
    # 目标是下一个15分钟K线的收盘价涨跌情况
    # 1. 获取下一个K线的收盘价
    df['future_close_1'] = df['close'].shift(-1)

    # 2. 计算相对于当前K线收盘价的未来收益率
    df['future_return_1'] = (df['future_close_1'] - df['close']) / df['close']

    # 3. 定义阈值和条件
    threshold_up = 0.002  # 2% 上涨
    threshold_down = -0.002  # 2% 下跌

    conditions = [
        df['future_return_1'] > threshold_up,
        (df['future_return_1'] >= threshold_down) & (df['future_return_1'] <= threshold_up),
        df['future_return_1'] < threshold_down
    ]

    # 4. 定义对应的标签
    choices = [2, 1, 0]

    # 5. 创建 'target' 列
    df['target'] = np.select(conditions, choices, default=np.nan)  # 对于最后一行，future_return_1 是 NaN，target 也会是 NaN

    # （可选）您可以删除用于计算 target 的中间列
    # df.drop(columns=['future_close_1', 'future_return_1'], inplace=True, errors='ignore')
    # 这里暂时保留它们，以便调试或检查。

    # 清理：将所有列中无穷大的值替换为NaN
    df.replace([np.inf, -np.inf], np.nan, inplace=True)

    return df


if __name__ == '__main__':
    # --- 创建一个与 Alpaca 数据结构类似的示例 DataFrame ---
    periods = 400
    start_time = '2024-01-01 09:30:00'
    # Alpaca通常返回UTC时间，如果您的本地时间是CEST，并且Alpaca返回的是UTC， pandas_ta和多数时间操作会正确处理
    # 但如果Alpaca返回的是已转换为本地时区的时间，请确保时区一致性
    idx = pd.to_datetime(pd.date_range(start=start_time, periods=periods, freq='15min'), utc=True)

    data = {
        'open': np.random.rand(periods) * 10 + 100,
        'high': np.random.rand(periods) * 5 + 105,
        'low': 100 - np.random.rand(periods) * 5,
        'close': np.random.rand(periods) * 10 + 100,
        'volume': np.random.uniform(100, 2000, periods).astype(int),
        'trade_count': np.random.uniform(10, 500, periods).astype(int),
        'vwap': np.random.rand(periods) * 2 + 101
    }
    sample_df = pd.DataFrame(data, index=idx)

    sample_df['high'] = sample_df[['open', 'close']].max(axis=1) + np.random.rand(periods) * 2
    sample_df['low'] = sample_df[['open', 'close']].min(axis=1) - np.random.rand(periods) * 2
    sample_df.loc[sample_df['low'] < 0, 'low'] = 0.01
    sample_df['vwap'] = (sample_df['high'] + sample_df['low'] + sample_df['close']) / 3

    print("原始 Alpaca 数据 (前3行):")
    print(sample_df.head(3))
    print(f"原始数据形状: {sample_df.shape}")
    print("\n" + "=" * 80 + "\n")

    # --- 计算技术指标和目标变量 ---
    df_processed = calculate_all_features_alpaca(sample_df.copy())

    print(f"处理后包含特征和目标的数据 (前3行，部分列):")
    cols_to_show = ['open', 'close', 'vwap', 'target', 'future_return_1',
                    'return_close_lag_1', 'ema_13', 'rsi_14', 'adx_14',
                    'close_div_vwap', 'avg_trade_size']

    cols_to_show_existing = [col for col in cols_to_show if col in df_processed.columns]
    print(df_processed[cols_to_show_existing].head(3))

    print(f"\n处理后数据形状: {df_processed.shape}")
    print(f"新增列的数量: {df_processed.shape[1] - sample_df.shape[1]}")

    print("\n查看尾部数据 (检查 target 和 future_return_1 的 NaN 情况):")
    tail_cols = ['close', 'future_close_1', 'future_return_1', 'target', 'ema_55', 'adx_14']
    tail_cols_existing = [col for col in tail_cols if col in df_processed.columns]
    print(df_processed[tail_cols_existing].tail())

    print("\n目标变量 'target' 的分布:")
    print(df_processed['target'].value_counts(dropna=False))