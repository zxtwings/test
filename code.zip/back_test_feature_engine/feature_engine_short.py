from datetime import time

import pandas as pd
import numpy as np
import talib
from sklearn.preprocessing import StandardScaler


def macd_func(close, fast=12, slow=26, signal=9):
    exp1 = close.ewm(span=fast, adjust=False).mean()
    exp2 = close.ewm(span=slow, adjust=False).mean()
    macd = exp1 - exp2
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    macd_diff = macd - signal_line
    return macd, signal_line, macd_diff


def rsi_func(series, period=14):
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    ma_up = up.ewm(com=period - 1, adjust=False).mean()
    ma_down = down.ewm(com=period - 1, adjust=False).mean()
    rsi = 100 * ma_up / (ma_up + ma_down + 1e-9)
    return rsi


class FeatureEngine:
    def __init__(self, mode='auto'):
        """
        mode: '15min', 'daily', or 'auto'
        """
        self.mode = mode

    def _detect_mode(self, df):
        time_diffs = df.index.to_series().diff().dropna()
        return '5min' if time_diffs.median() < pd.Timedelta('1H') else 'daily'

    # ===== 通用技术指标函数 =====
    def _rsi(self, series, window=14):
        delta = series.diff()
        gain = delta.clip(lower=0).rolling(window).mean()
        loss = -delta.clip(upper=0).rolling(window).mean()
        rs = gain / (loss + 1e-9)
        return 100 - 100 / (1 + rs)

    def _macd(self, series, fast=12, slow=26, signal=9):
        ema_fast = series.ewm(span=fast, adjust=False).mean()
        ema_slow = series.ewm(span=slow, adjust=False).mean()
        macd = ema_fast - ema_slow
        macd_signal = macd.ewm(span=signal, adjust=False).mean()
        return macd, macd_signal, macd - macd_signal

    def _vwap(self, close, volume, window=None):
        if window:
            return (close * volume).rolling(window).sum() / volume.rolling(window).sum()
        return (close * volume).cumsum() / volume.cumsum()

    def _obv(self, close, volume):
        return (np.sign(close.diff()) * volume).fillna(0).cumsum()

    def _adx(self, high, low, close, window=14):
        tr = pd.concat([
            high - low,
            (high - close.shift()).abs(),
            (low - close.shift()).abs()
        ], axis=1).max(axis=1)

        atr = tr.rolling(window).mean()
        up_move = high.diff()
        down_move = -low.diff()

        plus_dm = ((up_move > down_move) & (up_move > 0)) * up_move
        minus_dm = ((down_move > up_move) & (down_move > 0)) * down_move

        plus_di = 100 * plus_dm.rolling(window).mean() / (atr + 1e-9)
        minus_di = 100 * minus_dm.rolling(window).mean() / (atr + 1e-9)
        dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di + 1e-9)
        return dx.rolling(window).mean()

    # ===== 15分钟特征 =====
    def _add_features_15min2(self, df):
        df = df.copy()
        close = df['close']
        high = df['high']
        low = df['low']
        volume = df['volume']
        open_ = df['open']

        # ========== 核心趋势特征 ==========
        # 斐波那契周期均线系统
        df['sma_13'] = close.rolling(13).mean()  # 3.25小时窗口
        df['sma_34'] = close.rolling(34).mean()  # 8.5小时窗口
        df['sma_55'] = close.rolling(55).mean()  # 13.75小时窗口
        df['sma_diff'] = df['sma_13'] - df['sma_34']

        # 三重MACD系统
        df['macd_fast'], df['macd_slow'], df['macd_hist'] = talib.MACDEXT(
            close,
            fastperiod=8,  # 2小时
            slowperiod=21,  # 5.25小时
            signalperiod=5,
            fastmatype=1,  # EMA
            slowmatype=1,
            signalmatype=1
        )

        # ========== 波动率管理系统 ==========
        # 动态ATR系统
        df['atr_21'] = talib.ATR(high, low, close, 21)
        df['atr_55'] = df['atr_21'].rolling(55).mean()
        df['volatility_ratio'] = df['atr_21'] / (df['atr_55'] + 1e-9)

        # 自适应布林带
        ma21 = close.rolling(21).mean()
        std21 = close.rolling(21).std()
        df['boll_upper'] = ma21 + 2.618 * std21  # 黄金比例上轨
        df['boll_lower'] = ma21 - 1.618 * std21  # 黄金比例下轨
        df['boll_width'] = df['boll_upper'] - df['boll_lower']

        # ========== 量价协同特征 ==========
        # 智能资金流
        df['ohlc4'] = (open_ + high + low + close) / 4
        condition = close > df['ohlc4'].shift(1)
        df['smart_flow'] = (
                df['ohlc4'] * df['volume'] * condition.astype(int).replace(0, -1)
        ).rolling(8, min_periods=1).sum()
        # 量价背离检测
        df['price_volume_corr'] = close.rolling(34).corr(volume)  # 8.5小时相关性

        # ========== 市场状态特征 ==========
        # 趋势强度量化
        df['trend_strength'] = (
                (df['sma_13'] - df['sma_34']) /
                (close.rolling(13).std() + 1e-9)
        ).rolling(5).mean()

        # 斐波那契位置
        max55 = close.rolling(55).max()
        min55 = close.rolling(55).min()
        df['fib_position'] = (close - min55) / (max55 - min55 + 1e-9)

        # ========== 时间周期特征 ==========
        # 动态时段能量指标（适应A股交易时段）
        time_idx = df.index.hour * 100 + df.index.minute  # 保持为 Series
        high = df['high']  # 必须是 Series
        open_ = df['open']  # 必须是 Series

        # 使用纯 Pandas 语法重构
        morning_mask = (time_idx >= 930) & (time_idx <= 1130)
        morning_returns = (high - open_) / (open_ + 1e-9)  # 保持为 Series

        # 分步计算
        df['morning_power'] = morning_returns.where(morning_mask, 0).rolling(5, min_periods=1).mean()
        df['afternoon_vol'] = np.where(
            (time_idx >= 1300) & (time_idx <= 1455),
            volume / volume.rolling(8).mean(),
            1
        )

        # ========== 风险控制特征 ==========
        # 波动率调整动量
        df['momentum_8'] = close.pct_change(8)  # 2小时收益率
        df['risk_adjusted_mom'] = df['momentum_8'] / (df['atr_21'] + 1e-9)

        # 流动性冲击指标
        df['liquidity_shock'] = ((volume.rolling(5).max() / volume.rolling(21).mean()) *(df['boll_width'] / df['boll_width'].rolling(34).mean()))

        # ========== 高级形态特征 ==========
        # 三价线系统
        tp = (high + low + close) / 3

        df['cci_34'] = (tp - tp.rolling(34).mean()) / (0.015 * tp.rolling(34).std())

        # K线实体动量
        df['candle_power'] = (close - open_) / (high - low + 1e-9)
        df['shadow_ratio'] = ((high - np.maximum(close, open_)) + (np.minimum(close, open_) - low)) / (
                    high - low + 1e-9)

        # ========== 数据清洗 ==========

        # 处理跳空缺口
        df['overnight_gap'] = (open_ - close.shift(1)) / (close.shift(1) + 1e-9)

        # ========== 特征裁剪 ==========
        # 删除冗余特征
        del df['ohlc4']

        return df.dropna()


    def _add_features_15min(self, df):
        df = df.copy()
        close = df['close']
        high = df['high']
        low = df['low']
        volume = df['volume']
        open_ = df['open']

        # ========== 核心趋势特征 ==========
        # 斐波那契周期均线系统
        df['sma_13'] = close.rolling(13).mean()  # 3.25小时窗口
        df['sma_34'] = close.rolling(34).mean()  # 8.5小时窗口
        df['sma_55'] = close.rolling(55).mean()  # 13.75小时窗口
        df['sma_diff'] = df['sma_13'] - df['sma_34']

        # # 三重MACD系统
        # df['macd_fast'], df['macd_slow'], df['macd_hist'] = talib.MACDEXT(
        #     close,
        #     fastperiod=5,  # 2小时
        #     slowperiod=13,  # 5.25小时
        #     signalperiod=3,
        #     fastmatype=1,  # EMA
        #     slowmatype=1,
        #     signalmatype=1
        # )
        #
        # df['macd_fast2'], df['macd_slow2'], df['macd_hist2'] = talib.MACDEXT(
        #     close,
        #     fastperiod=8,  # 2小时
        #     slowperiod=21,  # 5.25小时
        #     signalperiod=5,
        #     fastmatype=1,  # EMA
        #     slowmatype=1,
        #     signalmatype=1
        # )

        # ========== 波动率管理系统 ==========
        # 动态ATR系统
        df['atr_21'] = talib.ATR(high, low, close, 21)
        df['atr_55'] = df['atr_21'].rolling(55).mean()
        df['volatility_ratio'] = df['atr_21'] / (df['atr_55'] + 1e-9)

        # 多周期布林带
        # for win in [8, 21, 34]:
        #     ma = close.rolling(win).mean()
        #     std = close.rolling(win).std()
        #     df[f'boll_upper_{win}'] = ma + 2 * std
        #     df[f'boll_lower_{win}'] = ma - 2 * std
        #     df[f'boll_width_{win}'] = df[f'boll_upper_{win}'] - df[f'boll_lower_{win}']
        #     df[f'boll_pos_{win}'] = (close - ma) / (std + 1e-9)
        #     df[f'boll_break_upper_{win}'] = (close > df[f'boll_upper_{win}']).astype(int)
        #     df[f'boll_break_lower_{win}'] = (close < df[f'boll_lower_{win}']).astype(int)

        # 自适应布林带
        ma21 = close.rolling(21).mean()
        std21 = close.rolling(21).std()
        df['boll_upper'] = ma21 + 3 * std21  # 黄金比例上轨
        df['boll_lower'] = ma21 - 3 * std21  # 黄金比例下轨
        df['boll_width'] = df['boll_upper'] - df['boll_lower']

        # ========== 量价协同特征 ==========
        # 智能资金流
        df['ohlc4'] = (open_ + high + low + close) / 4
        condition = close > df['ohlc4'].shift(1)
        df['smart_flow'] = (
                df['ohlc4'] * df['volume'] * condition.astype(int).replace(0, -1)
        ).rolling(8, min_periods=1).sum()
        # 量价背离检测
        df['price_volume_corr'] = close.rolling(34).corr(volume)  # 8.5小时相关性

        # ========== 市场状态特征 ==========
        # 趋势强度量化
        df['trend_strength'] = (
                (df['sma_13'] - df['sma_34']) /
                (close.rolling(13).std() + 1e-9)
        ).rolling(5).mean()

        # 斐波那契位置
        max55 = close.rolling(55).max()
        min55 = close.rolling(55).min()
        df['fib_position'] = (close - min55) / (max55 - min55 + 1e-9)

        # ========== 时间周期特征 ==========
        # 动态时段能量指标（适应A股交易时段）
        time_idx = df.index.hour * 100 + df.index.minute  # 保持为 Series
        high = df['high']  # 必须是 Series
        open_ = df['open']  # 必须是 Series

        # 使用纯 Pandas 语法重构
        morning_mask = (time_idx >= 930) & (time_idx <= 1130)
        morning_returns = (high - open_) / (open_ + 1e-9)  # 保持为 Series

        # 分步计算
        df['morning_power'] = morning_returns.where(morning_mask, 0).rolling(5, min_periods=1).mean()
        df['afternoon_vol'] = np.where(
            (time_idx >= 1300) & (time_idx <= 1455),
            volume / volume.rolling(8).mean(),
            1
        )

        # ========== 风险控制特征 ==========
        # 波动率调整动量
        df['momentum_8'] = close.pct_change(8)  # 2小时收益率
        df['risk_adjusted_mom'] = df['momentum_8'] / (df['atr_21'] + 1e-9)

        # 流动性冲击指标
        # df['liquidity_shock'] = ((volume.rolling(5).max() / volume.rolling(21).mean()) *(df['boll_width'] / df['boll_width'].rolling(34).mean()))

        # ========== 高级形态特征 ==========
        # 三价线系统
        tp = (high + low + close) / 3

        df['cci_34'] = (tp - tp.rolling(34).mean()) / (0.015 * tp.rolling(34).std())

        # K线实体动量
        df['candle_power'] = (close - open_) / (high - low + 1e-9)
        df['shadow_ratio'] = ((high - np.maximum(close, open_)) + (np.minimum(close, open_) - low)) / (
                    high - low + 1e-9)

        # ========== 数据清洗 ==========

        # 处理跳空缺口
        df['overnight_gap'] = (open_ - close.shift(1)) / (close.shift(1) + 1e-9)

        # ========== 特征裁剪 ==========
        # 删除冗余特征
        del df['ohlc4']

        return df.dropna()


    # ===== 5分钟特征 =====
    def _add_features_5min(self, df):
        df = df.copy()
        close, high, low, volume = df["close"], df["high"], df["low"], df["volume"]
        eps = 1e-9

        # 均线与趋势
        df["sma_3"] = close.rolling(3).mean()
        df["sma_10"] = close.rolling(10).mean()
        df['sma_diff'] = df['sma_3'] - df['sma_10']
        df["ma_trend_slope"] = df["sma_10"].diff()

        # 动量
        df["momentum_3"] = close / close.shift(3) - 1

        df["prev_up1"] = (close.diff(1) > 0).astype(int)
        df["prev_up2"] = (close.diff(2) > 0).astype(int)

        # 波动
        df["std_10"] = close.rolling(10).std()
        df["boll_width"] = 2 * close.rolling(20).std()
        df["atr_14"] = pd.concat([
            high - low,
            (high - close.shift()).abs(),
            (low - close.shift()).abs()
        ], axis=1).max(axis=1).rolling(14).mean()
        df["volatility_scaled_mom"] = df["momentum_3"] / (df["std_10"] + eps)
        #
        # 量能
        df['vol_ratio'] = volume / (volume.rolling(20).mean() + eps)
        df["volume_spike"] = volume / (volume.rolling(20).mean() + eps)
        df["volatility_volume_ratio"] = close.rolling(10).std() / (volume.rolling(10).mean() + eps)
        #
        # 价格结构与形态
        df["price_vs_high"] = close / high.rolling(30).max()
        df["close_position"] = (close - df[["close", "open"]].min(axis=1)) / (high - low + eps)
        df["gap_open"] = (df["open"] - close.shift(1)) / (close.shift(1) + eps)
        df["candle_body_ratio"] = abs(df["close"] - df["open"]) / (high - low + eps)
        #
        # MACD
        # macd, macd_signal, macd_diff = macd_func(close)
        # df["macd"] = macd
        # df["macd_signal"] = macd_signal
        # df["macd_diff"] = macd_diff
        # df["macd_hist_slope"] = df["macd_diff"].diff()

        macd, macdsignal, macdhist = talib.MACD(
            df['close'],
            fastperiod=8,  # 40分钟
            slowperiod=21,  # 105分钟
            signalperiod=5
        )
        df["macd_diff"] = macd
        df["macd_signal"] = macdsignal
        df["macd_hist"] = macdhist

        #
        # RSI
        df["rsi_14"] = rsi_func(close, 14)
        df["rsi_trend"] = df["rsi_14"].diff()
        #
        # 日内时间结构
        df["minute_of_day"] = df.index.hour * 60 + df.index.minute
        df["is_open"] = ((df["minute_of_day"] >= 870) & (df["minute_of_day"] < 930)).astype(int)
        df["is_close"] = ((df["minute_of_day"] >= 1140) & (df["minute_of_day"] <= 1200)).astype(int)
        #
        # # 日内收益与成交量累计
        # df["cum_return_today"] = df.groupby(df.index.date)["close"].transform(lambda x: x / x.iloc[0] - 1)
        # df["cum_volume_today"] = df.groupby(df.index.date)["volume"].transform("cumsum")
        #
        # # 动态止损
        # df["dynamic_sl"] = close - 2.8 * df["atr_14"]
        #
        # # 正余弦时间编码（周期效应）
        # df["sin_time"] = np.sin(2 * np.pi * df["minute_of_day"] / 1440)
        # df["cos_time"] = np.cos(2 * np.pi * df["minute_of_day"] / 1440)

        # df["cum_return_today"] = df.groupby(df.index.date)["close"].transform(lambda x: x / x.iloc[0] - 1)



        # 只保留主要特征列
        main_features = [
            "sma_3", "sma_10", "sma_diff", "ma_trend_slope",
            "momentum_3", "std_10", "boll_width", "atr_14", "volatility_scaled_mom",
            "vol_ratio", "volume_spike", "volatility_volume_ratio",
            "price_vs_high", "close_position", "gap_open", "candle_body_ratio",
            "macd", "macd_signal", "macd_diff", "macd_hist_slope",
            "rsi_14", "rsi_trend",
            "minute_of_day", "is_open", "is_close", "cum_return_today", "cum_volume_today",
            "dynamic_sl", "sin_time", "cos_time"
        ]
        # return df[main_features]
        return df

    # 使用方法


    # ===== 标签生成（Target）=====
    def _set_target(self, df):
        # df["tomorrow_open"] = df["open"].shift(-1)
        # df["tomorrow_close"] = df["close"].shift(-1)

        # df["target"] = (df["tomorrow_close"] > df["tomorrow_open"]).astype(int)
        # return df
        # 以未来5分钟的涨跌幅为target
        # future_close = df['close'].shift(-1)  # 以后一根K线收盘为例，实际可以用未来5min收盘
        # df['return'] = (future_close - df['close']) / df['close']

        df["future_open"] = df["open"].shift(-1)
        df["future_close"] = df["close"].shift(-1)

        df["future_return"] = (df["future_close"] - df["future_open"]) / df['future_open']
        # 设置阈值
        threshold = 0.001  # 0.2%

        # 只保留大涨/大跌样本
        df['target'] = np.where(df['future_return'] > threshold, 1,
                                np.where(df['future_return'] < -threshold, 0, np.nan))

        # 去除噪音样本（即涨跌幅度很小的）
        df_filtered = df.dropna(subset=['target'])
        return df_filtered


    def _set_target_3type(self, df):
        # 设置阈值（横盘波动阈值）
        threshold = 0.002  # 例如 0.2%

        # 未来开盘和收盘
        df["future_open"] = df["open"].shift(-1)
        df["future_close"] = df["close"].shift(-1)

        # df["future_close_2"] = df["close"].shift(-2)
        # df["future_close_3"] = df["close"].shift(-3)

        # 计算明日涨跌幅
        df["future_return"] = df["future_close"] / df["future_open"] - 1
        # df["future_return2"] = df["future_close_2"] / df["future_open_1"] - 1
        # df["future_return3"] = df["future_close_3"] / df["future_open_1"] - 1

        # 设定三分类标签
        # 用 pd.cut 得到分类类型
        df["target"] = pd.cut(
            df["future_return"],
            bins=[-float('inf'), -threshold, threshold, float('inf')],
            labels=[0, 1, 2]
        )

        return df

    def _set_target_linreg(self, df):

        # 未来开盘和收盘
        df["future_open_1"] = df["open"].shift(-1)
        df["future_close"] = df["close"].shift(-1)

        # df["future_close_2"] = df["close"].shift(-2)
        # df["future_close_3"] = df["close"].shift(-3)

        # 计算明日涨跌幅
        df["target"] = (df["future_close"] / df["future_open"] - 1) * 1000
        # df["future_return2"] = df["future_close_2"] / df["future_open_1"] - 1
        # df["future_return3"] = df["future_close_3"] / df["future_open_1"] - 1

        return df

    # ===== 主函数入口 =====
    def enrich_features_5min(self, df: pd.DataFrame) -> pd.DataFrame:
        # df = self._add_features_5min(df)

        df = self._add_features_5min(df)
        df = self._set_target_3type(df)

        return df

    def enrich_features_15min(self, df: pd.DataFrame) -> pd.DataFrame:
        df = self._add_features_15min(df)
        df = self._set_target_3type(df)
        return df

    def enrich_features_linreg(self, df: pd.DataFrame) -> pd.DataFrame:
        df = self._add_features_15min(df)
        df = self._set_target_linreg(df)
        return df