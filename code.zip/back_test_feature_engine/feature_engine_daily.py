import pandas as pd
import numpy as np
import ta

class FeatureEngine:
    def __init__(self, mode='auto'):
        """
        mode: '15min', 'daily', or 'auto'
        """
        self.mode = mode

    def _detect_mode(self, df):
        time_diffs = df.index.to_series().diff().dropna()
        return '15min' if time_diffs.median() < pd.Timedelta('1H') else 'daily'

    # ===== 通用技术指标函数 =====
    def _rsi(self, series, window=14):
        delta = series.diff()
        gain = delta.clip(lower=0).rolling(window).mean()
        loss = -delta.clip(upper=0).rolling(window).mean()
        rs = gain / (loss + 1e-9)
        return 100 - 100 / (1 + rs)

    def _macd(self, series, fast=12, slow=26, signal=9):
        ema_fast = series.ewm(span=fast, adjust=False).mean()
        ema_slow = series.ewm(span=slow, adjust=False).mean()
        macd = ema_fast - ema_slow
        macd_signal = macd.ewm(span=signal, adjust=False).mean()
        return macd, macd_signal, macd - macd_signal

    def _vwap(self, close, open, window=None):
        if window:
            return (close * open).rolling(window).sum() / open.rolling(window).sum()
        return (close * open).cumsum() / open.cumsum()

    def _obv(self, close, open):
        return (np.sign(close.diff()) * open).fillna(0).cumsum()

    def _adx(self, high, low, close, window=14):
        tr = pd.concat([
            high - low,
            (high - close.shift()).abs(),
            (low - close.shift()).abs()
        ], axis=1).max(axis=1)

        atr = tr.rolling(window).mean()
        up_move = high.diff()
        down_move = -low.diff()

        plus_dm = ((up_move > down_move) & (up_move > 0)) * up_move
        minus_dm = ((down_move > up_move) & (down_move > 0)) * down_move

        plus_di = 100 * plus_dm.rolling(window).mean() / (atr + 1e-9)
        minus_di = 100 * minus_dm.rolling(window).mean() / (atr + 1e-9)
        dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di + 1e-9)
        return dx.rolling(window).mean()


    # ===== 每日特征 =====
    def _add_features_daily(self, df):

        df = df.copy()

        # 原始特征
        df["open"] = df["open"]
        df["high"] = df["high"]
        df["low"] = df["low"]
        df["close"] = df["close"]
        df["volume"] = df["volume"]

        # 基础价格派生特征
        df["prev_close"] = df["close"].shift(1)
        df["return_1d"] = (df["close"] - df["prev_close"]) / df["prev_close"]
        df["gap_open"] = (df["open"] - df["prev_close"]) / df["prev_close"]
        df["intraday_return"] = (df["close"] - df["open"]) / df["open"]
        df["high_low_range"] = (df["high"] - df["low"]) / df["open"]
        df["volume_change"] = df["volume"].pct_change()

        # 技术指标 (使用 ta 库)
        df["SMA_5"] = ta.trend.sma_indicator(df["close"], window=5)
        df["SMA_10"] = ta.trend.sma_indicator(df["close"], window=10)
        df["EMA_5"] = ta.trend.ema_indicator(df["close"], window=5)

        macd = ta.trend.macd(df["close"])
        df["MACD"] = macd
        df["MACD_signal"] = ta.trend.macd_signal(df["close"])
        df["MACD_hist"] = ta.trend.macd_diff(df["close"])

        df["RSI_14"] = ta.momentum.rsi(df["close"], window=14)
        df["Momentum_10"] = ta.momentum.awesome_oscillator(df["high"], df["low"])
        df["ROC_5"] = ta.momentum.roc(df["close"], window=5)

        df["ATR_14"] = ta.volatility.average_true_range(df["high"], df["low"], df["close"], window=14)
        bb = ta.volatility.BollingerBands(df["close"], window=20, window_dev=2)
        df["Bollinger_width"] = bb.bollinger_hband() - bb.bollinger_lband()

        df["OBV"] = ta.volume.on_balance_volume(df["close"], df["volume"])

        # 滚动统计特征
        df["rolling_max_close_20"] = df["close"].rolling(20).max()
        df["rolling_min_close_20"] = df["close"].rolling(20).min()
        df["rolling_std_close_10"] = df["close"].rolling(10).std()
        df["price_vs_rolling_max"] = df["close"] / df["rolling_max_close_20"]

        # 时间特征（如果 index 是 datetime）
        if isinstance(df.index, pd.DatetimeIndex):
            df["weekday"] = df.index.weekday
            df["is_month_end"] = df.index.is_month_end.astype(int)
            df["is_month_start"] = df.index.is_month_start.astype(int)
            df["day_of_year"] = df.index.dayofyear
        else:
            df["weekday"] = 0
            df["is_month_end"] = 0
            df["is_month_start"] = 0
            df["day_of_year"] = 0

        # 清理缺失值
        # df = df.dropna().reset_index(drop=True)

        return df


    # ===== 标签生成（Target）=====
    def _set_target(self, df):
        df["tomorrow_open"] = df["open"].shift(-1)
        df["tomorrow_close"] = df["close"].shift(-1)
        df["target"] = (df["tomorrow_close"] > df["tomorrow_open"]).astype(int)
        return df

    def _set_target_3type(self, df):
        # 设置阈值（横盘波动阈值）
        threshold = 0.002  # 例如 0.2%

        # 未来开盘和收盘
        future_open_1 = df["open"].shift(-1)
        future_open_2 = df["open"].shift(-2)

        future_return = (future_open_2 - future_open_1) / future_open_1

        # 设定三分类标签
        # 用 pd.cut 得到分类类型
        df["target"] = pd.cut(
            future_return,
            bins=[-float('inf'), -threshold, threshold, float('inf')],
            labels=[0, 1, 2]
        )

        # df = df.dropna().reset_index(drop=True)

        return df

    # ===== 主函数入口 =====
    def enrich_features(self, df: pd.DataFrame) -> pd.DataFrame:
        
        df = self._add_features_daily(df)
        df = self._set_target_3type(df)
        return df
